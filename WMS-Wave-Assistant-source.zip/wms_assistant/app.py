import copy
import datetime as dt
import json
import os
from pathlib import Path
import queue
import secrets
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from zoneinfo import ZoneInfo
from .core import default_phases, default_config, validate_config, aisle_pairs, variants, validate_phase, ordered_phases

DATA = Path(os.environ.get('WMS_ASSISTANT_DATA', str(Path.home()/'.wms-wave-assistant')))
PHASES = default_phases()
TOKEN = secrets.token_urlsafe(32)
LOCK = threading.RLock()
JOBS = queue.Queue()
STOP = threading.Event()
STATE = {'busy':False,'browser_open':False,'message':'请登录 WMS，然后选择首波、次波或尾波。',
         'results':[], 'events':[], 'reminders':[], 'current_phase':None, 'completed_phase':None}
CONFIG = default_config()

def round_ledger():
    path=DATA/'round-ledger.json'
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else {'waves':[],'runs':[],'pending':None}

def save_round_ledger(data):
    with LOCK: atomic_json(DATA/'round-ledger.json',data)

def round_progress(index,key,title,status,detail):
    now=time.time()
    with LOCK:
        previous=STATE.get('round_progress') or {}
        started=previous.get('started',now) if previous.get('key')==key else now
        STATE['round_progress']={'index':index,'key':key,'title':title,'status':('running' if detail and status!='paused' else status),'started':started,'updated':now,**detail}
        nodes=STATE.setdefault('round_nodes',[])
        if detail:
            scope=detail.get('scope') or title
            node=next((n for n in nodes if n['key']==key and n['scope']==scope),None)
            if node is None:
                node={'key':key,'scope':scope,'started':now};nodes.append(node)
            node.update(detail,status=status,updated=now)
        elif status=='done':
            for node in nodes:
                if node['key']==key and node['status']=='running':node.update(status='done',updated=now)
    suffix=' · '+{'done':'已完成','paused':'已暂停','deferred':'已留置','skipped':'未选，跳过','limited':'达到批次上限'}.get(status,'执行中')
    if detail:
        suffix+=' · '+detail.get('scope','')+' · '+detail.get('action','')
        if 'packages' in detail:suffix+=' · '+str(detail['packages'])+' 包'
        if 'query_seconds' in detail:suffix+=' · '+str(detail['query_seconds'])+'s'
    event(title+suffix)


def atomic_json(path, data):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(path)

def event(message):
    with LOCK:
        item={'time':dt.datetime.now(dt.timezone.utc).isoformat(),'message':message}
        STATE['message']=message
        STATE['events'].append(item)
        STATE['events']=STATE['events'][-100:]
        with (DATA/'events.jsonl').open('a',encoding='utf-8') as f:
            f.write(json.dumps(item,ensure_ascii=False)+'\n')

def result(item):
    with LOCK:
        STATE['results'].append(item)
        STATE['results']=STATE['results'][-500:]
        atomic_json(DATA/'last-results.json',STATE['results'])

def pending_submission():
    path = DATA/'pending-submission.json'
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else None

def execute_phase(browser, phase, cfg, release_tail=False):
    if pending_submission():
        raise RuntimeError('存在待核对提交；请先在 WMS 核对后解除锁定')
    if phase.manual:
        raise RuntimeError('此阶段是人工检查点，请在 WMS 处理')
    for level, virtuals in variants(phase):
        base=aisle_pairs(phase.zone_types)
        cursor=0
        while True:
            if STOP.is_set():
                return
            end=min(cursor+cfg['initial_aisles'],len(base)) if phase.grouped else len(base)
            while True:
                if STOP.is_set():
                    return
                item=browser.query(phase,base[cursor:end],virtuals,cfg)
                count=item['total_packages']
                if count<cfg['min_packages'] and phase.grouped and end<len(base):
                    event(f"Total package={count}，不足 {cfg['min_packages']}，追加一个完整巷道并重新 Search")
                    end+=1
                    continue
                break
            item.update({'phase_id':phase.id,'phase_name':phase.name,'level':level,
                         'time':dt.datetime.now(dt.timezone.utc).isoformat(),'mode':'LIVE',
                         'submission_id':uuid.uuid4().hex})
            if count==0:
                item['decision']='无包裹，跳过'
            elif count<max(30,cfg['min_packages']):
                item['decision']='不足门槛，留到后续'
            else:
                if STOP.is_set():
                    return
                event(f'正式汇波：{phase.id}. {phase.name} {level}，策略 {phase.strategy} / Not Operated')
                def before_submit():
                    if STOP.is_set():
                        raise RuntimeError('停止请求已收到，未提交')
                    atomic_json(DATA/'pending-submission.json',item)
                    event('已记录提交意图，即将点击最终 OK：'+item['submission_id'])
                receipt=browser.consolidate(phase.strategy,before_submit,STOP)
                if receipt.get('status')!='confirmed':
                    raise RuntimeError('汇波没有得到明确成功回执')
                item['receipt']=receipt
                item['decision']='WMS 已确认汇波成功（Not Operated）'
                # Keep unresolved lock if persisting the receipt fails.
                result(item)
                (DATA/'pending-submission.json').unlink()
                event('本批汇波成功；准备下一批')
                if not phase.grouped or end>=len(base):
                    break
                cursor=end
                continue
            result(item)
            if not phase.grouped or end>=len(base):
                break
            cursor=end
    if not STOP.is_set():
        with LOCK:
            STATE['completed_phase']=phase.id
        event('本阶段处理完成，可直接点击下一个。')

def reconcile_round(browser):
    ledger=round_ledger();intent=ledger.get('pending')
    if not intent:raise RuntimeError('没有待核对操作')
    creator,warehouse=browser.identity()
    if creator!=intent['creator'] or warehouse!=intent['warehouse']:raise RuntimeError('当前账号或仓库与待核对操作不一致')
    if intent['kind']=='create':
        rows=browser.wait_new_waves(intent,STOP,allow_canceled_hold=intent.get('purpose') in ('top','single'))
        for row in rows:
            ledger['waves'].append({**row,'warehouse':warehouse,'run_id':intent['run_id'],'purpose':intent['purpose'],'step_key':intent.get('step_key'),'state':'canceled' if row['status']=='Canceled' else 'held' if intent['purpose'] in ('top','single') else 'released'})
        if intent['purpose']=='release_top':
            for run in ledger['runs']:
                if run['id']==intent['run_id']:run['top_released']+=sum(r['packages'] for r in rows)
    else:
        rows=browser.wave_snapshot(creator)
        found=[r for r in rows if r['wave_number']==intent['wave']['wave_number']]
        if len(found)!=1 or found[0]['status']!='Canceled':raise RuntimeError('该取消操作仍未确认；请在 WMS 人工核对')
        for wave in ledger['waves']:
            if wave['wave_number']==found[0]['wave_number']:wave['state']='canceled'
    run=next(r for r in ledger['runs'] if r['id']==intent['run_id'])
    if intent['kind']=='create':
        actual=sum(r['packages'] for r in rows)
        if actual!=intent['packages']:
            run.setdefault('quantity_differences',[]).append({'expected':intent['packages'],'actual':actual,'waves':[r['wave_number'] for r in rows]})
            event(f"数量差异仅记录：查询 {intent['packages']} 包，实际波次 {actual} 包")
        # A hold is one submission for the entire step, so its receipt
        # completes that step. Never skip an unfinished release batch.
        if intent['purpose'] in ('top','single'):
            from .rounds import run_steps
            keys=[k for k,_ in run_steps(run)]
            key='hold_'+intent['purpose']
            run['next_step']=keys.index(key)+(0 if all(r['status']=='Canceled' for r in rows) else 1);run['resume_ready']=True
    from .rounds import finish_checkpoint
    if intent['kind']=='create':
        finish_checkpoint(run,intent.get('checkpoint'))
        key=intent.get('step_key')
        if key and intent['purpose'].startswith('release_'):
            counts=run.setdefault('node_submissions',{});counts[key]=counts.get(key,0)+1
            totals=run.setdefault('node_packages',{});totals[key]=totals.get(key,0)+actual
    run['resume_ready']=True
    ledger['pending']=None;save_round_ledger(ledger)
    event('已自动检查上次操作结果，可以继续执行' if run.get('resume_ready') else '已核验操作结果；当前步骤需人工核对后结束本轮')


def worker():
    browser=None
    while True:
        command,payload = JOBS.get()
        if command=='shutdown':
            if browser:
                browser.close()
            return
        try:
            if (command in ('round','recheck','resume') or (command in ('scan','execute') and not payload['phase_config'].manual)) and not browser:
                from .browser import WMSBrowser
                browser=WMSBrowser(DATA/'browser-profile')
                with LOCK:
                    STATE['browser_open']=True
            if command=='open':
                if browser:
                    event('浏览器已打开，请在其窗口中完成登录。')
                else:
                    from .browser import WMSBrowser
                    browser=WMSBrowser(DATA/'browser-profile')
                    with LOCK:
                        STATE['browser_open']=True
                    event('浏览器已打开；请自行登录 WMS。不要在管理界面输入密码。')
            elif command=='resume':
                from .rounds import RoundRunner
                if pending_submission():raise RuntimeError('旧操作尚未核验')
                if round_ledger().get('pending'):reconcile_round(browser)
                RoundRunner(browser,round_ledger(),save_round_ledger,round_progress,STOP,copy.deepcopy(CONFIG)).resume()
                event('本轮续跑完成')
            elif command=='round':
                from .rounds import RoundRunner
                if pending_submission():raise RuntimeError('旧版本存在待核对提交，请先完成核对')
                ledger=round_ledger()
                active=[r for r in ledger['runs'] if r['status'] in ('running','paused')]
                if not payload.get('restart',False) and active and (len(active)!=1 or active[0]['mode']!=payload['mode']):
                    raise RuntimeError('请先选择未完成任务对应的策略，再点击开始继续')
                if ledger.get('pending'):
                    event('正在自动检查上次操作结果…')
                    reconcile_round(browser)
                    ledger=round_ledger()
                    active=[r for r in ledger['runs'] if r['status'] in ('running','paused')]
                if payload.get('restart',False):
                    creator,warehouse=browser.identity()
                    if any((run['creator'],run['warehouse'])!=(creator,warehouse) for run in active):
                        raise RuntimeError('当前账号或仓库与未完成任务不一致，未重新开始')
                    if hasattr(browser,'dismiss_unsubmitted_dialog'):browser.dismiss_unsubmitted_dialog()
                    if active:
                        folder=DATA/'backups';folder.mkdir(parents=True,exist_ok=True)
                        atomic_json(folder/('before-restart-'+uuid.uuid4().hex+'.json'),ledger)
                        for run in active:
                            run.update(status='ended',note='用户启动所选节点；保留已有波次',ended=dt.datetime.now(dt.timezone.utc).isoformat())
                        save_round_ledger(ledger)
                    active=[]
                runner=RoundRunner(browser,ledger,save_round_ledger,round_progress,STOP,copy.deepcopy(CONFIG))
                if active:runner.resume()
                elif 'selected_steps' in payload or 'release_limit' in payload:
                    options={'selection':payload.get('selected_steps'),'release_limit':payload.get('release_limit',0)}
                    if 'package_targets' in payload:options['package_targets']=payload['package_targets']
                    runner.execute(payload['mode'],**options)
                else:runner.execute(payload['mode'])
                event('本轮执行完成，请查看实际释放数量及剩余记录')
            elif command=='recheck':
                reconcile_round(browser)
            elif command=='execute':
                if not browser:
                    raise RuntimeError('请先打开浏览器并登录')
                execute_phase(browser,payload['phase_config'],payload['config'],payload.get('release_tail',False))
            elif command=='scan':
                phase=payload['phase_config']
                cfg=payload['config']
                if phase.manual:
                    event(phase.name+'：'+phase.note+' 此阶段需要人工处理，本程序不会操作。')
                    continue
                if not browser:
                    raise RuntimeError('请先打开浏览器并登录')
                with LOCK:
                    STATE['current_phase']=phase.id
                base=aisle_pairs(phase.zone_types)
                for level,virtuals in variants(phase):
                    cursor=0
                    while True:
                        if STOP.is_set():
                            event('已停止后续查询；没有提交任何汇波。')
                            break
                        end=min(cursor+cfg['initial_aisles'],len(base)) if phase.grouped else len(base)
                        selected=base[cursor:end]
                        while True:
                            event(f'只读查询：{phase.id}. {phase.name} {level} / '+(', '.join(map(str,selected)) or '整个指定范围'))
                            item=browser.query(phase,selected,virtuals,cfg)
                            item.update({'phase_id':phase.id,'phase_name':phase.name,'level':level,
                                         'time':dt.datetime.now(dt.timezone.utc).isoformat(),'mode':'PREVIEW ONLY'})
                            # User-defined batch size is the post-Search Total package for every strategy.
                            eligible = True
                            item['threshold_usable']=eligible
                            enough=item['total_packages']>=cfg['min_packages']
                            at_end=end>=len(base)
                            if not eligible:
                                item['decision']='仅记录查询：仓区匹配语义尚未核验，不自动扩展'
                            elif enough:
                                item['decision']='达到预览门槛；未创建波次'
                            elif phase.grouped and not at_end:
                                item['decision']='不足门槛，下一次预览追加一个完整巷道'
                            else:
                                item['decision']='尾批不足，留到后续；中午收尾需人工核验'
                            result(item)
                            if STOP.is_set() or not eligible or enough or not phase.grouped or at_end:
                                break
                            end+=1
                            selected=base[cursor:end]
                        if STOP.is_set() or not phase.grouped or end>=len(base):
                            break
                        cursor=end
                    if STOP.is_set():
                        break
                event('本阶段预览结束。没有汇波；下一阶段须单独点击开始。')
        except Exception as exc:
            event('已停止：'+str(exc))
        finally:
            with LOCK:
                STATE['busy']=False
                STATE['current_phase']=None
            JOBS.task_done()

def reminder_loop():
    seen_path=DATA/'reminders-seen.json'
    try:
        seen=set(json.loads(seen_path.read_text(encoding='utf-8')))
    except (FileNotFoundError,ValueError):
        seen=set()
    while True:
        with LOCK:
            cfg=copy.deepcopy(CONFIG)
        now=dt.datetime.now(ZoneInfo(cfg['timezone']))
        for scheduled in cfg['schedules']:
            key=now.date().isoformat()+'|'+scheduled['time']+'|'+cfg['timezone']
            # Only the current minute. Missed schedules are not automatically replayed.
            if now.strftime('%H:%M')==scheduled['time'] and key not in seen:
                with LOCK:
                    STATE['reminders'].append({'time':now.isoformat(),'message':scheduled['label']})
                seen.add(key)
                atomic_json(seen_path,sorted(seen)[-100:])
                event('定时提醒：'+scheduled['label']+'（不会自动汇波）')
        time.sleep(10)

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):
        pass
    def send_json(self, data, status=200):
        body=json.dumps(data,ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.end_headers()
        self.wfile.write(body)
    def do_GET(self):
        if self.path in ('/','/monitor'):
            html=Path(__file__).with_name('monitor.html' if self.path=='/monitor' else 'ui.html').read_text(encoding='utf-8').replace('__TOKEN__',TOKEN)
            self.send_response(200)
            self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Frame-Options','DENY')
            self.end_headers()
            self.wfile.write(html.encode())
        elif self.path=='/icon.png':
            body=Path(__file__).with_name('assets').joinpath('wave.png').read_bytes()
            self.send_response(200);self.send_header('Content-Type','image/png');self.end_headers();self.wfile.write(body)
        elif self.path=='/api/state':
            if self.headers.get('X-WMS-Token')!=TOKEN:
                return self.send_json({'error':'Forbidden'},403)
            with LOCK:
                self.send_json({'state':copy.deepcopy(STATE),'config':CONFIG,
                                'phases':[p.to_dict() for p in ordered_phases(PHASES)],'data_dir':str(DATA), 'pending_submission':pending_submission(),'round_ledger':round_ledger()})
        else:
            self.send_json({'error':'Not found'},404)
    def do_POST(self):
        if self.headers.get('X-WMS-Token')!=TOKEN:
            return self.send_json({'error':'Forbidden'},403)
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length>65536:
                raise ValueError('请求过大')
            payload=json.loads(self.rfile.read(length) or '{}')
            if self.path=='/api/export-ledger':
                with LOCK:
                    folder=DATA/'exports'
                    folder.mkdir(parents=True,exist_ok=True)
                    path=folder/('wms-wave-ledger-'+dt.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]+'.json')
                    atomic_json(path,round_ledger())
                return self.send_json({'path':str(path)})
            if self.path in ('/api/round','/api/recheck-round','/api/end-round','/api/resume-round'):
                with LOCK:
                    if STATE['busy']:raise ValueError('已有任务运行，请等待或停止')
                    ledger=round_ledger()
                    if self.path=='/api/end-round':
                        if ledger.get('pending'):raise ValueError('结果不明的操作尚未核对，不能结束本轮')
                        note=str(payload.get('note','')).strip()
                        if len(note)<4:raise ValueError('请填写人工核对结果')
                        for run in ledger['runs']:
                            if run['status'] in ('paused','running'):run.update(status='ended',note=note)
                        save_round_ledger(ledger)
                        return self.send_json({'ok':True})
                    if self.path=='/api/round':
                        from .rounds import ROUND_NAMES, selected_steps, validate_targets
                        if payload.get('mode') not in ROUND_NAMES and not (payload.get('mode')=='second' and not payload.get('restart',False)):raise ValueError('未知放单策略')
                        if type(payload.get('restart',False)) is not bool:raise ValueError('无效的开始方式')
                        if payload.get('restart',False) or not any(r['status'] in ('running','paused') for r in ledger['runs']):selected_steps(payload['mode'],payload.get('selected_steps'))
                        validate_targets(payload['mode'],payload.get('package_targets'))
                        limit=payload.get('release_limit',0)
                        if type(limit) is not int or not 0<=limit<=1000:raise ValueError('节点汇波批次上限须为 0–1000')
                        if pending_submission():raise ValueError('旧版本提交记录尚未处理')
                    if self.path=='/api/resume-round':
                        runs=[r for r in ledger['runs'] if r['status'] in ('paused','running')]
                        if pending_submission() or len(runs)!=1:raise ValueError('当前暂停位置不支持自动续跑，请先核验')
                    STATE['busy']=True;STATE['round_progress']=None;STATE['round_nodes']=[];STOP.clear()
                    JOBS.put(('round' if self.path=='/api/round' else 'resume' if self.path=='/api/resume-round' else 'recheck',payload))
                    return self.send_json({'ok':True})
            if self.path=='/api/config':
                cfg=validate_config(payload)
                with LOCK:
                    CONFIG.clear(); CONFIG.update(cfg)
                    atomic_json(DATA/'config.json',CONFIG)
                return self.send_json({'ok':True})
            if self.path=='/api/phase':
                with LOCK:
                    if STATE['busy']:
                        return self.send_json({'error':'查询运行中不能修改阶段'},409)
                    pid=payload.get('id')
                    if type(pid) is not int or not 1<=pid<=30:
                        raise ValueError('阶段编号无效')
                    PHASES[pid-1]=validate_phase(payload,PHASES[pid-1])
                    atomic_json(DATA/'phases.json',[p.to_dict() for p in PHASES])
                return self.send_json({'ok':True})
            if self.path=='/api/reconcile':
                with LOCK:
                    if STATE['busy']:
                        raise ValueError('任务运行中不能解除锁定')
                    record=pending_submission()
                    if not record or payload.get('submission_id')!=record['submission_id']:
                        raise ValueError('待核对提交编号不匹配')
                    note=str(payload.get('note','')).strip()
                    if len(note)<4:
                        raise ValueError('请填写核对结果，例如波次号或确认未生成')
                    record['manual_reconciliation']=note
                    with (DATA/'reconciliations.jsonl').open('a',encoding='utf-8') as f:
                        f.write(json.dumps(record,ensure_ascii=False)+'\n')
                    (DATA/'pending-submission.json').unlink()
                    event('人工核对完成：'+note+'；没有自动重试')
                return self.send_json({'ok':True})
            if self.path=='/api/stop':
                STOP.set()
                return self.send_json({'ok':True})
            if self.path=='/api/dismiss':
                with LOCK:
                    STATE['reminders']=[]
                return self.send_json({'ok':True})
            if self.path not in ('/api/open','/api/scan','/api/execute'):
                return self.send_json({'error':'Not found'},404)
            with LOCK:
                if STATE['busy']:
                    return self.send_json({'error':'已有任务运行，禁止并行操作同一浏览器'},409)
                if self.path in ('/api/scan','/api/execute'):
                    pid=payload.get('phase')
                    if type(pid) is not int or not 1<=pid<=len(PHASES):
                        raise ValueError('阶段编号无效')
                    live=self.path=='/api/execute'
                    if live and (payload.get('confirm_live') is not True or pending_submission()):
                        raise ValueError('必须确认正式汇波且无待核对提交')
                    job=('execute' if live else 'scan',{'release_tail':payload.get('release_tail') is True,'phase':pid,'phase_config':copy.deepcopy(PHASES[pid-1]),'config':copy.deepcopy(CONFIG)})
                else:
                    job=('open',{})
                STATE['completed_phase']=None
                STATE['busy']=True
                STOP.clear()
                JOBS.put(job)
            self.send_json({'ok':True})
        except Exception as exc:
            self.send_json({'error':str(exc)},400)

def main():
    DATA.mkdir(parents=True,exist_ok=True)
    try:
        os.chmod(DATA,0o700)
    except OSError:
        pass
    planfile=DATA/'phases.json'
    if planfile.exists():
        plans=json.loads(planfile.read_text(encoding='utf-8'))
        if len(plans)!=30:
            raise ValueError('阶段文件必须包含 30 个阶段')
        PHASES[:]=[validate_phase(p,original) for p,original in zip(plans,PHASES)]
    else:
        atomic_json(planfile,[p.to_dict() for p in PHASES])
    policyfile=DATA/'range-policy-v043.json'
    if not policyfile.exists():
        # Apply the user's new full-range policy to existing local phase files.
        for phase in PHASES:
            if len(phase.zone_types)==1 and not phase.manual:
                phase.grouped=False
        atomic_json(planfile,[p.to_dict() for p in PHASES])
        atomic_json(policyfile,{'version':1})
    cfgfile=DATA/'config.json'
    if cfgfile.exists():
        CONFIG.update(validate_config(json.loads(cfgfile.read_text(encoding='utf-8'))))
    else:
        atomic_json(cfgfile,CONFIG)
    port=int(os.environ.get('WMS_ASSISTANT_PORT','8765'))
    # Binding a fixed loopback port also prevents two app instances sharing a profile.
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    worker_thread=threading.Thread(target=worker,daemon=True)
    worker_thread.start()
    threading.Thread(target=reminder_loop,daemon=True).start()
    url=f'http://127.0.0.1:{port}'
    try:
        if '--no-open' in sys.argv:
            server.serve_forever()
        else:
            from .desktop import show_desktop
            serving=threading.Thread(target=server.serve_forever,daemon=True)
            serving.start()
            try:
                show_desktop(url, DATA/'desktop-profile', STOP)
            finally:
                server.shutdown()
                serving.join(timeout=5)
    except KeyboardInterrupt:
        pass
    finally:
        STOP.set()
        server.server_close()
        JOBS.put(('shutdown',{}))
        worker_thread.join(timeout=90)

if __name__=='__main__':
    main()
