import copy
import datetime as dt
import json
import os
from pathlib import Path
import queue
import secrets
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from zoneinfo import ZoneInfo
from .core import default_phases, default_config, validate_config, aisle_pairs, variants, validate_phase

DATA = Path(os.environ.get('WMS_ASSISTANT_DATA', str(Path.home()/'.wms-wave-assistant')))
PHASES = default_phases()
TOKEN = secrets.token_urlsafe(32)
LOCK = threading.RLock()
JOBS = queue.Queue()
STOP = threading.Event()
STATE = {'busy':False,'browser_open':False,'message':'先打开浏览器并登录，再选择阶段试查。',
         'results':[], 'events':[], 'reminders':[], 'current_phase':None}
CONFIG = default_config()

def atomic_json(path, data):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(path)

def event(message):
    with LOCK:
        item={'time':dt.datetime.now(dt.timezone.utc).isoformat(),'message':message}
        STATE['message']=message
        STATE['events'].append(item)
        STATE['events']=STATE['events'][-100:]
        with (DATA/'events.jsonl').open('a',encoding='utf-8') as f:
            f.write(json.dumps(item,ensure_ascii=False)+'\n')

def result(item):
    with LOCK:
        STATE['results'].append(item)
        STATE['results']=STATE['results'][-500:]
        atomic_json(DATA/'last-results.json',STATE['results'])

def pending_submission():
    path = DATA/'pending-submission.json'
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else None

def execute_phase(browser, phase, cfg, release_tail=False):
    if pending_submission():
        raise RuntimeError('存在待核对提交；请先在 WMS 核对后解除锁定')
    if phase.manual:
        raise RuntimeError('此阶段是人工检查点，请在 WMS 处理')
    for level, virtuals in variants(phase):
        base=aisle_pairs(phase.zone_types)
        cursor=0
        while True:
            if STOP.is_set():
                return
            end=min(cursor+cfg['initial_aisles'],len(base)) if phase.grouped else len(base)
            while True:
                if STOP.is_set():
                    return
                item=browser.query(phase,base[cursor:end],virtuals,cfg)
                count=item['total_packages']
                if count<cfg['min_packages'] and phase.grouped and end<len(base):
                    event(f"Total package={count}，不足 {cfg['min_packages']}，追加一个完整巷道并重新 Search")
                    end+=1
                    continue
                break
            item.update({'phase_id':phase.id,'phase_name':phase.name,'level':level,
                         'time':dt.datetime.now(dt.timezone.utc).isoformat(),'mode':'LIVE',
                         'submission_id':uuid.uuid4().hex})
            if count==0:
                item['decision']='无包裹，跳过'
            elif count<cfg['min_packages'] and not release_tail:
                item['decision']='不足门槛，留到后续'
            else:
                if STOP.is_set():
                    return
                event(f'正式汇波：{phase.id}. {phase.name} {level}，策略 {phase.strategy} / Not Operated')
                def before_submit():
                    if STOP.is_set():
                        raise RuntimeError('停止请求已收到，未提交')
                    atomic_json(DATA/'pending-submission.json',item)
                    event('已记录提交意图，即将点击最终 OK：'+item['submission_id'])
                receipt=browser.consolidate(phase.strategy,before_submit,STOP)
                if receipt.get('status')!='confirmed':
                    raise RuntimeError('汇波没有得到明确成功回执')
                item['receipt']=receipt
                item['decision']='WMS 已确认汇波成功（Not Operated）'
                # Keep unresolved lock if persisting the receipt fails.
                result(item)
                (DATA/'pending-submission.json').unlink()
                event('本批汇波成功；准备下一批')
                if not phase.grouped or end>=len(base):
                    break
                cursor=end
                continue
            result(item)
            if not phase.grouped or end>=len(base):
                break
            cursor=end
    event('本阶段汇波处理结束，请核对结果；下一阶段须单独开始。')

def worker():
    browser=None
    while True:
        command,payload = JOBS.get()
        if command=='shutdown':
            if browser:
                browser.close()
            return
        try:
            if command in ('scan','execute') and not browser and not payload['phase_config'].manual:
                from .browser import WMSBrowser
                browser=WMSBrowser(DATA/'browser-profile')
                with LOCK:
                    STATE['browser_open']=True
            if command=='open':
                if browser:
                    event('浏览器已打开，请在其窗口中完成登录。')
                else:
                    from .browser import WMSBrowser
                    browser=WMSBrowser(DATA/'browser-profile')
                    with LOCK:
                        STATE['browser_open']=True
                    event('浏览器已打开；请自行登录 WMS。不要在管理界面输入密码。')
            elif command=='execute':
                if not browser:
                    raise RuntimeError('请先打开浏览器并登录')
                execute_phase(browser,payload['phase_config'],payload['config'],payload.get('release_tail',False))
            elif command=='scan':
                phase=payload['phase_config']
                cfg=payload['config']
                if phase.manual:
                    event(phase.name+'：'+phase.note+' 此阶段需要人工处理，本程序不会操作。')
                    continue
                if not browser:
                    raise RuntimeError('请先打开浏览器并登录')
                with LOCK:
                    STATE['current_phase']=phase.id
                base=aisle_pairs(phase.zone_types)
                for level,virtuals in variants(phase):
                    cursor=0
                    while True:
                        if STOP.is_set():
                            event('已停止后续查询；没有提交任何汇波。')
                            break
                        end=min(cursor+cfg['initial_aisles'],len(base)) if phase.grouped else len(base)
                        selected=base[cursor:end]
                        while True:
                            event(f'只读查询：{phase.id}. {phase.name} {level} / '+(', '.join(map(str,selected)) or '整个指定范围'))
                            item=browser.query(phase,selected,virtuals,cfg)
                            item.update({'phase_id':phase.id,'phase_name':phase.name,'level':level,
                                         'time':dt.datetime.now(dt.timezone.utc).isoformat(),'mode':'PREVIEW ONLY'})
                            # User-defined batch size is the post-Search Total package for every strategy.
                            eligible = True
                            item['threshold_usable']=eligible
                            enough=item['total_packages']>=cfg['min_packages']
                            at_end=end>=len(base)
                            if not eligible:
                                item['decision']='仅记录查询：仓区匹配语义尚未核验，不自动扩展'
                            elif enough:
                                item['decision']='达到预览门槛；未创建波次'
                            elif phase.grouped and not at_end:
                                item['decision']='不足门槛，下一次预览追加一个完整巷道'
                            else:
                                item['decision']='尾批不足，留到后续；中午收尾需人工核验'
                            result(item)
                            if STOP.is_set() or not eligible or enough or not phase.grouped or at_end:
                                break
                            end+=1
                            selected=base[cursor:end]
                        if STOP.is_set() or not phase.grouped or end>=len(base):
                            break
                        cursor=end
                    if STOP.is_set():
                        break
                event('本阶段预览结束。没有汇波；下一阶段须单独点击开始。')
        except Exception as exc:
            event('已停止：'+str(exc))
        finally:
            with LOCK:
                STATE['busy']=False
                STATE['current_phase']=None
            JOBS.task_done()

def reminder_loop():
    seen_path=DATA/'reminders-seen.json'
    try:
        seen=set(json.loads(seen_path.read_text(encoding='utf-8')))
    except (FileNotFoundError,ValueError):
        seen=set()
    while True:
        with LOCK:
            cfg=copy.deepcopy(CONFIG)
        now=dt.datetime.now(ZoneInfo(cfg['timezone']))
        for scheduled in cfg['schedules']:
            key=now.date().isoformat()+'|'+scheduled['time']+'|'+cfg['timezone']
            # Only the current minute. Missed schedules are not automatically replayed.
            if now.strftime('%H:%M')==scheduled['time'] and key not in seen:
                with LOCK:
                    STATE['reminders'].append({'time':now.isoformat(),'message':scheduled['label']})
                seen.add(key)
                atomic_json(seen_path,sorted(seen)[-100:])
                event('定时提醒：'+scheduled['label']+'（不会自动汇波）')
        time.sleep(10)

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):
        pass
    def send_json(self, data, status=200):
        body=json.dumps(data,ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.end_headers()
        self.wfile.write(body)
    def do_GET(self):
        if self.path=='/':
            html=Path(__file__).with_name('ui.html').read_text(encoding='utf-8').replace('__TOKEN__',TOKEN)
            self.send_response(200)
            self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Frame-Options','DENY')
            self.end_headers()
            self.wfile.write(html.encode())
        elif self.path=='/api/state':
            if self.headers.get('X-WMS-Token')!=TOKEN:
                return self.send_json({'error':'Forbidden'},403)
            with LOCK:
                self.send_json({'state':copy.deepcopy(STATE),'config':CONFIG,
                                'phases':[p.to_dict() for p in PHASES],'data_dir':str(DATA), 'pending_submission':pending_submission()})
        else:
            self.send_json({'error':'Not found'},404)
    def do_POST(self):
        if self.headers.get('X-WMS-Token')!=TOKEN:
            return self.send_json({'error':'Forbidden'},403)
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length>65536:
                raise ValueError('请求过大')
            payload=json.loads(self.rfile.read(length) or '{}')
            if self.path=='/api/config':
                cfg=validate_config(payload)
                with LOCK:
                    CONFIG.clear(); CONFIG.update(cfg)
                    atomic_json(DATA/'config.json',CONFIG)
                return self.send_json({'ok':True})
            if self.path=='/api/phase':
                with LOCK:
                    if STATE['busy']:
                        return self.send_json({'error':'查询运行中不能修改阶段'},409)
                    pid=payload.get('id')
                    if type(pid) is not int or not 1<=pid<=30:
                        raise ValueError('阶段编号无效')
                    PHASES[pid-1]=validate_phase(payload,PHASES[pid-1])
                    atomic_json(DATA/'phases.json',[p.to_dict() for p in PHASES])
                return self.send_json({'ok':True})
            if self.path=='/api/reconcile':
                with LOCK:
                    if STATE['busy']:
                        raise ValueError('任务运行中不能解除锁定')
                    record=pending_submission()
                    if not record or payload.get('submission_id')!=record['submission_id']:
                        raise ValueError('待核对提交编号不匹配')
                    note=str(payload.get('note','')).strip()
                    if len(note)<4:
                        raise ValueError('请填写核对结果，例如波次号或确认未生成')
                    record['manual_reconciliation']=note
                    with (DATA/'reconciliations.jsonl').open('a',encoding='utf-8') as f:
                        f.write(json.dumps(record,ensure_ascii=False)+'\n')
                    (DATA/'pending-submission.json').unlink()
                    event('人工核对完成：'+note+'；没有自动重试')
                return self.send_json({'ok':True})
            if self.path=='/api/stop':
                STOP.set()
                return self.send_json({'ok':True})
            if self.path=='/api/dismiss':
                with LOCK:
                    STATE['reminders']=[]
                return self.send_json({'ok':True})
            if self.path not in ('/api/open','/api/scan','/api/execute'):
                return self.send_json({'error':'Not found'},404)
            with LOCK:
                if STATE['busy']:
                    return self.send_json({'error':'已有任务运行，禁止并行操作同一浏览器'},409)
                if self.path in ('/api/scan','/api/execute'):
                    pid=payload.get('phase')
                    if type(pid) is not int or not 1<=pid<=len(PHASES):
                        raise ValueError('阶段编号无效')
                    live=self.path=='/api/execute'
                    if live and (payload.get('confirm_live') is not True or pending_submission()):
                        raise ValueError('必须确认正式汇波且无待核对提交')
                    job=('execute' if live else 'scan',{'release_tail':payload.get('release_tail') is True,'phase':pid,'phase_config':copy.deepcopy(PHASES[pid-1]),'config':copy.deepcopy(CONFIG)})
                else:
                    job=('open',{})
                STATE['busy']=True
                STOP.clear()
                JOBS.put(job)
            self.send_json({'ok':True})
        except Exception as exc:
            self.send_json({'error':str(exc)},400)

def main():
    DATA.mkdir(parents=True,exist_ok=True)
    try:
        os.chmod(DATA,0o700)
    except OSError:
        pass
    planfile=DATA/'phases.json'
    if planfile.exists():
        plans=json.loads(planfile.read_text(encoding='utf-8'))
        if len(plans)!=30:
            raise ValueError('阶段文件必须包含 30 个阶段')
        PHASES[:]=[validate_phase(p,original) for p,original in zip(plans,PHASES)]
    else:
        atomic_json(planfile,[p.to_dict() for p in PHASES])
    cfgfile=DATA/'config.json'
    if cfgfile.exists():
        CONFIG.update(validate_config(json.loads(cfgfile.read_text(encoding='utf-8'))))
    else:
        atomic_json(cfgfile,CONFIG)
    port=int(os.environ.get('WMS_ASSISTANT_PORT','8765'))
    # Binding a fixed loopback port also prevents two app instances sharing a profile.
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    worker_thread=threading.Thread(target=worker,daemon=True)
    worker_thread.start()
    threading.Thread(target=reminder_loop,daemon=True).start()
    url=f'http://127.0.0.1:{port}'
    try:
        if '--no-open' in sys.argv:
            server.serve_forever()
        else:
            from .desktop import show_desktop
            serving=threading.Thread(target=server.serve_forever,daemon=True)
            serving.start()
            try:
                show_desktop(url, DATA/'desktop-profile', STOP)
            finally:
                server.shutdown()
                serving.join(timeout=5)
    except KeyboardInterrupt:
        pass
    finally:
        STOP.set()
        server.server_close()
        JOBS.put(('shutdown',{}))
        worker_thread.join(timeout=90)

if __name__=='__main__':
    main()
