"""Three-round orchestration with durable, exact-wave ownership and receipts."""
import copy
import datetime as dt
import uuid
import time
from dataclasses import replace
from .core import Phase, default_phases, aisle_pairs, variants

MULTI_TABS = ('Multiple units (same SKU)', 'Multiple units (mixed SKUs)', 'Multi Items Multi Pieces')
ROUND_NAMES = {'first':'首波','second':'次波','last':'尾波'}

def steps_for(mode):
    if mode not in ROUND_NAMES: raise ValueError('未知放单策略')
    steps=[('hold_top','隔离爆品')]
    if mode=='first':
        steps += [('hold_single','暂存普通 Single'),('multis','按区域 / 巷道释放全部 Multis'),
                  ('cancel_single','取消本轮 Single 暂存'),('single','按区域 / 巷道释放 Single（1–3）'),
                  ('cancel_top','取消爆品暂存'),('top','按区域 / 巷道释放爆品（最多 2000 包）')]
    else:
        steps += [('single','按区域 / 巷道释放全部普通 Single'),('multis','按区域 / 巷道释放全部 Multis')]
        if mode=='last': steps += [('cancel_top','取消爆品暂存'),('top','按区域 / 巷道释放全部爆品（6–999）')]
    return steps+[('audit','核验结果与剩余包裹')]

def scoped_phases(kind):
    return [replace(p,grouped=p.zone_types==['Box']) for p in default_phases() if p.kind==kind and p.id not in (12,13)]

def candidate_threshold(query, budget, floor=6):
    """Maximize cumulative packages without exceeding budget; reads only.

    Start at 100. Search downward if there is room and upward if already over budget.
    Requery the chosen threshold before any submission because WMS is dynamic.
    """
    counts={}
    def count(n):
        if n not in counts: counts[n]=query(n)
        return counts[n]
    start=count(100)
    lo,hi=(floor,100) if start<=budget else (101,999)
    best=100 if 0<start<=budget else None
    while lo<=hi:
        mid=(lo+hi)//2; n=count(mid)
        if n<=budget:
            if n>0: best=mid
            hi=mid-1
        else: lo=mid+1
    # A changing result must never cause a submission above the remaining budget.
    return best, counts

class RoundRunner:
    def __init__(self,browser,ledger,save,progress,stop,config):
        self.b=browser;self.data=ledger;self.save=save;self.progress=progress;self.stop=stop;self.cfg=config
        self.data.setdefault('waves',[]);self.data.setdefault('runs',[])
    def persist(self): self.save(self.data)
    def check(self):
        if self.stop.is_set(): raise RuntimeError('已停止；已创建波次保留在台账中，不会自动重试')
    def holds(self,purpose):
        return [w for w in self.data['waves'] if w['purpose']==purpose and w['state']=='held' and w['creator']==self.creator and w.get('warehouse')==self.warehouse]
    def resume(self):
        if self.data.get('pending'):raise RuntimeError('请先核验待处理波次')
        runs=[r for r in self.data['runs'] if r['status'] in ('paused','running')]
        if len(runs)==1 and runs[0].get('error')=='提交前包裹数发生变化，已暂停；本批尚未提交':
            keys=[key for key,_ in steps_for(runs[0]['mode'])]
            index=runs[0].get('next_step',0)
            if 0<=index<len(keys) and keys[index] in ('hold_top','hold_single'):
                runs[0]['resume_ready']=True
        if len(runs)==1 and runs[0].get('error','').startswith(('已停止，尚未点击最终 OK','已停止，尚未提交','已停止；已创建波次保留')):
            runs[0]['resume_ready']=True
        if len(runs)!=1 or not runs[0].get('resume_ready'):raise RuntimeError('当前暂停位置不支持自动续跑')
        self.run=runs[0]
        self.creator,self.warehouse=self.b.identity()
        if (self.creator,self.warehouse)!=(self.run['creator'],self.run['warehouse']):raise RuntimeError('续跑账号或仓库不一致')
        if hasattr(self.b,'dismiss_unsubmitted_dialog'):self.b.dismiss_unsubmitted_dialog()
        self.run['status']='running';self.run['resume_ready']=False;self.persist()
        self.execute(self.run['mode'],resuming=True)

    def execute(self,mode,resuming=False):
        if self.data.get('pending'): raise RuntimeError('存在结果不明的操作，请先到 WMS 核对；禁止重复执行')
        if not resuming:
            if any(r['status'] in ('running','paused') for r in self.data['runs']):
                raise RuntimeError('上一轮未结束。请先核对台账并结束该轮，再启动新一轮')
            self.creator,self.warehouse=self.b.identity()
            self.run={'id':uuid.uuid4().hex,'mode':mode,'creator':self.creator,'warehouse':self.warehouse,'status':'running','top_released':0,'started':dt.datetime.now(dt.timezone.utc).isoformat()}
            self.data['runs'].append(self.run);self.persist()
        try:
            for index,(key,title) in enumerate(steps_for(mode)):
                if index<self.run.get('next_step',0):continue
                self.run['resume_ready']=False;self.persist()
                self.check();self.step=(index,key,title);self.progress(index,key,title,'running',{})
                if key=='hold_top': self.hold('top',6,999)
                elif key=='hold_single': self.hold('single',None,None)
                elif key=='cancel_single': self.cancel('single')
                elif key=='cancel_top': self.cancel('top')
                elif key=='single': self.release('single',1,3 if mode=='first' else 5,True)
                elif key=='multis': self.release_multis()
                elif key=='top': self.release_top(mode)
                elif key=='audit': self.audit()
                self.run['next_step']=index+1;self.run['resume_ready']=True;self.persist()
                self.progress(index,key,title,'done',{})
            self.run['status']='complete';self.persist()
        except Exception as exc:
            self.run['status']='paused';self.run['error']=str(exc);self.persist();raise
    def query(self,p,pairs,virtuals,minimum=None,maximum=None,tab=None):
        self.check()
        # Recovery is restricted to reads with no unresolved write intent.
        from playwright.sync_api import TimeoutError as PlaywrightTimeout
        interval=max(0,int(self.cfg.get('refresh_every_queries',0)))
        count=getattr(self,'query_count',0)
        if interval and count and count % interval == 0 and not self.data.get('pending'):
            self.recover_query(False)
        for attempt in range(3):
            self.check()
            try:
                result=self.b.query(p,pairs,virtuals,self.cfg,quantity=(minimum,maximum),tab_override=tab)
                break
            except (PlaywrightTimeout, RuntimeError) as exc:
                cause=exc
                while cause.__cause__ is not None: cause=cause.__cause__
                transient=isinstance(cause,PlaywrightTimeout) or str(exc)=='查询结果未稳定，已停止'
                if not transient or self.data.get('pending') or attempt==2: raise
                self.recover_query(attempt==1)
        self.query_count=count+1
        if hasattr(self,'step'):
            index,key,title=self.step
            self.progress(index,key,title,'running',{'scope':p.name,'aisles':list(pairs),'virtual_zones':virtuals,'packages':result['total_packages']})
        return result
    def recover_query(self,reopen):
        self.check()
        if self.data.get('pending'): raise RuntimeError('存在未核验操作，禁止刷新重试')
        if hasattr(self,'step'):
            index,key,title=self.step
            self.progress(index,key,title,'running',{'scope':'重新打开页面并恢复筛选' if reopen else '清理浏览器缓存并刷新页面'})
        self.b.recover_query_page(reopen=reopen)
        if self.b.identity()!=(self.creator,self.warehouse):
            raise RuntimeError('恢复页面后账号或仓库已改变，已暂停')
        self.check()
    def write(self,p,pairs,virtuals,item,purpose,minimum=None,maximum=None,tab=None):
        self.check()
        if self.b.identity()!=(self.creator,self.warehouse):raise RuntimeError('执行账号或仓库已改变，尚未提交')
        if getattr(self.b,'preserves_query_for_receipts',False):
            if not hasattr(self,'receipt_baseline'):self.receipt_baseline=self.b.wave_snapshot(self.creator)
            baseline=self.receipt_baseline
            current=item
        else:
            baseline=self.b.wave_snapshot(self.creator)
            current=self.query(p,pairs,virtuals,minimum,maximum,tab)
        # Orders arrive continuously; submit the latest search, without comparing counts.
        if current['total_packages']==0:return
        if purpose=='release_top' and self.run['mode']=='first' and self.run['top_released']+current['total_packages']>2000:
            raise RuntimeError('本批将超过首波 2000 包上限，尚未提交')
        intent={'kind':'create','run_id':self.run['id'],'creator':self.creator,'warehouse':self.warehouse,'purpose':purpose,'packages':current['total_packages'],'baseline':baseline,'started':dt.datetime.now(dt.timezone.utc).isoformat(),'query':current}
        def before():
            self.check();self.data['pending']=intent;self.persist()
        self.b.consolidate(p.strategy,before,self.stop,receipt_via_table=True)
        rows=self.b.wait_new_waves(intent,self.stop)
        self.receipt_baseline=[*baseline,*rows]
        actual=sum(r['packages'] for r in rows)
        if actual!=intent['packages']:
            self.run.setdefault('quantity_differences',[]).append({'expected':intent['packages'],'actual':actual,'waves':[r['wave_number'] for r in rows]})
            if hasattr(self,'step'):self.progress(*self.step,'running',{'scope':'数量差异仅记录，已核验新波次','packages':actual})
        for row in rows:
            self.data['waves'].append({**row,'warehouse':self.warehouse,'run_id':self.run['id'],'purpose':purpose,'state':'held' if purpose in ('top','single') else 'released'})
        if purpose=='release_top': self.run['top_released']+=sum(r['packages'] for r in rows)
        self.data['pending']=None;self.persist()
    def hold(self,kind,minimum,maximum):
        # Existing tracked holds remain isolated; this catches newly arrived packages.
        p=Phase(100,'暂存 '+kind,'single',[],[],'Top Selling - Single' if kind=='top' else 'Clean-up Single')
        item=self.query(p,[],[],minimum,maximum,'One item only')
        if item['total_packages']:
            self.write(p,[],[],item,kind,minimum,maximum,'One item only')
    def cancel(self,purpose):
        owned=list(self.holds(purpose))
        if not owned:return
        if self.b.identity()!=(self.creator,self.warehouse):raise RuntimeError('取消前账号或仓库已改变')
        existing={r['wave_number']:r for r in self.b.wave_snapshot(self.creator)}
        for wave in owned:
            if existing.get(wave['wave_number'],{}).get('status')=='Canceled':wave['state']='canceled'
        self.persist();owned=[w for w in owned if w['state']=='held']
        if not owned:return
        p=Phase(103,'等待取消包裹回池','single',[],[],'')
        bounds=(6,999) if purpose=='top' else (None,None)
        before_count=self.query(p,[],[],*bounds,'One item only')['total_packages']
        for wave in owned:
            self.check()
            intent={'kind':'cancel','run_id':self.run['id'],'wave':copy.deepcopy(wave),'creator':self.creator,'warehouse':self.warehouse}
            def before():
                self.check();self.data['pending']=intent;self.persist()
            self.b.cancel_owned_wave(wave,before,self.stop)
            wave['state']='canceled';self.data['pending']=None;self.persist()
        target=before_count+sum(w['packages'] for w in owned)
        deadline=time.monotonic()+120
        while time.monotonic()<deadline:
            self.check()
            if self.query(p,[],[],*bounds,'One item only')['total_packages']>=target:return
            time.sleep(2)
        raise RuntimeError('取消已完成，但包裹回池数量在 120 秒内未达到预期，已暂停')
    def batches(self,p,minimum,maximum,tab,tail):
        base=aisle_pairs(p.zone_types)
        for _,virtuals in variants(p):
            cursor=0
            while True:
                end=min(cursor+self.cfg['initial_aisles'],len(base)) if p.grouped else len(base)
                while True:
                    pairs=base[cursor:end];item=self.query(p,pairs,virtuals,minimum,maximum,tab)
                    if item['total_packages']<self.cfg['min_packages'] and p.grouped and end<len(base): end+=1;continue
                    break
                if item['total_packages'] and (tail or item['total_packages']>=self.cfg['min_packages']):
                    yield pairs,virtuals,item
                if not p.grouped or end>=len(base):break
                cursor=end
    def release(self,kind,minimum,maximum,tail):
        for p in scoped_phases(kind):
            for pairs,virtuals,item in self.batches(p,minimum,maximum,'One item only',tail):
                self.write(p,pairs,virtuals,item,'release_'+kind,minimum,maximum,'One item only')
        self.fallback(kind,minimum,maximum)
    def release_multis(self):
        # Clean-up Multis handles all three multi categories in one submission.
        phases=[replace(p,grouped=p.zone_types==['Box']) for p in default_phases() if p.kind=='multis']
        for p in phases:
            for tab in ('All',):
                for pairs,virtuals,item in self.batches(p,None,None,tab,True):
                    self.write(p,pairs,virtuals,item,'release_multis',None,None,tab)
        self.fallback('multis',None,None)
    def release_top(self,mode):
        if mode=='last': return self.release('top',6,999,True)
        global_phase=Phase(101,'爆品目标查询','top',[],[],'Top Selling - Single')
        threshold,counts=candidate_threshold(lambda n:self.query(global_phase,[],[],n,999,'One item only')['total_packages'],2000)
        self.run['top_threshold']=threshold;self.run['threshold_queries']=counts;self.persist()
        if threshold is None:return
        for p in scoped_phases('top'):
            for pairs,virtuals,item in self.batches(p,threshold,999,'One item only',True):
                remaining=2000-self.run['top_released']
                if item['total_packages']>remaining:
                    # Never split a SKU/order group by arbitrary row clicks.
                    self.run.setdefault('deferred_top',[]).append(item);self.persist();continue
                self.write(p,pairs,virtuals,item,'release_top',threshold,999,'One item only')
        self.fallback('top',threshold,999)
    def fallback(self,kind,minimum,maximum):
        """One global pass per class; never loop on newly arriving orders."""
        strategy={'multis':'Clean-up Multis','single':'Clean-up Single','top':'Top Selling - Single'}[kind]
        p=Phase(104,'全仓剩余兜底 / '+kind,kind,[],[],strategy)
        tabs=('All',) if kind=='multis' else ('One item only',)
        for tab in tabs:
            item=self.query(p,[],[],minimum,maximum,tab)
            count=item['total_packages']
            if not count: continue
            if kind=='top' and self.run['mode']=='first' and count>2000-self.run['top_released']:
                self.run.setdefault('deferred_top',[]).append(item);self.persist();continue
            self.write(p,[],[],item,'release_'+kind,minimum,maximum,tab)
    def audit(self):
        p=Phase(102,'剩余检查','single',[],[],'')
        remaining={}
        for tab in MULTI_TABS:
            remaining[tab]=self.query(p,[],[],None,None,tab)['total_packages']
        remaining['single_1_5']=self.query(p,[],[],1,5,'One item only')['total_packages']
        remaining['top_6_999']=self.query(p,[],[],6,999,'One item only')['total_packages']
        remaining['over_999_manual']=self.query(p,[],[],1000,None,'One item only')['total_packages']
        self.run['remaining']=remaining;self.persist()
        if any(remaining[t] for t in MULTI_TABS):
            raise RuntimeError('Multis 仍有残留（可能跨高低位或仓区未匹配），已暂停；请查看剩余记录，不会宣告全部放完')
        if self.run['mode']=='last' and (remaining['single_1_5'] or remaining['top_6_999']):
            raise RuntimeError('尾波仍有区域未匹配或新到包裹，已暂停；请查看剩余记录')
