"""Three-round orchestration with durable, exact-wave ownership and receipts."""
import copy
import datetime as dt
import uuid
import time
import math
import json
from dataclasses import replace
from .core import Phase, default_phases, aisle_pairs, variants

MULTI_TABS = ('Multiple units (same SKU)', 'Multiple units (mixed SKUs)', 'Multi Items Multi Pieces')
ROUND_NAMES = {'first':'首波','last':'尾波','flex':'Flex'}

def legacy_steps(mode):
    if mode not in ('first','second','last'): raise ValueError('未知放单策略')
    steps=[('hold_top','隔离爆品')]
    if mode=='first':
        steps += [('hold_single','暂存普通 Single'),('multis','按区域 / 巷道释放全部 Multis'),
                  ('cancel_single','取消本轮 Single 暂存'),('single','按区域 / 巷道释放 Single（1–3）'),
                  ('cancel_top','取消爆品暂存'),('top','按区域 / 巷道释放爆品（最多 2000 包）')]
    else:
        steps += [('single','按区域 / 巷道释放全部普通 Single'),('multis','按区域 / 巷道释放全部 Multis')]
        if mode=='last': steps += [('cancel_top','取消爆品暂存'),('top','按区域 / 巷道释放全部爆品（6–999）')]
    return steps+[('audit','核验结果与剩余包裹')]

def flex_phases():
    return {f'{kind}_{zone}_{level}': p
            for kind in ('top','single','multis')
            for p in scoped_phases(kind) if len(p.virtual_zones)==1 and len(p.zone_types)==1
            for zone,level in [(p.zone_types[0].lower(),p.virtual_zones[0][-1].lower())] if p.zone_types} | {
            f'{kind}_ground': scoped_phases(kind)[0] for kind in ('top','single','multis')}

def steps_for(mode):
    if mode=='first':
        return [('top','先释放爆品（最多 1500 包）'),('hold_top','锁定剩余爆品'),
                ('hold_single','锁定 Single'),('multis','分区释放 Multis'),
                ('cancel_single','解除 Single 锁定'),('single','分区释放 Single（1–4）'),
                ('cancel_top','解除爆品锁定')]
    if mode=='last':
        return [('cancel_top','解除已有爆品锁定'),('top','分区释放爆品（6–999）'),
                ('cancel_single','解除已有 Single 锁定'),('single','分区释放 Single（不限制件数）'),
                ('multis','分区释放 Multis'),('audit','核验剩余包裹')]
    if mode=='flex':
        phases=flex_phases()
        keys=[f'{kind}_{scope}' for kind in ('top','single','multis')
              for scope in ('ground','pallet_l','pallet_h','box_l','box_h','bin_l','bin_h')]
        return [('hold_top','锁定爆品（全仓 6–999）'),('hold_single','锁定 Single（全仓）'),
                ('cancel_top','解除已记录的爆品锁定'),('cancel_single','解除已记录的 Single 锁定')]+[(k,phases[k].name) for k in keys]
    raise ValueError('未知放单策略')

def run_steps(run):
    return steps_for(run['mode']) if run.get('plan_version')==2 else legacy_steps(run['mode'])

def selected_steps(mode, selection=None):
    keys=[k for k,_ in steps_for(mode)]
    if selection is None:
        if mode=='flex':raise ValueError('Flex 请选择至少一个操作或释放区域')
        return keys
    if not isinstance(selection,list) or not selection or any(not isinstance(k,str) or k not in keys for k in selection) or len(set(selection))!=len(selection):
        raise ValueError('请选择至少一个有效节点，不可重复')
    return [k for k in keys if k in selection]

def finish_checkpoint(run, checkpoint):
    if checkpoint:
        state=run.setdefault('batch_progress',{}).setdefault(checkpoint['key'],{})
        state.update(checkpoint['after'])
        run.pop('current_batch',None)

class NodeLimitReached(Exception): pass

def scoped_phases(kind):
    return [replace(p,grouped=p.zone_types==['Box']) for p in default_phases() if p.kind==kind and p.id not in (12,13)]

def candidate_threshold(query, budget, floor=6):
    """Maximize cumulative packages without exceeding budget; reads only.

    Start at 100. Search downward if there is room and upward if already over budget.
    Requery the chosen threshold before any submission because WMS is dynamic.
    """
    counts={}
    def count(n):
        if n not in counts: counts[n]=query(n)
        return counts[n]
    start=count(100)
    lo,hi=(floor,100) if start<=budget else (101,999)
    best=100 if 0<start<=budget else None
    while lo<=hi:
        mid=(lo+hi)//2; n=count(mid)
        if n<=budget:
            if n>0: best=mid
            hi=mid-1
        else: lo=mid+1
    # A changing result must never cause a submission above the remaining budget.
    return best, counts

class RoundRunner:
    def __init__(self,browser,ledger,save,progress,stop,config):
        self.b=browser;self.data=ledger;self.save=save;self.progress=progress;self.stop=stop;self.cfg=config
        self.data.setdefault('waves',[]);self.data.setdefault('runs',[])
    @property
    def minimum_release(self): return max(30,self.cfg['min_packages'])
    def activity(self,action,status='running',**detail):
        if hasattr(self,'step'):
            self.progress(*self.step,status,{'scope':getattr(self,'scope',''),'action':action,**detail})
    def defer(self,item):
        if hasattr(self,'run'):
            self.run.setdefault('deferred_batches',[]).append(item);self.persist()
        self.activity('不足最低包裹数，留待后续处理','deferred',packages=item['total_packages'])
    def persist(self): self.save(self.data)
    def check(self):
        if self.stop.is_set(): raise RuntimeError('已停止；已创建波次保留在台账中，不会自动重试')
    def holds(self,purpose):
        return [w for w in self.data['waves'] if w['purpose']==purpose and w['state']=='held' and w['creator']==self.creator and w.get('warehouse')==self.warehouse]
    def resume(self):
        if self.data.get('pending'):raise RuntimeError('请先核验待处理波次')
        runs=[r for r in self.data['runs'] if r['status'] in ('paused','running')]
        if len(runs)==1 and runs[0].get('error')=='提交前包裹数发生变化，已暂停；本批尚未提交':
            keys=[key for key,_ in run_steps(runs[0])]
            index=runs[0].get('next_step',0)
            if 0<=index<len(keys) and keys[index] in ('hold_top','hold_single'):
                runs[0]['resume_ready']=True
        if len(runs)==1 and runs[0].get('error','').startswith(('已停止，尚未点击最终 OK','已停止，尚未提交','已停止；已创建波次保留')):
            runs[0]['resume_ready']=True
        if len(runs)==1 and runs[0].get('batch_progress') is not None: runs[0]['resume_ready']=True
        if len(runs)!=1 or not runs[0].get('resume_ready'):raise RuntimeError('当前暂停位置不支持自动续跑')
        self.run=runs[0]
        self.creator,self.warehouse=self.b.identity()
        if (self.creator,self.warehouse)!=(self.run['creator'],self.run['warehouse']):raise RuntimeError('续跑账号或仓库不一致')
        if hasattr(self.b,'dismiss_unsubmitted_dialog'):self.b.dismiss_unsubmitted_dialog()
        self.run['status']='running';self.run['resume_ready']=False;self.persist()
        self.execute(self.run['mode'],resuming=True)

    def execute(self,mode,resuming=False,selection=None,release_limit=0):
        if self.data.get('pending'): raise RuntimeError('存在结果不明的操作，请先到 WMS 核对；禁止重复执行')
        if not resuming:
            chosen=selected_steps(mode,selection)
            if type(release_limit) is not int or not 0<=release_limit<=1000:raise ValueError('节点汇波批次上限须为 0–1000')
            if any(r['status'] in ('running','paused') for r in self.data['runs']):
                raise RuntimeError('上一轮未结束。请先核对台账并结束该轮，再启动新一轮')
            self.creator,self.warehouse=self.b.identity()
            self.run={'id':uuid.uuid4().hex,'plan_version':2,'mode':mode,'creator':self.creator,'warehouse':self.warehouse,'status':'running','top_released':0,'selected_steps':chosen,'release_limit':release_limit,'node_status':{},'node_submissions':{},'batch_progress':{},'started':dt.datetime.now(dt.timezone.utc).isoformat()}
            self.data['runs'].append(self.run);self.persist()
        try:
            for index,(key,title) in enumerate(run_steps(self.run)):
                if index<self.run.get('next_step',0):continue
                if key not in self.run.get('selected_steps',[k for k,_ in run_steps(self.run)]):
                    self.run.setdefault('node_status',{})[key]='skipped';self.run['next_step']=index+1;self.persist();self.progress(index,key,title,'skipped',{});continue
                self.run['resume_ready']=False;self.run.setdefault('node_status',{})[key]='running';self.persist()
                self.active_batch=None
                self.run['next_step']=index;self.step=(index,key,title);self.persist();self.check();self.progress(index,key,title,'running',{})
                limited=False
                try:
                    if (key in ('single','multis','top') or key in flex_phases()) and self.run.get('release_limit',0) and self.run.get('node_submissions',{}).get(key,0)>=self.run['release_limit']:raise NodeLimitReached()
                    if key=='hold_top': self.hold('top',6,999)
                    elif key=='hold_single': self.hold('single',None,None)
                    elif key=='cancel_single': self.cancel('single')
                    elif key=='cancel_top': self.cancel('top')
                    elif key=='single':
                        lo,hi=(1,4) if mode=='first' else (None,None)
                        if self.run.get('plan_version')!=2:lo,hi=1,3 if mode=='first' else 5
                        self.release('single',lo,hi,True)
                    elif key=='multis': self.release_multis()
                    elif key=='top': self.release_top(mode)
                    elif key=='audit': self.audit()
                    elif mode=='flex' and key in flex_phases(): self.release_flex(key)
                except NodeLimitReached:
                    limited=True
                self.run['node_status'][key]='limited' if limited else 'done'
                self.run['next_step']=index+1;self.run['resume_ready']=True;self.persist()
                self.progress(index,key,title,'limited' if limited else 'done',{})
            self.run['status']='complete';self.persist()
        except Exception as exc:
            if hasattr(self,'step'):self.run.setdefault('node_status',{})[self.step[1]]='paused'
            self.run['resume_ready']=not bool(self.data.get('pending'))
            self.run['status']='paused';self.run['error']=str(exc);self.activity(str(exc),'paused');self.persist();raise
    def query(self,p,pairs,virtuals,minimum=None,maximum=None,tab=None):
        self.check()
        self.scope=p.name+' · '+('/'.join(virtuals) or '全仓')+' · '+(','.join(str(n)+'–'+str(n+1) for n in pairs) or '整区')
        if p.id in (101,102):self.scope+=' · '+str(tab)+' · '+str(minimum)+'–'+str(maximum)
        if hasattr(self,'run'):
            self.run.setdefault('current_batch',{}).update(scope=self.scope,aisles=list(pairs),virtual_zones=list(virtuals));self.persist()
        self.activity('查询包裹',aisles=list(pairs),virtual_zones=virtuals)
        query_started=time.monotonic()
        # Recovery is restricted to reads with no unresolved write intent.
        from playwright.sync_api import TimeoutError as PlaywrightTimeout
        interval=max(0,int(self.cfg.get('refresh_every_queries',0)))
        count=getattr(self,'query_count',0)
        if interval and count and count % interval == 0 and not self.data.get('pending'):
            self.recover_query(False)
        for attempt in range(3):
            self.check()
            try:
                result=self.b.query(p,pairs,virtuals,self.cfg,quantity=(minimum,maximum),tab_override=tab)
                break
            except (PlaywrightTimeout, RuntimeError) as exc:
                cause=exc
                while cause.__cause__ is not None: cause=cause.__cause__
                transient=isinstance(cause,PlaywrightTimeout) or str(exc)=='查询结果未稳定，已停止'
                if not transient or self.data.get('pending') or attempt==2: raise
                self.recover_query(attempt==1)
        self.query_count=count+1
        if hasattr(self,'step'):
            index,key,title=self.step
            self.activity('查询完成',aisles=list(pairs),virtual_zones=virtuals,packages=result['total_packages'],query_seconds=round(time.monotonic()-query_started,2))
        return result
    def recover_query(self,reopen):
        self.check()
        if self.data.get('pending'): raise RuntimeError('存在未核验操作，禁止刷新重试')
        if hasattr(self,'step'):
            index,key,title=self.step
            self.progress(index,key,title,'running',{'scope':'重新打开页面并恢复筛选' if reopen else '清理浏览器缓存并刷新页面'})
        self.b.recover_query_page(reopen=reopen)
        if self.b.identity()!=(self.creator,self.warehouse):
            raise RuntimeError('恢复页面后账号或仓库已改变，已暂停')
        self.check()
    def write(self,p,pairs,virtuals,item,purpose,minimum=None,maximum=None,tab=None):
        self.check()
        if self.b.identity()!=(self.creator,self.warehouse):raise RuntimeError('执行账号或仓库已改变，尚未提交')
        if getattr(self.b,'preserves_query_for_receipts',False):
            if not hasattr(self,'receipt_baseline'):self.receipt_baseline=self.b.wave_snapshot(self.creator)
            baseline=self.receipt_baseline
            current=item
        else:
            baseline=self.b.wave_snapshot(self.creator)
            current=self.query(p,pairs,virtuals,minimum,maximum,tab)
        # Orders arrive continuously; submit the latest search, without comparing counts.
        if current['total_packages']==0:return
        if purpose.startswith('release_') and current['total_packages']<self.minimum_release:
            self.defer(current);return
        if purpose=='release_top' and self.run['mode']=='first' and self.run['top_released']+current['total_packages']>self.top_budget:
            self.run.setdefault('deferred_top',[]).append(current);self.persist();self.activity('超过本轮爆品剩余额度，留置','deferred',packages=current['total_packages']);return
        intent={'kind':'create','run_id':self.run['id'],'creator':self.creator,'warehouse':self.warehouse,'purpose':purpose,'packages':current['total_packages'],'baseline':baseline,'started':dt.datetime.now(dt.timezone.utc).isoformat(),'query':current,'checkpoint':copy.deepcopy(getattr(self,'active_batch',None)),'step_key':self.step[1] if hasattr(self,'step') else None}
        def before():
            self.check();self.data['pending']=intent;self.persist()
        self.activity('提交汇波',packages=current['total_packages'])
        self.b.consolidate(p.strategy,before,self.stop,receipt_via_table=True)
        self.activity('等待 WMS 生成波次',packages=current['total_packages'])
        rows=self.b.wait_new_waves(intent,self.stop)
        self.receipt_baseline=[*baseline,*rows]
        actual=sum(r['packages'] for r in rows)
        if actual!=intent['packages']:
            self.run.setdefault('quantity_differences',[]).append({'expected':intent['packages'],'actual':actual,'waves':[r['wave_number'] for r in rows]})
            if hasattr(self,'step'):self.progress(*self.step,'running',{'scope':'数量差异仅记录，已核验新波次','packages':actual})
        for row in rows:
            self.data['waves'].append({**row,'warehouse':self.warehouse,'run_id':self.run['id'],'purpose':purpose,'state':'held' if purpose in ('top','single') else 'released'})
        if purpose=='release_top': self.run['top_released']+=sum(r['packages'] for r in rows)
        finish_checkpoint(self.run,intent.get('checkpoint'))
        if purpose.startswith('release_') and hasattr(self,'step'):
            key=self.step[1];counts=self.run.setdefault('node_submissions',{});counts[key]=counts.get(key,0)+1
        self.data['pending']=None;self.persist()
        self.activity('已生成波次','done',packages=actual,waves=[r['wave_number'] for r in rows])
        if purpose.startswith('release_') and hasattr(self,'step'):
            key=self.step[1];counts=self.run['node_submissions']
            limit=self.run.get('release_limit',0)
            if limit and counts[key]>=limit:raise NodeLimitReached()
    def hold(self,kind,minimum,maximum):
        # Existing tracked holds remain isolated; this catches newly arrived packages.
        p=Phase(100,'暂存 '+kind,'single',[],[],'Top Selling - Single' if kind=='top' else 'Clean-up Single')
        item=self.query(p,[],[],minimum,maximum,'One item only')
        if item['total_packages']:
            self.write(p,[],[],item,kind,minimum,maximum,'One item only')
        else:self.activity('无可处理包裹','done',packages=0)
    def cancel(self,purpose):
        owned=list(self.holds(purpose))
        if not owned:return
        if self.b.identity()!=(self.creator,self.warehouse):raise RuntimeError('取消前账号或仓库已改变')
        existing={r['wave_number']:r for r in self.b.wave_snapshot(self.creator)}
        for wave in owned:
            if existing.get(wave['wave_number'],{}).get('status')=='Canceled':wave['state']='canceled'
        self.persist();owned=[w for w in owned if w['state']=='held']
        if not owned:return
        for wave in owned:
            self.scope=wave['wave_number'];self.activity('取消暂存波次')
            self.check()
            intent={'kind':'cancel','run_id':self.run['id'],'wave':copy.deepcopy(wave),'creator':self.creator,'warehouse':self.warehouse}
            def before():
                self.check();self.data['pending']=intent;self.persist()
            self.b.cancel_owned_wave(wave,before,self.stop)
            wave['state']='canceled';self.data['pending']=None;self.persist()
            self.activity('暂存已取消','done',packages=wave['packages'])
    @property
    def top_budget(self): return 1500 if self.run.get('plan_version')==2 else 2000
    def batch_state(self,p,virtuals,minimum,maximum,tab):
        key=json.dumps([self.step[1] if hasattr(self,'step') else p.kind,p.id,virtuals,minimum,maximum,tab],ensure_ascii=False)
        state=self.run.setdefault('batch_progress',{}).setdefault(key,{}) if hasattr(self,'run') else {}
        return key,state
    def prepare_batch(self,key,after,pairs,virtuals):
        self.active_batch={'key':key,'after':after}
        if hasattr(self,'run'):
            self.run['current_batch']={'checkpoint':copy.deepcopy(self.active_batch),'aisles':list(pairs),'virtual_zones':list(virtuals),'scope':getattr(self,'scope','')}
            self.persist()
    def finish_batch(self):
        if hasattr(self,'run'):
            finish_checkpoint(self.run,getattr(self,'active_batch',None));self.persist()
        self.active_batch=None
    def batches(self,p,minimum,maximum,tab,tail):
        base=aisle_pairs(p.zone_types)
        for _,virtuals in variants(p):
            key,state=self.batch_state(p,virtuals,minimum,maximum,tab)
            if state.get('done'):continue
            if 'width' not in state:
                whole=self.query(p,[],virtuals,minimum,maximum,tab)
                total=whole['total_packages']
                if total<self.minimum_release:
                    self.defer(whole);state['done']=True;self.persist();continue
                groups=min(math.ceil(len(base)/self.cfg['initial_aisles']),max(1,total//(2*self.minimum_release))) if p.grouped else 1
                state.update(width=math.ceil(len(base)/groups) if groups>1 else 0,cursor=0)
                self.persist()
            else:whole=None
            if state['width']==0:
                self.prepare_batch(key,{'done':True},[],virtuals)
                item=whole if whole is not None else self.query(p,[],virtuals,minimum,maximum,tab)
                if item['total_packages']>=self.minimum_release:yield [],virtuals,item
                else:self.defer(item)
                self.finish_batch();continue
            width=state['width'];cursor=state.get('cursor',0)
            while cursor<len(base):
                end=state.get('end',min(cursor+width,len(base)))
                while True:
                    state['end']=end;self.persist()
                    pairs=base[cursor:end]
                    self.prepare_batch(key,{'cursor':end,'end':min(end+width,len(base)),'done':end==len(base)},pairs,virtuals)
                    item=self.query(p,pairs,virtuals,minimum,maximum,tab)
                    if item['total_packages']>=self.minimum_release or end==len(base):break
                    end=min(len(base),cursor+2*(end-cursor))
                    self.activity('包裹不足，成倍扩大 Box 范围',packages=item['total_packages'],aisles=base[cursor:end])
                if item['total_packages']>=self.minimum_release:yield pairs,virtuals,item
                else:self.defer(item)
                state.update(cursor=end,end=min(end+width,len(base)),done=end==len(base))
                self.finish_batch();cursor=end
    def release_flex(self,key):
        p=flex_phases()[key]
        minimum,maximum,tab=(6,999,'One item only') if p.kind=='top' else ((1,5,'One item only') if p.kind=='single' else (None,None,'All'))
        # Flex is deliberately limited to selected scopes: no unselected-zone fallback.
        for pairs,virtuals,item in self.batches(p,minimum,maximum,tab,True):
            self.write(p,pairs,virtuals,item,'release_'+p.kind,minimum,maximum,tab)
    def release(self,kind,minimum,maximum,tail):
        for p in scoped_phases(kind):
            for pairs,virtuals,item in self.batches(p,minimum,maximum,'One item only',tail):
                self.write(p,pairs,virtuals,item,'release_'+kind,minimum,maximum,'One item only')
        self.fallback(kind,minimum,maximum)
    def release_multis(self):
        # Clean-up Multis handles all three multi categories in one submission.
        phases=[replace(p,grouped=p.zone_types==['Box']) for p in default_phases() if p.kind=='multis']
        for p in phases:
            for tab in ('All',):
                for pairs,virtuals,item in self.batches(p,None,None,tab,True):
                    self.write(p,pairs,virtuals,item,'release_multis',None,None,tab)
        self.fallback('multis',None,None)
    def release_top(self,mode):
        if mode=='last': return self.release('top',6,999,True)
        global_phase=Phase(101,'爆品目标查询','top',[],[],'Top Selling - Single')
        if 'top_threshold' not in self.run:
            threshold,counts=candidate_threshold(lambda n:self.query(global_phase,[],[],n,999,'One item only')['total_packages'],self.top_budget)
            self.run['top_threshold']=threshold;self.run['threshold_queries']=counts;self.persist()
        threshold=self.run['top_threshold']
        if threshold is None:return
        for p in scoped_phases('top'):
            for pairs,virtuals,item in self.batches(p,threshold,999,'One item only',True):
                remaining=self.top_budget-self.run['top_released']
                if item['total_packages']>remaining:
                    # Never split a SKU/order group by arbitrary row clicks.
                    self.run.setdefault('deferred_top',[]).append(item);self.persist();continue
                self.write(p,pairs,virtuals,item,'release_top',threshold,999,'One item only')
        self.fallback('top',threshold,999)
    def fallback(self,kind,minimum,maximum):
        """One global pass per class; never loop on newly arriving orders."""
        strategy={'multis':'Clean-up Multis','single':'Clean-up Single','top':'Top Selling - Single'}[kind]
        p=Phase(104,'全仓剩余兜底 / '+kind,kind,[],[],strategy)
        tabs=('All',) if kind=='multis' else ('One item only',)
        for tab in tabs:
            key,state=self.batch_state(p,[],minimum,maximum,tab)
            if state.get('done'):continue
            self.prepare_batch(key,{'done':True},[],[])
            item=self.query(p,[],[],minimum,maximum,tab)
            count=item['total_packages']
            if count<self.minimum_release:
                self.defer(item);self.finish_batch();continue
            if kind=='top' and self.run['mode']=='first' and count>self.top_budget-self.run['top_released']:
                self.run.setdefault('deferred_top',[]).append(item);self.finish_batch();continue
            self.write(p,[],[],item,'release_'+kind,minimum,maximum,tab)
            self.finish_batch()
    def audit(self):
        p=Phase(102,'剩余检查','single',[],[],'')
        remaining={}
        for tab in MULTI_TABS:
            remaining[tab]=self.query(p,[],[],None,None,tab)['total_packages']
        remaining['single_1_5']=self.query(p,[],[],1,5,'One item only')['total_packages']
        remaining['top_6_999']=self.query(p,[],[],6,999,'One item only')['total_packages']
        remaining['over_999_manual']=self.query(p,[],[],1000,None,'One item only')['total_packages']
        self.run['remaining']=remaining;self.persist()
        self.activity('剩余数量已记录，本轮结束','done',remaining=remaining)
