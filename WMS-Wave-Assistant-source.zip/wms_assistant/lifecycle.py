"""Windows owns all child processes in a kill-on-close Job Object.

The OS closes this handle even if the workspace is terminated or crashes.
Only this process tree is affected, never an unrelated Chrome session.
"""
import sys
_job=None

def own_process_tree():
    global _job
    if sys.platform!='win32' or _job:return
    import ctypes as c
    from ctypes import wintypes as w
    class Basic(c.Structure):
        _fields_=[('per_process',c.c_longlong),('per_job',c.c_longlong),('flags',w.DWORD),
            ('min_working',c.c_size_t),('max_working',c.c_size_t),('active',w.DWORD),
            ('affinity',c.c_size_t),('priority',w.DWORD),('scheduling',w.DWORD)]
    class IO(c.Structure):
        _fields_=[(name,c.c_ulonglong) for name in ('read_ops','write_ops','other_ops','read_bytes','write_bytes','other_bytes')]
    class Extended(c.Structure):
        _fields_=[('basic',Basic),('io',IO),('process_memory',c.c_size_t),('job_memory',c.c_size_t),('peak_process',c.c_size_t),('peak_job',c.c_size_t)]
    k=c.WinDLL('kernel32',use_last_error=True)
    k.CreateJobObjectW.argtypes=[c.c_void_p,w.LPCWSTR];k.CreateJobObjectW.restype=w.HANDLE
    k.SetInformationJobObject.argtypes=[w.HANDLE,c.c_int,c.c_void_p,w.DWORD];k.SetInformationJobObject.restype=w.BOOL
    k.AssignProcessToJobObject.argtypes=[w.HANDLE,w.HANDLE];k.AssignProcessToJobObject.restype=w.BOOL
    k.GetCurrentProcess.restype=w.HANDLE
    k.CloseHandle.argtypes=[w.HANDLE]
    handle=k.CreateJobObjectW(None,None)
    if not handle:raise c.WinError(c.get_last_error())
    info=Extended();info.basic.flags=0x2000 # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
    if not k.SetInformationJobObject(handle,9,c.byref(info),c.sizeof(info)) or not k.AssignProcessToJobObject(handle,k.GetCurrentProcess()):
        error=c.get_last_error();k.CloseHandle(handle);raise c.WinError(error)
    _job=handle # Intentionally held for the full lifetime of this process.
