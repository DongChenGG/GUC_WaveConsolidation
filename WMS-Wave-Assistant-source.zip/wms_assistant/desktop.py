"""Desktop workspace, compact monitor and Windows notification-area controls."""
import sys
import threading
from pathlib import Path

ASSETS=Path(__file__).with_name('assets')

class WindowAPI:
    def __init__(self,controls):self._controls=controls
    def compact(self):self._controls.compact()
    def quit(self):self._controls.quit()
    def expand(self):self._controls.expand()
    def hide_monitor(self):self._controls.hide_monitor()
    def pin(self,value):self._controls.pin(value)
    def set_sound(self,value):self._controls.set_sound(value)

class DesktopControls:
    def __init__(self,stop):
        self.stop=stop;self.main=None;self.mini=None;self.tray=None
        self.exiting=False;self.sound=False;self.closed=threading.Event()
    def compact(self):
        self.mini.show();self.mini.restore();self.main.hide()
    def expand(self):
        self.main.show();self.main.restore();self.mini.hide()
    def hide_monitor(self):
        if self.tray:self.mini.hide()
        else:self.expand()
    def pin(self,value):
        self.mini.on_top=bool(value)
    def set_sound(self,value):
        self.sound=bool(value)
    def close_main(self):
        if self.exiting:return True
        self.compact();return False
    def close_mini(self):
        if self.exiting:return True
        self.hide_monitor();return False
    def quit(self):
        self.exiting=True;self.stop.set();self.closed.set()
        if self.tray:self.tray.stop()
        self.mini.destroy();self.main.destroy()
    def notify(self,message):
        if self.tray:
            try:self.tray.notify(message,'WMS Wave Assistant')
            except Exception:pass
        if self.sound and sys.platform=='win32':
            import winsound
            winsound.MessageBeep()
    def background(self):
        if sys.platform=='win32':
            try:
                import pystray
                from PIL import Image
                tray=pystray.Icon('wms-wave',Image.open(ASSETS/'wave.png'),'WMS Wave Assistant',pystray.Menu(
                    pystray.MenuItem('工作台 / Abrir',lambda:self.expand(),default=True),
                    pystray.MenuItem('监控小窗 / Monitor',lambda:self.compact()),
                    pystray.MenuItem('退出 / Salir',lambda:self.quit())))
                tray.run_detached();self.tray=tray
            except Exception:
                # Keep a visible window if the notification area is unavailable.
                self.tray=None
        from . import app
        seen=set()
        while not self.closed.wait(1):
            try:
                with app.LOCK:
                    ledger=app.round_ledger();run=ledger['runs'][-1] if ledger['runs'] else None
                    busy=app.STATE['busy'];message=app.STATE.get('message','')
                if not run:continue
                status=run['status']
                token=(run['id'],status,run.get('error',''))
                if status in ('paused','complete') and not busy and token not in seen:
                    seen.add(token)
                    self.notify(('已暂停 / Pausado: ' if status=='paused' else '已完成 / Completado: ')+(run.get('error',message) if status=='paused' else run['mode']))
                for key,target in run.get('package_targets',{}).items():
                    event=(run['id'],'target',key)
                    if target and run.get('node_status',{}).get(key) in ('done','limited') and event not in seen:
                        seen.add(event);self.notify(f"区域完成 / Zona completa: {key} {run.get('node_packages',{}).get(key,0)} / {target}")
                if status=='running':seen.discard((run['id'],'paused',run.get('error','')))
            except Exception:continue


def show_desktop(url,storage,stop):
    import webview
    storage.mkdir(parents=True,exist_ok=True)
    controls=DesktopControls(stop)
    controls.main=webview.create_window('WMS Wave Assistant · v0.8.0',url,js_api=WindowAPI(controls),
        width=1380,height=940,min_size=(1000,700),background_color='#f3f6fa',text_select=True)
    controls.mini=webview.create_window('WMS Monitor',url+'/monitor',js_api=WindowAPI(controls),
        width=390,height=390,min_size=(350,350),hidden=True,on_top=True,background_color='#101116')
    controls.main.events.closing+=controls.close_main
    controls.main.events.minimized+=controls.compact
    controls.mini.events.closing+=controls.close_mini
    try:
        webview.start(controls.background,gui='edgechromium' if sys.platform=='win32' else None,
            private_mode=False,storage_path=str(storage),icon=str(ASSETS/'wave.ico'))
    finally:
        controls.closed.set();stop.set()
        if controls.tray:controls.tray.stop()


def desktop_self_test():
    """Two real native windows and compact/restore/pin, without WMS access."""
    import webview
    c=DesktopControls(threading.Event());outcome=[];ready=set();lock=threading.Lock()
    c.main=webview.create_window('WMS desktop test',html='<p id="ready">READY</p>',js_api=WindowAPI(c),width=600,height=400)
    c.mini=webview.create_window('WMS monitor test',html='<p id="ready">MONITOR</p>',js_api=WindowAPI(c),width=390,height=390,hidden=True,on_top=True)
    def loaded(name):
        with lock:
            ready.add(name)
            if len(ready)!=2:return
        try:
            c.compact();c.pin(False);c.pin(True)
            outcome.append(c.mini.evaluate_js('document.getElementById("ready").textContent')=='MONITOR')
            c.expand()
            outcome.append(c.main.evaluate_js('document.getElementById("ready").textContent')=='READY')
        finally:c.quit()
    c.main.events.loaded+=lambda:loaded('main')
    c.mini.events.loaded+=lambda:loaded('mini')
    timer=threading.Timer(60,c.quit);timer.daemon=True;timer.start()
    try:webview.start(gui='edgechromium' if sys.platform=='win32' else None,icon=str(ASSETS/'wave.ico'))
    finally:timer.cancel()
    if outcome!=[True,True]:raise RuntimeError('Native workspace/monitor test failed')
