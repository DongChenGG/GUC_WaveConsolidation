"""Native application shell. WMS automation stays in its dedicated browser."""
import sys
import threading


def show_desktop(url, storage, stop):
    import webview
    storage.mkdir(parents=True, exist_ok=True)
    window = webview.create_window('WMS Wave Assistant · v0.5.3-test', url,
        width=1380, height=940, min_size=(1000,700), background_color='#f3f6fa', text_select=True)
    window.events.closing += lambda: stop.set()
    webview.start(gui='edgechromium' if sys.platform=='win32' else None,
                  private_mode=False, storage_path=str(storage))


def desktop_self_test():
    """Executed on the Windows runner against the frozen EXE, no WMS access."""
    import webview
    outcome=[]
    window=webview.create_window('WMS desktop test', html='<html><title>WMS native test</title><body><p id="ready">READY</p></body></html>', width=600,height=400)
    def loaded():
        try:
            outcome.append(window.evaluate_js('document.getElementById("ready").textContent')=='READY')
        finally:
            window.destroy()
    window.events.loaded += loaded
    timeout=threading.Timer(45,window.destroy)
    timeout.daemon=True
    timeout.start()
    try:
        webview.start(gui='edgechromium' if sys.platform=='win32' else None)
    finally:
        timeout.cancel()
    if outcome != [True]:
        raise RuntimeError('Native desktop WebView2 render test failed')
