"""Single native workspace. Closing the window exits the application."""
import sys
import threading
from pathlib import Path
ASSETS=Path(__file__).with_name('assets')

class WindowAPI:
    def __init__(self,controls):self._controls=controls
    def quit(self):self._controls.quit()

class DesktopControls:
    def __init__(self,stop):
        self.stop=stop;self.main=None;self.exiting=False
        self.closed=threading.Event()
    def close_main(self):
        self.exiting=True;self.stop.set();self.closed.set()
        return True
    def quit(self):
        if self.exiting:return
        self.close_main()
        if self.main:self.main.destroy()

def show_desktop(url,storage,stop):
    import webview
    storage.mkdir(parents=True,exist_ok=True)
    controls=DesktopControls(stop)
    controls.main=webview.create_window('WMS Wave Assistant · v0.8.2',url,js_api=WindowAPI(controls),
        width=1380,height=940,min_size=(1000,700),background_color='#f3f6fa',text_select=True)
    controls.main.events.closing+=controls.close_main
    try:
        webview.start(gui='edgechromium' if sys.platform=='win32' else None,
            private_mode=False,storage_path=str(storage),icon=str(ASSETS/'wave.ico'))
    finally:controls.close_main()

def desktop_self_test():
    import webview
    c=DesktopControls(threading.Event());outcome=[]
    c.main=webview.create_window('WMS desktop test',html='<p id="ready">READY</p>',js_api=WindowAPI(c),width=600,height=400)
    c.main.events.closing+=c.close_main
    def loaded():
        try:outcome.append(c.main.evaluate_js('document.getElementById("ready").textContent')=='READY')
        finally:c.quit()
    c.main.events.loaded+=loaded
    timer=threading.Timer(60,c.quit);timer.daemon=True;timer.start()
    try:webview.start(gui='edgechromium' if sys.platform=='win32' else None,icon=str(ASSETS/'wave.ico'))
    finally:timer.cancel()
    if outcome!=[True] or not c.stop.is_set():raise RuntimeError('Native workspace close test failed')
