"""Pure planning rules; never submits warehouse operations."""
from dataclasses import dataclass, asdict
from typing import List

TYPE_RANGES = {'Pallet': (124, 130), 'Box': (131, 178), 'Bin': (179, 191)}
OPERATORS = ('Include', 'Not included', 'Totally included', 'Equal')

@dataclass
class Phase:
    id: int
    name: str
    kind: str
    zone_types: List[str]
    virtual_zones: List[str]
    strategy: str
    grouped: bool = False
    manual: bool = False
    note: str = ''

    def to_dict(self):
        return asdict(self)

def aisle_pairs(types):
    pairs = set()
    for name in types:
        low, high = TYPE_RANGES[name]
        for shelf in range(low, high + 1):
            start = shelf if shelf % 2 == 0 else shelf - 1
            pairs.add(start)
    return sorted(pairs)

def zone_values(pairs):
    return [f'{n}-{n+1}-{half}' for n in pairs for half in (1, 2)]

def batches(pairs, width=3):
    if width < 1:
        raise ValueError('巷道数必须大于零')
    return [pairs[i:i + width] for i in range(0, len(pairs), width)]

def default_phases():
    out = []
    def add(name, kind, types, vz, strategy='', grouped=False, manual=False, note=''):
        out.append(Phase(len(out)+1, name, kind, types, vz, strategy, grouped, manual, note))
    def single_type(kind, strategy):
        for t in ('Pallet', 'Box', 'Bin'):
            for level in ('L', 'H'):
                add(f'货架 {t} {level} · {kind}', kind, [t], [f'TT {t.upper()} {level}'], strategy, False)
    add('地堆 Multis', 'multis', [], ['TTGROUND'], 'Clean-up Multis')
    single_type('multis', 'Clean-up Multis')
    for types in (['Pallet','Box'], ['Box','Bin']):
        for level in ('L','H'):
            add(f'{" + ".join(types)} {level} 混区 Multis', 'multis', types,
                [f'TT {t.upper()} {level}' for t in types], 'Clean-up Multis',
                note='整段查询。多选虚拟区不等于必须同时跨两区；精确语义待核验。')
    add('货架剩余混区 Multis · L/H 分开', 'multis', ['Pallet','Box','Bin'], [], 'Clean-up Multis',
        note='分别查询三个类型的 L 集合和 H 集合；不处理同包跨 L/H 的未定义归属。')
    add('全仓混区 Multis · L/H 分开', 'multis', [], [], 'Clean-up Multis',
        note='显式全仓收尾阶段。分别查询 TTGROUND + 全货架 L/H；多选匹配语义待核验。')
    add('核验 Multis 剩余', 'checkpoint', [], [], manual=True, note='核对未匹配、尾批、跨 L/H 和失败订单，不能仅凭阶段结束认定放完。')
    add('暂存爆品（人工）', 'hold', [], [], 'Top Selling - Single', manual=True,
        note='One item only，Package quantity 6–999。暂存占单与自动确认行为尚未验证，不自动创建。')
    add('地堆 Single', 'single', [], ['TTGROUND'], 'Clean-up Single')
    single_type('single', 'Clean-up Single')
    add('取消暂存波次（人工）', 'cancel', [], [], manual=True,
        note='只处理本轮记录的暂存波次，人工取消后核验包裹回池。禁止批量取消其他波次。')
    add('地堆 Top-selling Single', 'top', [], ['TTGROUND'], 'Top Selling - Single')
    single_type('top', 'Top Selling - Single')
    return out

def variants(phase):
    if phase.id in (12, 13):
        for level in ('L', 'H'):
            vs = [f'TT {t} {level}' for t in ('PALLET','BOX','BIN')]
            if phase.id == 13:
                vs.insert(0, 'TTGROUND')
            yield level, vs
    else:
        yield '', phase.virtual_zones

def default_config():
    return {'refresh_every_queries':40, 'min_packages':30, 'initial_aisles':3, 'zone_operator':'Totally included',
            'virtual_operator':'Totally included', 'operators_verified':True,
            'timezone':'America/New_York', 'schedules':[
                {'time':'09:00','label':'爆品可以开始陆续放单，请选择阶段并确认'},
                {'time':'12:00','label':'截单收尾提醒：开始时间/完成期限尚待确认，请检查全部残留'}]}

def validate_config(c):
    refresh=c.get('refresh_every_queries',40)
    if type(refresh) is not int or not 0<=refresh<=1000:
        raise ValueError('刷新间隔须为 0–1000；0 表示关闭定期刷新')
    if isinstance(c.get('min_packages'), bool) or not isinstance(c.get('min_packages'), int) or not 1 <= c['min_packages'] <= 1000000:
        raise ValueError('最低包裹数须为 1–1000000 的整数')
    if isinstance(c.get('initial_aisles'), bool) or not isinstance(c.get('initial_aisles'), int) or not 1 <= c['initial_aisles'] <= 34:
        raise ValueError('初始完整巷道数须为 1–34')
    if c.get('zone_operator') not in OPERATORS or c.get('virtual_operator') not in OPERATORS[:3]:
        raise ValueError('不支持的仓区匹配方式')
    if not isinstance(c.get('operators_verified'), bool):
        raise ValueError('匹配语义核验标记必须是布尔值')
    from zoneinfo import ZoneInfo
    ZoneInfo(c['timezone'])
    import re
    for s in c['schedules']:
        if not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',s['time']):
            raise ValueError('定时格式应为 HH:MM')
        if not isinstance(s['label'], str) or len(s['label']) > 300:
            raise ValueError('提醒内容无效')
    # Migrate legacy global choices: matching is now determined by each phase.
    return {**c, 'zone_operator':'Totally included',
            'virtual_operator':'Totally included', 'operators_verified':True}


def validate_phase(data, original):
    p = Phase(**data)
    if p.id != original.id or p.kind != original.kind or p.manual != original.manual:
        raise ValueError('阶段编号、类型和人工节点不可在此修改')
    if not isinstance(p.name,str) or not 1<=len(p.name)<=150:
        raise ValueError('阶段名称无效')
    if any(t not in TYPE_RANGES for t in p.zone_types):
        raise ValueError('类型只能为 Pallet / Box / Bin')
    if not isinstance(p.virtual_zones,list) or any(not isinstance(v,str) or len(v)>100 for v in p.virtual_zones):
        raise ValueError('虚拟区必须是准确名称列表')
    if p.strategy not in ('', 'Clean-up Multis','Clean-up Single','Singles(50)','Top Selling - Single','Top Selling - Multis'):
        raise ValueError('未知 picking strategy')
    if type(p.grouped) is not bool or len(p.note)>2000:
        raise ValueError('配置无效')
    return p


def phase_operators(phase, virtuals):
    """User policy: pure zones fully included; explicit cross-zone phases included."""
    mixed = phase.id in range(8,14) or len(phase.zone_types)>1 or len(virtuals)>1
    operator = 'Include' if mixed else 'Totally included'
    return 'Include', operator


# Stable IDs are retained for saved settings and submission receipts.
EXECUTION_ORDER = [15, *range(16, 23), *range(1, 15), *range(23, 31)]

def ordered_phases(phases):
    by_id = {p.id:p for p in phases}
    return [by_id[i] for i in EXECUTION_ORDER]
