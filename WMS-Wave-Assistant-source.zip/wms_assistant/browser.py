"""WMS UI adapter with explicit, single-attempt consolidation."""
import re
import time
from .core import zone_values

URL = 'https://wms-ttp.tiktokw.us/outbound/waveManagementInfo/wave-summary'

class WMSBrowser:
    def __init__(self, profile):
        from playwright.sync_api import sync_playwright
        self.pw = sync_playwright().start()
        self.context = self.pw.chromium.launch_persistent_context(str(profile), headless=False,
            viewport={'width':1600, 'height':1000}, accept_downloads=False)
        self.page = self.context.pages[0] if self.context.pages else self.context.new_page()
        self.page.goto(URL, wait_until='domcontentloaded')
        self.page.set_default_timeout(12000)

    def close(self):
        try:
            self.context.close()
        finally:
            self.pw.stop()

    def select(self, field, labels):
        if not labels:
            return
        box = self.page.locator('#'+field)
        box.click()
        for label in labels:
            # Only exact labels inside the dropdown opened by this control.
            list_id = box.get_attribute('aria-controls')
            if not list_id:
                raise RuntimeError(f'{field} 没有可识别的下拉列表；停止查询')
            # Ant-style listbox is virtualized; rendered option nodes expose titles.
            panel = self.page.locator('[class*="select-dropdown"]').filter(visible=True)
            option = panel.get_by_title(label, exact=True)
            exact = option.filter(visible=True)
            exact.wait_for(state='visible')
            if exact.count() != 1:
                raise RuntimeError(f'{field} 找不到唯一精确选项 {label!r}；未采用模糊匹配')
            exact.click()
            # Multiple dropdowns remain open; single dropdowns close.
        box.press('Escape')

    def set_operator(self, field, label):
        box = self.page.locator('#'+field)
        box.click()
        panel = self.page.locator('[class*="select-dropdown"]').filter(visible=True)
        option = panel.get_by_title(label, exact=True).filter(visible=True)
        if option.count() != 1:
            raise RuntimeError('无法唯一定位匹配方式 '+label)
        option.click()

    def query(self, phase, pairs, virtuals, config):
        p = self.page
        if 'wave-summary' not in p.url:
            p.goto(URL, wait_until='domcontentloaded')
        p.get_by_role('button', name='Reset', exact=True).wait_for(state='visible')
        p.get_by_role('button', name='Reset', exact=True).click()
        more = p.get_by_role('button', name='More', exact=True)
        if more.is_visible():
            more.click()
        tab = 'One item only' if phase.kind in ('single','top') else 'All'
        p.get_by_text(tab, exact=True).click()
        if phase.kind == 'top':
            p.get_by_role('spinbutton').nth(0).fill('6')
            p.get_by_role('spinbutton').nth(1).fill('999')
        if pairs:
            self.set_operator('zone_op_type', config['zone_operator'])
            self.select('inv_zone_list', zone_values(pairs))
        if virtuals:
            self.set_operator('logical_zone_op_type',config['virtual_operator'])
            self.select('logical_inv_zone_list', virtuals)
        # Require completion of a new read-only query response. We never read tokens,
        # issue private requests or assume stale totals are fresh results.
        def is_query_response(response):
            req = response.request
            return req.resource_type in ('xhr','fetch') and response.ok and 'wms-ttp.tiktokw.us' in response.url
        with p.expect_response(is_query_response, timeout=30000):
            p.get_by_role('button',name='Search',exact=True).click()
        # Wait for loading indicators and ensure the DOM result is stable.
        p.locator('.auxo-spin-spinning').first.wait_for(state='hidden',timeout=30000)
        last = None
        stable = 0
        deadline = time.monotonic()+15
        while time.monotonic()<deadline:
            text = p.locator('body').inner_text()
            found = re.search(r'Total package:\s*([\d,]+|[-—])',text)
            if not found:
                raise RuntimeError('找不到 Total package；页面可能已变化')
            raw = found.group(1)
            current = int(raw.replace(',','')) if raw not in ('-','—') else None
            empty = 'No data available' in text
            signature=(current,empty)
            stable = stable+1 if signature==last else 0
            last=signature
            if stable >= 3 and (current is not None or empty):
                if current is None:
                    # Dash is not proof of zero. Report unknown rather than auto-expand.
                    raise RuntimeError('页面显示 Total package 为横线且无数据；需人工核验，不把未知值当作 0')
                return {'total_packages':current, 'type_tab':tab,
                        'quantity_range':[6,999] if phase.kind=='top' else [None,None],
                        'zone_values':zone_values(pairs), 'virtual_zones':virtuals,
                        'zone_operator':config['zone_operator'],'virtual_operator':config['virtual_operator'],
                        'count_scope':'全部筛选结果，尚未经过 Multis 策略过滤' if phase.kind=='multis' else '页面筛选结果',
                        'strategy':phase.strategy}
            p.wait_for_timeout(400)
        raise RuntimeError('查询结果未稳定，已停止')

    def consolidate(self, strategy, before_submit, stop):
        """Never retry a write. Persist intent before clicking the final OK."""
        p = self.page
        if stop.is_set():
            raise RuntimeError('已停止，尚未提交')
        selection = re.search(r'Goods selected\s*([\d,]+)', p.locator('body').inner_text())
        if not selection or int(selection.group(1).replace(',', '')) != 0:
            raise RuntimeError('必须确认 Goods selected 为 0，才能按完整筛选结果汇波')
        dialogs = p.get_by_role('dialog').filter(visible=True)
        if dialogs.count():
            raise RuntimeError('页面已有弹窗，请人工关闭后重新开始')
        p.get_by_role('button', name='Consolidate Wave', exact=True).click()
        dialogs.first.wait_for(state='visible')
        if dialogs.count() != 1:
            raise RuntimeError('汇波弹窗不唯一，停止')
        dialog = dialogs.first
        if not dialog.get_by_text(re.compile(r'^Select pick strategy$', re.I)).count():
            # Preliminary confirmation; final write is only allowed below.
            dialog.get_by_role('button', name='OK', exact=True).click()
        p.get_by_text(re.compile(r'^Select pick strategy$', re.I)).wait_for(state='visible')
        dialogs = p.get_by_role('dialog').filter(visible=True)
        if dialogs.count() != 1:
            raise RuntimeError('无法唯一定位 Select pick strategy 弹窗')
        dialog = dialogs.first
        label = dialog.get_by_text(strategy, exact=True)
        if label.count() != 1:
            raise RuntimeError('找不到唯一 picking strategy：'+strategy)
        row = dialog.get_by_role('row').filter(has=p.get_by_text(strategy, exact=True))
        if row.count() != 1:
            raise RuntimeError('无法唯一识别策略行；停止而不选择默认策略')
        radios = row.get_by_role('radio')
        if radios.count() != 1:
            raise RuntimeError('策略行没有唯一单选框')
        radios.check()
        if not radios.is_checked():
            raise RuntimeError('策略没有选中')
        status = dialog.get_by_role('radio', name=re.compile(r'^Not Operated$', re.I))
        if status.count() != 1:
            raise RuntimeError('找不到唯一 Not Operated 选项；停止提交')
        status.check()
        if not status.is_checked() or not radios.is_checked():
            raise RuntimeError('策略或 Not Operated 校验失败')
        if stop.is_set():
            raise RuntimeError('已停止，尚未点击最终 OK；请人工关闭弹窗')
        # Capture the acknowledgement channel before writing, excluding stale success toasts.
        notices = p.locator('[role="alert"], [class*="message-notice"], [class*="notification-notice"]')
        previous = set(notices.all_text_contents())
        before_submit()
        dialog.get_by_role('button', name='OK', exact=True).click(timeout=15000)
        deadline = time.monotonic()+60
        while time.monotonic() < deadline:
            fresh = [t.strip() for t in notices.all_text_contents() if t not in previous]
            for text in fresh:
                if re.search(r'failed|failure|error|失败', text, re.I):
                    raise RuntimeError('提交后 WMS 报错：'+text+'；需核对是否已生成波次')
                if re.search(r'success|成功', text, re.I):
                    dialog.wait_for(state='hidden', timeout=15000)
                    return {'status':'confirmed', 'acknowledgement':text, 'strategy':strategy,
                            'wave_operation':'Not Operated'}
            # A disappearing dialog or HTTP 200 alone is not confirmation of success.
            p.wait_for_timeout(200)
        raise RuntimeError('最终 OK 已尝试，60 秒内未识别明确成功提示；请在 WMS 核对，禁止自动重试')
