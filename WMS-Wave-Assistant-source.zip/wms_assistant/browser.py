"""WMS UI adapter with explicit, single-attempt consolidation."""
import re
import time
from functools import wraps
from .core import zone_values, phase_operators

URL = 'https://wms-ttp.tiktokw.us/outbound/waveManagementInfo/wave-summary'

def receipt_page(method):
    """Keep the live query untouched while reading/canceling owned wave receipts."""
    @wraps(method)
    def wrapped(self,*args,**kwargs):
        if not hasattr(self,'context') or getattr(self,'_in_receipts',False):
            return method(self,*args,**kwargs)
        original=self.page
        page=getattr(self,'_receipt_page',None)
        if page is None or page.is_closed():
            page=self.context.new_page();page.set_default_timeout(12000)
            self._receipt_page=page
            page.goto(URL,wait_until='domcontentloaded')
        self.page=page;self._in_receipts=True
        try:return method(self,*args,**kwargs)
        finally:self.page=original;self._in_receipts=False
    return wrapped

class WMSBrowser:
    preserves_query_for_receipts = True
    def __init__(self, profile):
        from playwright.sync_api import sync_playwright
        self.pw = sync_playwright().start()
        self.context = self.pw.chromium.launch_persistent_context(str(profile), headless=False,
            viewport={'width':1600, 'height':1000}, accept_downloads=False)
        self.page = self.context.pages[0] if self.context.pages else self.context.new_page()
        self.page.goto(URL, wait_until='domcontentloaded')
        self.page.set_default_timeout(12000)

    def close(self):
        try:
            self.context.close()
        finally:
            self.pw.stop()

    def open_select(self, field):
        return self.open_select_box(self.page.locator('#'+field), field)

    def open_select_box(self, box, field):
        box.wait_for(state='attached')
        # Auxo/Ant readonly search inputs are covered by the selected label.
        # Click the visible selector surface, never the covered input or force-click.
        surface = box.locator('xpath=ancestor::*[contains(concat(" ", normalize-space(@class), " "), " auxo-select-selector ") or contains(concat(" ", normalize-space(@class), " "), " ant-select-selector ")][1]')
        surface.click()
        list_id = box.get_attribute('aria-controls') or box.get_attribute('aria-owns')
        if not list_id:
            raise RuntimeError(f'{field} 没有可识别的下拉列表；停止查询')
        # Scope options to this control, including virtualized option lists.
        panel = self.page.locator('[id="'+list_id+'"]').locator('xpath=ancestor::*[contains(concat(" ", normalize-space(@class), " "), " auxo-select-dropdown ") or contains(concat(" ", normalize-space(@class), " "), " ant-select-dropdown ")][1]')
        panel.wait_for(state='visible')
        return box, panel

    def select(self, field, labels):
        if not labels:
            return
        box, panel = self.open_select(field)
        for label in labels:
            exact = panel.get_by_title(label, exact=True).filter(visible=True)
            exact.first.wait_for(state='visible')
            if exact.count() != 1:
                raise RuntimeError(f'{field} 找不到唯一精确选项 {label!r}；未采用模糊匹配')
            exact.click()
        box.press('Escape')

    def set_operator(self, field, label):
        box, panel = self.open_select(field)
        option = panel.get_by_title(label, exact=True).filter(visible=True)
        option.first.wait_for(state='visible')
        if option.count() != 1:
            raise RuntimeError('无法唯一定位匹配方式 '+label)
        option.click()
        panel.wait_for(state='hidden')

    def ensure_wave_page(self):
        p = self.page
        if p.is_closed():
            self.page = self.context.new_page()
            p = self.page
        ready = p.get_by_role('button', name='Reset', exact=True)
        # A refreshing SPA is not a logged-out session. Wait on the current route.
        if '/outbound/waveManagementInfo/wave-summary' not in p.url:
            menu=p.get_by_role('menuitem',name='Wave Consolidation',exact=True).filter(visible=True)
            if menu.count():
                menu.first.click()
                p.wait_for_url('**/outbound/waveManagementInfo/wave-summary',timeout=30000)
            else:
                try:
                    p.goto(URL, wait_until='domcontentloaded')
                except Exception as exc:
                    # WMS may interrupt a deep link with its Home startup route.
                    # Continue through the visible menu only for this known case.
                    if not ('interrupted by another navigation' in str(exc) and '/home' in p.url): raise
                    p.wait_for_load_state('domcontentloaded',timeout=30000)
        try:
            # A fresh deep link can redirect to Home while the SPA initializes.
            # Follow the real Outbound menu if the route did not become ready.
            outbound = p.get_by_role('menuitem', name='Outbound', exact=True)
            ready.or_(outbound).first.wait_for(state='visible', timeout=30000)
            if not ready.is_visible() and '/outbound/waveManagementInfo/wave-summary' not in p.url:
                outbound.click()
                wave = p.get_by_role('menuitem', name='Wave', exact=True)
                destination = p.get_by_role('menuitem', name='Wave Consolidation', exact=True)
                wave.wait_for(state='visible')
                if not destination.is_visible():
                    wave.click()
                destination.click()
            ready.wait_for(state='visible', timeout=30000)
        except Exception as exc:
            self.check_session()
            if p.get_by_role('button',name='重置',exact=True).is_visible():
                raise RuntimeError('当前 WMS 是中文，请切换为 English 后继续当前小节点') from exc
            raise RuntimeError('Wave Consolidation 页面尚未就绪，可刷新后继续当前小节点') from exc

    def recover_query_page(self,reopen=False):
        """Clear HTTP cache only: retain cookies, storage, profile and ledger."""
        if self.page.is_closed():
            self.page=self.context.new_page()
        session=self.context.new_cdp_session(self.page)
        try:
            session.send('Network.clearBrowserCache')
        finally:
            session.detach()
        if reopen:
            old=self.page
            self.page=self.context.new_page()
            self.page.set_default_timeout(12000)
            old.close()
            self.page.goto(URL,wait_until='domcontentloaded',timeout=30000)
        else:
            self.page.reload(wait_until='domcontentloaded',timeout=30000)
        self.ensure_wave_page()

    def settle_query_page(self):
        deadline=time.monotonic()+30
        while time.monotonic()<deadline:
            self.page.wait_for_timeout(100)
            if not self._query_pending and time.monotonic()-self._query_activity>=0.25:
                if not self.page.locator('.auxo-spin-spinning').first.is_visible():return
        from playwright.sync_api import TimeoutError
        raise TimeoutError('查询请求尚未全部结束，未读取 Total package')

    def query(self, phase, pairs, virtuals, config, quantity=None, tab_override=None):
        self.ensure_wave_page()
        p=self.page
        self._query_pending=set();self._query_activity=time.monotonic()
        def started(request):
            if request.resource_type in ('xhr','fetch'):
                self._query_pending.add(request);self._query_activity=time.monotonic()
        def ended(request):
            if request in self._query_pending:
                self._query_pending.discard(request);self._query_activity=time.monotonic()
        p.on('request',started);p.on('requestfinished',ended);p.on('requestfailed',ended)
        try:
            # Drain any requests that started before the listeners were attached.
            p.wait_for_load_state('networkidle',timeout=30000)
            return self._query(phase,pairs,virtuals,config,quantity,tab_override)
        finally:
            p.remove_listener('request',started)
            p.remove_listener('requestfinished',ended)
            p.remove_listener('requestfailed',ended)

    def set_outbound_created_range(self, window):
        import datetime as dt
        from zoneinfo import ZoneInfo
        p=self.page
        dates=[dt.datetime.fromisoformat(window[k]).astimezone(ZoneInfo('America/New_York')) for k in ('start','end')]
        field=p.locator('.auxo-form-item').filter(has=p.locator('label[for="consignment_order_create_time"]')).filter(visible=True)
        if field.count()!=1:raise RuntimeError('无法唯一定位 Outbound order created at，尚未提交')
        field.locator('input').first.click()
        popup=p.locator('.sp-picker-range').filter(visible=True)
        popup.wait_for(state='visible')
        for index,date in enumerate(dates):
            popup.locator('.sp-picker-range-body input').nth(index).click()
            day=popup.locator('td.auxo-picker-cell-in-view[title="'+date.strftime('%Y-%m-%d')+'"]')
            for _ in range(24):
                if day.count():break
                first=popup.locator('td.auxo-picker-cell-in-view').first.get_attribute('title')
                direction='prev' if date.strftime('%Y-%m-%d')<first else 'next'
                popup.locator('.auxo-picker-header-'+direction+'-btn').filter(visible=True).click()
            if day.count()!=1:raise RuntimeError('无法选择尾波日期，尚未提交')
            day.click()
        for index,date in enumerate(dates):
            time_input=popup.locator('.sp-picker-range-time input').nth(index)
            time_input.click()
            panel=p.locator('.auxo-picker-time-panel').filter(visible=True)
            for column,value in enumerate((date.hour,date.minute,date.second)):
                panel.locator('.auxo-picker-time-panel-column').nth(column).get_by_text(f'{value:02d}',exact=True).click()
            if time_input.input_value()!=date.strftime('%H:%M:%S'):
                raise RuntimeError('尾波时间未正确选中，尚未提交')
            time_input.press('Escape')
        popup.get_by_role('button',name='OK',exact=True).click()
        popup.wait_for(state='hidden')
        actual=field.locator('input').evaluate_all('(es)=>es.map(e=>e.value)')
        parsed=[]
        for value in actual:
            try:parsed.append(dt.datetime.strptime(value,'%m/%d/%Y %I:%M:%S %p'))
            except ValueError:raise RuntimeError('无法读取尾波日期筛选值，尚未提交')
        if parsed!=[d.replace(tzinfo=None) for d in dates]:
            raise RuntimeError('尾波日期筛选未正确保留，尚未提交')

    def _query(self, phase, pairs, virtuals, config, quantity=None, tab_override=None):
        p=self.page
        self.settle_query_page()
        zone_operator, virtual_operator = phase_operators(phase, virtuals)
        p.get_by_role('button', name='Reset', exact=True).click()
        self.settle_query_page()
        more = p.get_by_role('button', name='More', exact=True)
        if more.is_visible():
            more.click()
        tab = tab_override or ('One item only' if phase.kind in ('single','top') else 'All')
        bounds = quantity if quantity is not None else ((6,999) if phase.kind=='top' else (None,None))
        p.get_by_text(tab, exact=True).click()
        self.settle_query_page()
        for i,value in enumerate(bounds):
            if value is not None:
                p.get_by_role('spinbutton').nth(i).fill(str(value))
        if pairs:
            self.set_operator('zone_op_type', zone_operator)
            self.select('inv_zone_list', zone_values(pairs))
        if virtuals:
            self.set_operator('logical_zone_op_type',virtual_operator)
            self.select('logical_inv_zone_list', virtuals)
        if config.get('outbound_created_range'):
            self.set_outbound_created_range(config['outbound_created_range'])
        # Flush onchange/debounced reads before capturing the Search request.
        p.wait_for_timeout(250)
        self.settle_query_page()
        expected_bounds=['' if value is None else str(value) for value in bounds]
        actual_bounds=[p.get_by_role('spinbutton').nth(i).input_value() for i in range(2)] if p.get_by_role('spinbutton').count()>=2 else None
        if actual_bounds is not None and actual_bounds!=expected_bounds:
            raise RuntimeError('Package quantity 筛选值未正确保留，尚未提交')
        def is_query_request(req):
            return req.resource_type in ('xhr','fetch') and 'wms-ttp.tiktokw.us' in req.url
        with p.expect_request(is_query_request,timeout=30000) as search:
            p.get_by_role('button',name='Search',exact=True).click()
        self.settle_query_page()
        response=search.value.response()
        if response is None or not response.ok:
            raise RuntimeError('Search 请求失败，尚未提交')
        self.settle_query_page()
        last = None
        stable = 0
        deadline = time.monotonic()+15
        while time.monotonic()<deadline:
            text = p.locator('body').inner_text()
            found = re.search(r'Total package:\s*([\d,]+|[-—])',text)
            if not found:
                raise RuntimeError('找不到 Total package；页面可能已变化')
            raw = found.group(1)
            current = int(raw.replace(',','')) if raw not in ('-','—') else None
            empty = 'No data available' in text
            signature=(current,empty)
            stable = stable+1 if signature==last else 0
            last=signature
            if stable >= 2 and (current is not None or empty):
                if current is None:
                    # Live WMS uses dash + a stable empty table for zero results.
                    # A dash alone never reaches this branch.
                    current = 0
                return {'total_packages':current, 'type_tab':tab,
                        'quantity_range':list(bounds),
                        'outbound_created_range':config.get('outbound_created_range'),
                        'zone_values':zone_values(pairs), 'virtual_zones':virtuals,
                        'zone_operator':zone_operator,'virtual_operator':virtual_operator,
                        'count_scope':'Search 后页面 Total package（所有策略统一使用）',
                        'strategy':phase.strategy}
            p.wait_for_timeout(200)
        raise RuntimeError('查询结果未稳定，已停止')

    def dismiss_unsubmitted_dialog(self):
        # Called only with no pending write and a known pre-OK stop.
        titles=self.page.locator('.auxo-modal-title, .ant-modal-title, [role="heading"], h1, h2, h3').filter(has_text=re.compile(r'^Select pick strategy$',re.I))
        dialogs=self.page.get_by_role('dialog').filter(has=titles).filter(visible=True)
        if not dialogs.count():return
        if dialogs.count()!=1:raise RuntimeError('停止前弹窗不唯一，请关闭后继续')
        dialog=dialogs.first
        cancel=dialog.get_by_role('button',name='Cancel',exact=True)
        if not cancel.is_visible():cancel=dialog.get_by_role('button',name='Close',exact=True)
        if not cancel.is_visible():raise RuntimeError('请关闭尚未提交的策略弹窗，再点击开始')
        cancel.click();dialog.wait_for(state='hidden')

    def consolidate(self, strategy, before_submit, stop, receipt_via_table=False):
        """Never retry a write. Persist intent before clicking the final OK."""
        p = self.page
        if stop.is_set():
            raise RuntimeError('已停止，尚未提交')
        selection = re.search(r'Goods selected\s*([\d,]+)', p.locator('body').inner_text())
        if not selection or int(selection.group(1).replace(',', '')) != 0:
            raise RuntimeError('必须确认 Goods selected 为 0，才能按完整筛选结果汇波')
        dialogs = p.get_by_role('dialog').filter(visible=True)
        if dialogs.count():
            raise RuntimeError('页面已有弹窗，请人工关闭后重新开始')
        p.get_by_role('button', name='Consolidate Wave', exact=True).click()
        dialogs.first.wait_for(state='visible')
        if dialogs.count() != 1:
            raise RuntimeError('汇波弹窗不唯一，停止')
        title_pattern = re.compile(r'^Select pick strategy$', re.I)
        titles = p.locator('.auxo-modal-title, .ant-modal-title, [role="heading"], h1, h2, h3').filter(has_text=title_pattern)
        picks = p.get_by_role('dialog').filter(has=titles).filter(visible=True)
        if not picks.count():
            # This is the preliminary confirmation, not the final submission.
            dialogs.first.get_by_role('button', name='OK', exact=True).click()
        picks.first.wait_for(state='visible')
        # Live WMS keeps the preliminary modal visible during its exit animation.
        # Wait for that transition; never treat a transient second modal as failure.
        from playwright.sync_api import expect
        try:
            expect(picks).to_have_count(1, timeout=12000)
            expect(dialogs).to_have_count(1, timeout=12000)
        except AssertionError as exc:
            raise RuntimeError('Select pick strategy 弹窗过渡未完成或存在重复弹窗；尚未提交') from exc
        dialog = picks.first
        selector = dialog.locator('.auxo-select-selector, .ant-select-selector').filter(
            has=p.get_by_text(title_pattern)).filter(visible=True)
        if selector.count():
            if selector.count() != 1:
                raise RuntimeError('策略下拉框不唯一，停止提交')
            box = selector.get_by_role('combobox')
            if box.count() != 1:
                raise RuntimeError('无法唯一定位策略下拉框输入控件')
            _, panel = self.open_select_box(box, 'picking strategy')
            option = panel.get_by_title(strategy, exact=True).filter(visible=True)
            option.first.wait_for(state='visible')
            if option.count() != 1:
                raise RuntimeError('找不到唯一 picking strategy：'+strategy)
            option.click()
            panel.wait_for(state='hidden')
            selected = dialog.locator('.auxo-select-selection-item, .ant-select-selection-item').filter(has_text=re.compile('^'+re.escape(strategy)+'$'))
            selected.wait_for(state='visible')
            strategy_checked = lambda: selected.count()==1 and selected.is_visible()
        else:
            # Retain compatibility with the table/radio layout.
            row = dialog.get_by_role('row').filter(has=p.get_by_text(strategy, exact=True))
            if row.count() != 1:
                raise RuntimeError('无法唯一识别策略行；停止而不选择默认策略')
            radios = row.get_by_role('radio')
            if radios.count() != 1:
                raise RuntimeError('策略行没有唯一单选框')
            radios.check()
            strategy_checked = radios.is_checked
        if not strategy_checked():
            raise RuntimeError('策略没有选中')
        status = dialog.get_by_role('radio', name=re.compile(r'^Not Operated$', re.I))
        if status.count() != 1:
            raise RuntimeError('找不到唯一 Not Operated 选项；停止提交')
        status.check()
        if not status.is_checked() or not strategy_checked():
            raise RuntimeError('策略或 Not Operated 校验失败')
        if stop.is_set():
            raise RuntimeError('已停止，尚未点击最终 OK；请人工关闭弹窗')
        # Capture the acknowledgement channel before writing, excluding stale success toasts.
        notices = p.locator('[role="alert"], [class*="message-notice"], [class*="notification-notice"]')
        previous = set(notices.all_text_contents())
        before_submit()
        dialog.get_by_role('button', name='OK', exact=True).click(timeout=15000)
        if receipt_via_table:
            # Poll the authoritative wave table, not a transient success toast.
            dialog.wait_for(state='hidden', timeout=30000)
            return {'status':'submitted'}
        deadline = time.monotonic()+60
        while time.monotonic() < deadline:
            fresh = [t.strip() for t in notices.all_text_contents() if t not in previous]
            for text in fresh:
                if re.search(r'failed|failure|error|失败', text, re.I):
                    raise RuntimeError('提交后 WMS 报错：'+text+'；需核对是否已生成波次')
                if re.search(r'success|成功', text, re.I):
                    dialog.wait_for(state='hidden', timeout=15000)
                    return {'status':'confirmed', 'acknowledgement':text, 'strategy':strategy,
                            'wave_operation':'Not Operated'}
            # A disappearing dialog or HTTP 200 alone is not confirmation of success.
            p.wait_for_timeout(200)
        raise RuntimeError('最终 OK 已尝试，60 秒内未识别明确成功提示；请在 WMS 核对，禁止自动重试')


    def check_session(self):
        p=self.page
        if re.search(r'/(login|signin|sign-in)(?:[/?#]|$)',p.url,re.I) or p.get_by_text('Session timeout. Please log in again.',exact=True).is_visible():
            raise RuntimeError('WMS 登录已过期，请重新登录后继续当前小节点')

    def identity(self):
        self.ensure_wave_page()
        p=self.page
        self.check_session()
        # English form controls are the evidence, not a transient header language button.
        p.get_by_role('button',name='Reset',exact=True).wait_for(state='visible',timeout=30000)
        profile=p.get_by_role('button').filter(has=p.get_by_role('img',name='Profile Photo',exact=True))
        profile.first.wait_for(state='visible',timeout=30000)
        if profile.count()!=1: raise RuntimeError('无法唯一识别当前账号和仓库')
        parts=profile.inner_text().split()
        if len(parts)!=2: raise RuntimeError('账号/仓库显示结构变化，请人工核验')
        return parts[0],parts[1]

    def confirmation_page(self):
        p=self.page
        if '/wave-confirm' not in p.url:
            menu=p.get_by_role('menuitem',name='Wave Confirmation',exact=True).filter(visible=True)
            if not menu.count(): self.ensure_wave_page()
            menu.first.click()
            p.wait_for_url('**/outbound/waveManagementInfo/wave-confirm',timeout=30000)
        p.get_by_role('textbox',name='Creator',exact=True).wait_for(state='visible',timeout=30000)
        if p.get_by_text('Session timeout. Please log in again.',exact=True).is_visible():
            raise RuntimeError('WMS 登录已过期，请重新登录；操作未自动重试')

    def _search_waves(self,creator):
        self.confirmation_page();p=self.page
        p.get_by_role('button',name='Reset',exact=True).click()
        # Reset can start a slow older table request; drain it before Search.
        p.wait_for_load_state('networkidle',timeout=30000)
        p.get_by_role('textbox',name='Creator',exact=True).fill(creator)
        with p.expect_response(lambda r:r.request.resource_type in ('xhr','fetch') and r.ok and 'wms-ttp.tiktokw.us' in r.url,timeout=30000):
            p.get_by_role('button',name='Search',exact=True).click()
        p.locator('.auxo-spin-spinning').first.wait_for(state='hidden',timeout=30000)
        p.wait_for_load_state('networkidle',timeout=30000)

    def _wave_rows(self):
        # Only rendered table cells, no private API or application state.
        rows=self.page.locator('tr').evaluate_all("""es => es.map(e=>Array.from(e.querySelectorAll('td')).map(c=>c.textContent.trim())).filter(c=>c.length===17 && /^WAVE/.test(c[2]))""")
        result=[]
        for cells in rows:
            result.append({'wave_number':cells[2],'creator':cells[8],'created_at':cells[10],
                'packages':0 if cells[4].strip() in ('','-','—') else int(cells[4].replace(',','')),'status':cells[15],'source':cells[14]})
        return result

    @receipt_page
    def wave_snapshot(self,creator):
        self._search_waves(creator);p=self.page
        records=[];pages=set()
        for _ in range(400):
            rows=self._wave_rows()
            if any(r['creator']!=creator for r in rows):raise RuntimeError('Creator 筛选结果尚未一致，停止核验')
            signature=tuple(r['wave_number'] for r in rows)
            if signature in pages:raise RuntimeError('波次分页未前进，无法取得完整核验基线')
            pages.add(signature);records.extend(rows)
            next_button=p.get_by_role('listitem',name='Next Page',exact=True).get_by_role('button')
            if not next_button.is_enabled():return records
            with p.expect_response(lambda r:r.request.resource_type in ('xhr','fetch') and r.ok and 'wms-ttp.tiktokw.us' in r.url,timeout=30000):
                next_button.click()
            p.locator('.auxo-spin-spinning').first.wait_for(state='hidden',timeout=30000)
            p.wait_for_load_state('networkidle',timeout=30000)
        raise RuntimeError('波次记录超过核验分页上限，已停止')

    @receipt_page
    def wait_new_waves(self,intent,stop,allow_canceled_hold=False):
        import datetime as dt
        seen={r['wave_number'] for r in intent['baseline']}
        started=dt.datetime.fromisoformat(intent['started'])-dt.timedelta(seconds=5)
        deadline=time.monotonic()+120
        while time.monotonic()<deadline:
            # Finish receipt reconciliation even after Stop; never start another write.
            rows=self.wave_snapshot(intent['creator'])
            body=self.page.locator('body').inner_text()
            offset=re.search(r'UTC([+-])(\d{1,2})(?::(\d{2}))?',body)
            if not offset:raise RuntimeError('无法读取 WMS 显示时区，停止波次核验')
            minutes=(int(offset[2])*60+int(offset[3] or 0))*(1 if offset[1]=='+' else -1)
            tz=dt.timezone(dt.timedelta(minutes=minutes))
            fresh=[]
            for row in rows:
                if row['creator']!=intent['creator']:raise RuntimeError('波次创建人与当前核验账号不一致')
                if row['wave_number'] in seen:continue
                created=dt.datetime.strptime(row['created_at'],'%m/%d/%Y %I:%M:%S %p').replace(tzinfo=tz)
                if created<started:continue
                if row['source']!='Wave Consolidation':raise RuntimeError('同账号出现其他来源的新波次，需人工核对')
                fresh.append(row)
            active=[r for r in fresh if r['status'] not in ('Failed','Canceled')]
            if not active and fresh:
                if allow_canceled_hold and all(r['status']=='Canceled' for r in fresh):return fresh
                raise RuntimeError('上次操作未成功：波次已失败或取消')
            fresh=active
            if fresh and all(r['status'] in ('Created','Confirmed') for r in fresh):
                if all(r['packages']>0 for r in fresh):return fresh
            self.page.wait_for_timeout(1000)
        raise RuntimeError('120 秒内未匹配本账号新增波次与包裹数；保留待核对记录，禁止重试')

    @receipt_page
    def cancel_owned_wave(self,wave,before_submit,stop):
        rows=self.wave_snapshot(wave['creator'])
        matches=[r for r in rows if r['wave_number']==wave['wave_number']]
        if len(matches)!=1:raise RuntimeError('台账暂存波次未找到或不唯一，未取消')
        row=matches[0]
        if row['packages']!=wave['packages']:raise RuntimeError('暂存波次包裹数已改变，未取消')
        if row['status']=='Canceled':return
        if row['status']!='Created':raise RuntimeError('暂存波次不是 Created，禁止取消：'+row['status'])
        # Search the exact wave number before touching its row; table may span pages.
        p=self.page
        number=p.get_by_role('textbox',name='Please enter',exact=True)
        number.fill(wave['wave_number'])
        with p.expect_response(lambda r:r.request.resource_type in ('xhr','fetch') and r.ok and 'wms-ttp.tiktokw.us' in r.url,timeout=30000):
            p.get_by_role('button',name='Search',exact=True).click()
        p.locator('.auxo-spin-spinning').first.wait_for(state='hidden',timeout=30000)
        p.wait_for_load_state('networkidle',timeout=30000)
        exact=p.get_by_role('row').filter(has=p.get_by_role('cell',name=re.compile('^'+re.escape(wave['wave_number'])+r'(?: Copy)?$')))
        if exact.count()!=1:raise RuntimeError('无法唯一定位本轮暂存波次行，未取消')
        if stop.is_set():raise RuntimeError('取消前已停止')
        before_submit()
        exact.get_by_text('Cancel',exact=True).click()
        # WMS may show a confirmation dialog. Never select a default across dialogs.
        until=time.monotonic()+10
        while time.monotonic()<until:
            dialogs=p.get_by_role('dialog').filter(visible=True)
            if dialogs.count():
                if dialogs.count()!=1:raise RuntimeError('取消弹窗不唯一，需人工核对')
                text=dialogs.inner_text()
                if not re.search(r'cancel',text,re.I):raise RuntimeError('未识别取消确认弹窗，需人工核对')
                ok=dialogs.get_by_role('button',name='OK',exact=True)
                if ok.count()!=1:raise RuntimeError('取消弹窗没有唯一 OK，需人工核对')
                if stop.is_set():raise RuntimeError('取消确认前已停止，需人工核对')
                ok.click();break
            if any(r['wave_number']==wave['wave_number'] and r['status']=='Canceled' for r in self._wave_rows()):return
            p.wait_for_timeout(300)
        deadline=time.monotonic()+120
        while time.monotonic()<deadline:
            rows=self.wave_snapshot(wave['creator'])
            found=[r for r in rows if r['wave_number']==wave['wave_number']]
            if len(found)==1 and found[0]['status']=='Canceled':
                p.wait_for_timeout(1500);return
            p.wait_for_timeout(3000)
        raise RuntimeError('取消后 120 秒内未看到 Canceled，需人工核对；不会重复取消')
