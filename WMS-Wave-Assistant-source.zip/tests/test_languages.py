"""Desktop UI contract tests, served entirely by local fixtures."""
import json,re,unittest
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
from wms_assistant.core import default_config

class LanguageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw=sync_playwright().start();cls.browser=cls.pw.chromium.launch(headless=True,executable_path=cls.pw.chromium.executable_path)
    @classmethod
    def tearDownClass(cls):cls.browser.close();cls.pw.stop()
    def setUp(self):
        self.context=self.browser.new_context();self.page=self.context.new_page();self.posts=[]
        self.data={'state':{'busy':False,'message':'','events':[]},'config':default_config(),'round_ledger':{'runs':[],'waves':[],'pending':None},'pending_submission':None}
        html=(Path(__file__).parents[1]/'wms_assistant/ui.html').read_text(encoding='utf-8')
        def response(route):
            if route.request.method=='POST':self.posts.append((route.request.url,route.request.post_data_json))
            route.fulfill(content_type='application/json' if '/api/' in route.request.url else 'text/html',body=json.dumps(self.data) if '/api/' in route.request.url else html)
        self.page.route('**/*',response);self.page.goto('http://wms-ui.test/',wait_until='domcontentloaded');expect(self.page.locator('#cards button')).to_have_count(3)
    def tearDown(self):self.context.close()
    def test_three_choices_and_one_click_execution_no_second_dialog(self):
        self.page.locator('#cards button').nth(2).click();expect(self.page.locator('#timeline')).to_contain_text('隔离爆品')
        dialogs=[];self.page.on('dialog',lambda d:(dialogs.append(d.message),d.dismiss()))
        self.page.locator('#start').click();self.assertEqual(dialogs,[])
        self.assertEqual(self.posts[-1][1],{'mode':'last','restart':True})
    def test_spanish_persists_and_translates_timeline(self):
        self.page.locator('#language').select_option('es');expect(self.page).to_have_title('Cronología de oleadas')
        self.assertFalse(re.search('[\u4e00-\u9fff]',self.page.locator('#timeline').inner_text()))
        self.page.reload();expect(self.page.locator('#language')).to_have_value('es')
        expect(self.page.locator('.notice')).to_contain_text('English')
    def test_pending_or_busy_blocks_new_round_and_shows_recheck(self):
        self.data['round_ledger']['pending']={'kind':'create'};self.page.evaluate('refresh()')
        expect(self.page.locator('#start')).to_be_enabled();expect(self.page.locator('#recovery')).to_be_hidden()
        self.data['state']['busy']=True;self.page.evaluate('refresh()')
        expect(self.page.locator('#cards button').first).to_be_disabled()
    def test_ledger_metrics_exclude_holds_and_other_runs(self):
        self.data['round_ledger']={'pending':None,'runs':[{'id':'r','mode':'first','status':'complete','top_released':100}], 'waves':[{'run_id':'r','state':'released','packages':100},{'run_id':'r','state':'held','packages':500},{'run_id':'old','state':'released','packages':900}]}
        self.page.evaluate('refresh()');expect(self.page.locator('#released')).to_have_text('100')

    def test_verified_hold_shows_resume_without_starting_new_round(self):
        self.data['round_ledger']['runs']=[{'id':'r','mode':'first','status':'paused','next_step':1,'resume_ready':True}]
        self.page.evaluate('refresh()')
        expect(self.page.locator('#start')).to_be_enabled()
        self.page.locator('#continue').click()
        self.assertTrue(self.posts[-1][0].endswith('/api/round'))
        self.assertEqual(self.posts[-1][1],{'mode':'first','restart':False})
    def test_export_uses_backend_instead_of_blob_download(self):
        self.page.locator('details').nth(1).locator('summary').click()
        self.page.get_by_role('button',name='导出台账',exact=True).click()
        self.assertTrue(self.posts[-1][0].endswith('/api/export-ledger'))

    def test_new_round_and_continue_are_separate_choices(self):
        self.data['round_ledger']['runs']=[{'id':'r','mode':'first','status':'paused','next_step':2}]
        self.page.evaluate('refresh()')
        expect(self.page.locator('#continue')).to_be_visible()
        self.page.locator('#cards button').nth(2).click()
        self.page.locator('#start').click()
        self.assertEqual(self.posts[-1][1],{'mode':'last','restart':True})
        self.page.locator('#continue').click()
        self.assertEqual(self.posts[-1][1],{'mode':'first','restart':False})
        self.page.locator('#language').select_option('es')
        expect(self.page.locator('#start')).to_contain_text('Iniciar desde el paso 0')
        expect(self.page.locator('#continue')).to_contain_text('Continuar tarea anterior')
