"""Desktop UI contract tests, served entirely by local fixtures."""
import json,re,unittest
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
from wms_assistant.core import default_config

class LanguageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw=sync_playwright().start();cls.browser=cls.pw.chromium.launch(headless=True,executable_path=cls.pw.chromium.executable_path)
    @classmethod
    def tearDownClass(cls):cls.browser.close();cls.pw.stop()
    def setUp(self):
        self.context=self.browser.new_context();self.page=self.context.new_page();self.posts=[]
        self.data={'state':{'busy':False,'message':'','events':[]},'config':default_config(),'round_ledger':{'runs':[],'waves':[],'pending':None},'pending_submission':None}
        html=(Path(__file__).parents[1]/'wms_assistant/ui.html').read_text(encoding='utf-8')
        def response(route):
            if route.request.method=='POST':self.posts.append((route.request.url,route.request.post_data_json))
            route.fulfill(content_type='application/json' if '/api/' in route.request.url else 'text/html',body=json.dumps(self.data) if '/api/' in route.request.url else html)
        self.page.route('**/*',response);self.page.goto('http://wms-ui.test/',wait_until='domcontentloaded');expect(self.page.locator('#cards button')).to_have_count(3)
    def tearDown(self):self.context.close()
    def test_three_choices_and_one_click_execution_no_second_dialog(self):
        self.page.locator('#cards button').nth(1).click();expect(self.page.locator('#timeline')).to_contain_text('解除已记录的爆品锁定')
        dialogs=[];self.page.on('dialog',lambda d:(dialogs.append(d.message),d.dismiss()))
        self.page.locator('#start').click();self.assertEqual(dialogs,[])
        self.assertEqual(self.posts[-1][1],{'mode':'last','restart':True,'release_limit':0})
    def test_spanish_persists_and_translates_timeline(self):
        self.page.locator('#language').select_option('es');expect(self.page).to_have_title('Cronología de oleadas')
        self.assertFalse(re.search('[\u4e00-\u9fff]',self.page.locator('#timeline').inner_text()))
        self.page.reload();expect(self.page.locator('#language')).to_have_value('es')
        expect(self.page.locator('.notice')).to_contain_text('English')
    def test_pending_or_busy_blocks_new_round_and_shows_recheck(self):
        self.data['round_ledger']['pending']={'kind':'create'};self.page.evaluate('refresh()')
        expect(self.page.locator('#start')).to_be_enabled();expect(self.page.locator('#recovery')).to_be_hidden()
        self.data['state']['busy']=True;self.page.evaluate('refresh()')
        expect(self.page.locator('#cards button').first).to_be_disabled()
    def test_ledger_metrics_exclude_holds_and_other_runs(self):
        self.data['round_ledger']={'pending':None,'runs':[{'id':'r','mode':'first','status':'complete','top_released':100}], 'waves':[{'run_id':'r','state':'released','packages':100},{'run_id':'r','state':'held','packages':500},{'run_id':'old','state':'released','packages':900}]}
        self.page.evaluate('refresh()');expect(self.page.locator('#released')).to_have_text('100')

    def test_verified_hold_shows_resume_without_starting_new_round(self):
        self.data['round_ledger']['runs']=[{'id':'r','mode':'first','status':'paused','next_step':1,'resume_ready':True}]
        self.page.evaluate('refresh()')
        expect(self.page.locator('#start')).to_be_enabled()
        self.page.locator('#continue').click()
        self.assertTrue(self.posts[-1][0].endswith('/api/round'))
        self.assertEqual(self.posts[-1][1],{'mode':'first','restart':False})
    def test_export_uses_backend_instead_of_blob_download(self):
        self.page.locator('details').nth(1).locator('summary').click()
        self.page.get_by_role('button',name='导出台账',exact=True).click()
        self.assertTrue(self.posts[-1][0].endswith('/api/export-ledger'))

    def test_new_round_and_continue_are_separate_choices(self):
        self.data['round_ledger']['runs']=[{'id':'r','mode':'first','status':'paused','next_step':2}]
        self.page.evaluate('refresh()')
        expect(self.page.locator('#continue')).to_be_visible()
        self.page.locator('#cards button').nth(1).click()
        self.page.locator('#start').click()
        self.assertEqual(self.posts[-1][1],{'mode':'last','restart':True,'release_limit':0})
        self.page.locator('#continue').click()
        self.assertEqual(self.posts[-1][1],{'mode':'first','restart':False})
        self.page.locator('#language').select_option('es')
        expect(self.page.locator('#start')).to_contain_text('Iniciar')
        expect(self.page.locator('#continue')).to_contain_text('Continuar subetapa actual')

    def test_running_substeps_and_wait_state_are_visible_and_escaped(self):
        import time
        now=time.time()
        self.data['state'].update(busy=True,round_progress={'index':2,'key':'multis','status':'running','updated':now-10,'action':'等待 WMS 生成波次'},round_nodes=[{'key':'multis','scope':'Box L <unsafe>','status':'running','action':'等待 WMS 生成波次','started':now-20,'updated':now-10,'packages':50}])
        self.page.evaluate('refresh()')
        expect(self.page.locator('#live')).to_contain_text('正在运行')
        expect(self.page.locator('.substep')).to_contain_text('Box L <unsafe>')
        expect(self.page.locator('unsafe')).to_have_count(0)
        self.data['state']['busy']=False;self.page.evaluate('refresh()')
        expect(self.page.locator('.substep')).to_contain_text('已暂停')
        self.page.locator('#language').select_option('es')
        expect(self.page.locator('.substep')).to_contain_text('Pausado')

    def test_flex_presets_and_batch_limit_sent_without_multis(self):
        self.page.locator('#cards button').nth(2).click()
        expect(self.page.locator('#start')).to_be_disabled()
        self.page.get_by_role('button',name='仅 Single',exact=True).click()
        expect(self.page.locator('[data-node="multis_box_l"]')).not_to_be_checked()
        expect(self.page.locator('[data-node="single_box_l"]')).to_be_checked()
        self.page.locator('#release-limit').fill('3');self.page.locator('#release-limit').press('Tab')
        self.page.locator('#start').click()
        payload=self.posts[-1][1]
        self.assertEqual(payload['mode'],'flex');self.assertEqual(payload['release_limit'],3)
        self.assertEqual(len(payload['selected_steps']),7)
        self.assertTrue(all(k.startswith('single_') for k in payload['selected_steps']))
        self.page.get_by_role('button',name='清空选择',exact=True).click()
        self.page.locator('[data-node="hold_top"]').check()
        self.page.locator('[data-node="top_bin_h"]').check()
        self.page.locator('#start').click()
        self.assertEqual(self.posts[-1][1]['selected_steps'],['hold_top','top_bin_h'])
    def test_fixed_modes_hide_picker_and_first_does_not_audit(self):
        expect(self.page.locator('#flex-panel')).to_be_hidden()
        expect(self.page.locator('#timeline')).not_to_contain_text('核验结果')
        expect(self.page.locator('#timeline')).to_contain_text('1–4')
        expect(self.page.locator('.notice')).to_contain_text('必须')
        self.page.locator('#cards button').nth(1).click()
        expect(self.page.locator('#timeline')).to_contain_text('Package quantity 留空')
        expect(self.page.locator('#timeline')).to_contain_text('核验结果')
        self.page.locator('#cards button').nth(2).click()
        self.page.locator('#language').select_option('es')
        self.assertFalse(re.search('[\u4e00-\u9fff]',self.page.locator('#flex-panel').inner_text()))
    def test_unselected_nodes_not_shown_completed(self):
        self.data['round_ledger']['runs']=[{'id':'r','mode':'first','status':'complete','node_status':{'multis':'skipped','single':'limited'}}]
        self.page.evaluate('refresh()')
        expect(self.page.locator('.step.skipped')).to_contain_text('未选，跳过')
        expect(self.page.locator('.step.limited')).to_contain_text('达到批次上限')

    def test_flex_future_nodes_not_marked_done_during_run(self):
        self.data['round_ledger']['runs']=[{'id':'r','mode':'flex','plan_version':2,'status':'running','selected_steps':['top_bin_h','single_box_l'],'node_status':{'top_bin_h':'running'}}]
        self.data['state'].update(busy=True,round_progress={'key':'top_bin_h','index':10,'status':'running'})
        self.page.evaluate('refresh()')
        expect(self.page.locator('.step.running')).to_contain_text('Top-selling')
        expect(self.page.locator('.step.done')).to_have_count(0)
