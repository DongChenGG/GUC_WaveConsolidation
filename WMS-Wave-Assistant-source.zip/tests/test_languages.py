"""Browser-only localization tests; all requests are served by fixtures."""
import json
import re
import unittest
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
from wms_assistant.core import default_config, default_phases, ordered_phases

class LanguageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw = sync_playwright().start()
        cls.browser = cls.pw.chromium.launch(headless=True, executable_path=cls.pw.chromium.executable_path)
    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()
    def setUp(self):
        self.context = self.browser.new_context()
        self.page = self.context.new_page()
        self.page.set_default_timeout(5000)
        self.page.set_default_navigation_timeout(30000)
        self.posts = []
        self.data = dict(state=dict(busy=False, message='先打开浏览器并登录，再选择阶段试查。', results=[], events=[], reminders=[]), config=default_config(), phases=[p.to_dict() for p in ordered_phases(default_phases())], data_dir='C:/WMS', pending_submission=None)
        self.html = (Path(__file__).parents[1]/'wms_assistant/ui.html').read_text(encoding='utf-8')
        def respond(route):
            if route.request.method == 'POST': self.posts.append(route.request.post_data_json)
            route.fulfill(content_type='application/json' if '/api/' in route.request.url else 'text/html', body=json.dumps(self.data) if '/api/' in route.request.url else self.html)
        self.page.route('**/*', respond)
        self.page.goto('http://wms-ui.test/', wait_until='domcontentloaded')
        expect(self.page.locator('#phases tr')).to_have_count(30)
    def tearDown(self): self.context.close()
    def spanish(self):
        self.page.locator('#language').select_option('es')
        expect(self.page).to_have_title('Asistente de oleadas WMS')
    def test_all_stages_translate_and_language_persists(self):
        self.spanish()
        self.assertFalse(re.search('[\u4e00-\u9fff]', self.page.locator('#phases').inner_text()))
        self.page.reload(wait_until='domcontentloaded')
        expect(self.page).to_have_title('Asistente de oleadas WMS')
        expect(self.page.locator('#language')).to_have_value('es')
        self.page.locator('#language').select_option('zh')
        expect(self.page).to_have_title('WMS 放单助手')
        expect(self.page.locator('#phases')).to_contain_text('地堆 Multis')
    def test_values_and_real_confirmation_remain_correct(self):
        self.page.locator('#min').fill('45')
        self.spanish()
        expect(self.page.locator('#min')).to_have_value('45')
        expect(self.page.locator('.policy')).to_contain_text('Totally included')
        self.assertEqual(self.page.locator('#verified').count(),0)
        self.page.locator('#phases tr').nth(1).locator('button').first.click()
        expect(self.page.locator('#confirm')).to_contain_text('Clean-up Single')
        expect(self.page.locator('#confirm')).to_contain_text('Totally included')
        self.assertFalse(re.search('[\u4e00-\u9fff]', self.page.locator('#confirm').inner_text()))
        messages=[]
        self.page.on('dialog', lambda dialog: (messages.append(dialog.message), dialog.dismiss()))
        self.page.locator('#confirm button').filter(has_text='Not Operated').click()
        self.assertEqual(len(messages),0)
        self.assertEqual(self.posts,[{'phase':16,'confirm_live':True,'release_tail':False}])
    def test_editor_preserves_original_phase_data(self):
        self.spanish()
        self.page.locator('#phases tr').nth(1).locator('button').nth(1).click()
        original=self.page.locator('#phasejson').input_value()
        self.assertEqual(json.loads(original),self.data['phases'][1])
        self.page.locator('#language').select_option('zh')
        expect(self.page.locator('#phasejson')).to_have_value(original)

    def test_next_runs_once_without_confirmation_and_is_blocked_when_busy(self):
        self.data['state']['completed_phase']=16
        self.page.evaluate('refresh()')
        expect(self.page.locator('#next-step')).to_be_visible()
        dialogs=[]
        self.page.on('dialog',lambda d:(dialogs.append(d.message),d.dismiss()))
        self.page.locator('#next-step button').click()
        self.assertEqual(self.posts,[{'phase':17,'confirm_live':True,'release_tail':False}])
        self.assertEqual(dialogs,[])
        self.data['state']['busy']=True
        self.page.evaluate('refresh()')
        expect(self.page.locator('#next-step')).to_be_hidden()
    def test_english_requirement_in_both_languages(self):
        expect(self.page.locator('#english-required')).to_contain_text('必须切换为 English')
        self.spanish()
        expect(self.page.locator('#english-required')).to_contain_text('Cambie el idioma de WMS a English')
