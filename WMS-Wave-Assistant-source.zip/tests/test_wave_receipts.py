import threading,unittest
from playwright.sync_api import sync_playwright
from wms_assistant.browser import WMSBrowser
from wms_assistant.core import default_phases,default_config

class ReceiptBrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw=sync_playwright().start();cls.browser=cls.pw.chromium.launch(headless=True,executable_path=cls.pw.chromium.executable_path)
    @classmethod
    def tearDownClass(cls):cls.browser.close();cls.pw.stop()
    def setUp(self):
        self.context=self.browser.new_context();self.page=self.context.new_page();self.page.set_default_timeout(3000)
        self.b=WMSBrowser.__new__(WMSBrowser);self.b.page=self.page
    def tearDown(self):self.context.close()
    def test_live_table_shape_parses_full_wave_number_and_package_count(self):
        cells=['','1','WAVE20260001','30','30','1','-','-','tester','-','11/23/2026 7:00:00 PM','-','-','-','Wave Consolidation','Created','Cancel']
        self.page.set_content('<table><tr>'+''.join('<td>'+x+'</td>' for x in cells)+'</tr></table>')
        row=self.b._wave_rows()[0]
        self.assertEqual(row['wave_number'],'WAVE20260001');self.assertEqual(row['packages'],30);self.assertEqual(row['creator'],'tester')
    def test_new_wave_requires_timestamp_identity_count_and_final_state(self):
        self.page.set_content('<p>UTC-5</p>')
        row={'wave_number':'WAVEnew','creator':'tester','created_at':'11/23/2026 7:00:02 PM','packages':30,'status':'Created','source':'Wave Consolidation'}
        self.b.wave_snapshot=lambda c:[row]
        intent={'baseline':[],'creator':'tester','packages':30,'started':'2026-11-24T00:00:00+00:00'}
        self.assertEqual(self.b.wait_new_waves(intent,threading.Event()),[row])
        row['packages']=31
        with self.assertRaises(RuntimeError):self.b.wait_new_waves(intent,threading.Event())
        row.update(packages=30,status='Failed')
        with self.assertRaises(RuntimeError):self.b.wait_new_waves(intent,threading.Event())
    def test_confirmed_hold_is_never_canceled(self):
        row={'wave_number':'WAVEown','creator':'tester','packages':20,'status':'Confirmed'}
        self.b.wave_snapshot=lambda c:[row]
        calls=[]
        with self.assertRaises(RuntimeError):self.b.cancel_owned_wave(row,lambda:calls.append('intent'),threading.Event())
        self.assertEqual(calls,[])
    def test_cancel_exact_owned_wave_and_wait_for_canceled(self):
        row={'wave_number':'WAVEown','creator':'tester','packages':20,'status':'Created'}
        html='''<input placeholder="Please enter"><button onclick="fetch('/search')">Search</button><table><tr><td>WAVEown</td><td><span onclick="document.querySelector('#modal').hidden=false">Cancel</span></td></tr></table><div id="modal" role="dialog" hidden>Cancel wave?<button onclick="this.parentElement.hidden=true">OK</button></div>'''
        self.page.route('**/*',lambda r:r.fulfill(content_type='text/html',body=html))
        self.page.goto('https://wms-ttp.tiktokw.us/test-fixture')
        count=[0]
        def snapshot(c):
            count[0]+=1
            return [{**row,'status':'Created' if count[0]==1 else 'Canceled'}]
        self.b.wave_snapshot=snapshot;calls=[]
        self.b.cancel_owned_wave(row,lambda:calls.append('intent'),threading.Event())
        self.assertEqual(calls,['intent']);self.assertGreaterEqual(count[0],2)
    def test_fresh_search_dash_plus_empty_table_is_zero(self):
        html='''<button>Reset</button><div>One item only</div><button onclick="fetch('/query')">Search</button><p>Total package: -</p><table><tr><td>No data available</td></tr></table>'''
        self.page.route('**/*',lambda r:r.fulfill(content_type='text/html',body=html));self.page.goto('https://wms-ttp.tiktokw.us/query-fixture')
        self.b.ensure_wave_page=lambda:None
        result=self.b.query(default_phases()[15],[],[],default_config(),quantity=(None,None))
        self.assertEqual(result['total_packages'],0)
    def test_cache_recovery_retains_cookie_and_storage(self):
        self.b.context=self.page.context
        self.b.context.route('**/*',lambda r:r.fulfill(content_type='text/html',body='<button>Reset</button>'))
        self.page.goto('https://wms-ttp.tiktokw.us/outbound/waveManagementInfo/wave-summary')
        self.page.evaluate("localStorage.setItem('fixture','retained')")
        self.b.context.add_cookies([{'name':'fixture','value':'retained','url':'https://wms-ttp.tiktokw.us'}])
        for reopen in (False,True):
            self.b.recover_query_page(reopen=reopen)
            self.assertEqual(self.b.page.evaluate("localStorage.getItem('fixture')"),'retained')
            self.assertEqual(self.b.context.cookies()[0]['value'],'retained')
        self.b.page.close()
