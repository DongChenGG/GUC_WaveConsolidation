import copy
import threading
import unittest
from wms_assistant.rounds import RoundRunner,steps_for,candidate_threshold,scoped_phases
from wms_assistant.core import default_config,aisle_pairs

class Fake:
    def __init__(self):self.queries=[];self.writes=[];self.cancels=[];self.rows=[];self.number=0
    def recover_query_page(self,reopen=False):pass
    def identity(self):return 'tester','WH1'
    def query(self,p,pairs,v,c,quantity=None,tab_override=None):
        self.queries.append((p.name,list(pairs),list(v),quantity,tab_override))
        return {'total_packages':20 if self.cancels and p.id==103 else 0,'quantity_range':quantity}
    def wave_snapshot(self,c):return copy.deepcopy(self.rows)
    def consolidate(self,strategy,before,stop,receipt_via_table=False):before();self.writes.append(strategy)
    def wait_new_waves(self,intent,stop):
        self.number+=1
        row={'wave_number':f'WAVE{self.number}','creator':'tester','packages':intent['packages'],'status':'Created','created_at':'date'}
        self.rows.append(row);return [row]
    def cancel_owned_wave(self,w,before,stop):before();self.cancels.append(w['wave_number'])

class RoundTests(unittest.TestCase):
    def runner(self,b=None,data=None):
        self.saved=[];self.stop=threading.Event();self.b=b or Fake();self.data=data or {'waves':[],'runs':[]}
        return RoundRunner(self.b,self.data,lambda d:self.saved.append(copy.deepcopy(d)),lambda *a:None,self.stop,default_config())
    def test_round_order_and_tail_isolates_before_single_multis(self):
        self.assertEqual([k for k,_ in steps_for('first')],['hold_top','hold_single','multis','cancel_single','single','cancel_top','top','audit'])
        self.assertEqual([k for k,_ in steps_for('last')],['hold_top','single','multis','cancel_top','top','audit'])
        self.assertNotIn('cancel_top',[k for k,_ in steps_for('second')])
    def test_all_kinds_have_ground_and_shelf_height_batches(self):
        for kind in ('single','top'):
            phases=scoped_phases(kind)
            self.assertEqual(len(phases),7)
            for p in phases[1:]:
                self.assertTrue(p.grouped);self.assertEqual(len(p.zone_types),1);self.assertEqual(len(p.virtual_zones),1)
    def test_empty_round_finishes_without_any_write(self):
        r=self.runner();r.execute('first');self.assertEqual(self.b.writes,[])
        self.assertEqual(self.data['runs'][-1]['status'],'complete')
    def test_second_keeps_owned_top_holds(self):
        data={'runs':[],'waves':[{'wave_number':'held','purpose':'top','state':'held','creator':'tester','warehouse':'WH1','packages':20}]}
        r=self.runner(data=data);r.execute('second');self.assertEqual(self.b.cancels,[])
        self.assertEqual(data['waves'][0]['state'],'held')
    def test_last_cancels_only_owned_account_warehouse_holds(self):
        waves=[{'wave_number':'ours','purpose':'top','state':'held','creator':'tester','warehouse':'WH1','packages':20},
               {'wave_number':'other','purpose':'top','state':'held','creator':'other','warehouse':'WH1','packages':20},
               {'wave_number':'warehouse','purpose':'top','state':'held','creator':'tester','warehouse':'WH2','packages':20},
               {'wave_number':'released','purpose':'release_top','state':'released','creator':'tester','warehouse':'WH1','packages':20}]
        r=self.runner(data={'runs':[],'waves':waves});r.execute('last');self.assertEqual(self.b.cancels,['ours'])
    def test_threshold_maximizes_under_cap_without_overflow(self):
        threshold,counts=candidate_threshold(lambda n:3000-n*20,2000)
        self.assertEqual(threshold,50);self.assertEqual(counts[threshold],2000)
        threshold,_=candidate_threshold(lambda n:2500 if n<150 else 1800,2000)
        self.assertEqual(threshold,150)
        threshold,_=candidate_threshold(lambda n:3000,2000);self.assertIsNone(threshold)
    def test_three_aisles_extend_without_crossing_type(self):
        r=self.runner();p=scoped_phases('single')[1]
        values=iter([10,20]);self.b.query=lambda *a,**kw:{'total_packages':next(values)}
        result=list(r.batches(p,1,3,'One item only',True))
        self.assertEqual(result[0][0],[124,126,128,130])
        self.assertEqual(result[0][1],['TT PALLET L'])
    def test_changed_count_stops_before_write(self):
        r=self.runner();r.creator='tester';r.warehouse='WH1';r.run={'id':'run','mode':'first','top_released':0}
        with self.assertRaises(RuntimeError):r.write(scoped_phases('single')[0],[],[],{'total_packages':20},'release_single',1,3,'One item only')
        self.assertEqual(self.b.writes,[]);self.assertFalse(self.data.get('pending'))
    def test_ambiguous_create_is_durable_and_blocks_new_round(self):
        r=self.runner();r.creator='tester';r.warehouse='WH1';r.run={'id':'run','mode':'first','top_released':0}
        self.b.query=lambda *a,**kw:{'total_packages':20}
        self.b.wait_new_waves=lambda *a:(_ for _ in ()).throw(RuntimeError('timeout'))
        with self.assertRaises(RuntimeError):r.write(scoped_phases('single')[0],[],[],{'total_packages':20},'release_single',1,3,'One item only')
        self.assertEqual(self.data['pending']['packages'],20)
        with self.assertRaises(RuntimeError):r.execute('first')
        self.assertEqual(len(self.b.writes),1)
    def test_first_top_guard_checks_cumulative_budget(self):
        r=self.runner();r.creator='tester';r.warehouse='WH1';r.run={'id':'run','mode':'first','top_released':1990}
        self.b.query=lambda *a,**kw:{'total_packages':20}
        with self.assertRaises(RuntimeError):r.write(scoped_phases('top')[0],[],[],{'total_packages':20},'release_top',100,999,'One item only')
        self.assertFalse(self.b.writes)

    def test_fallback_clears_zones_retains_class_and_small_batches(self):
        r=self.runner();r.run={'mode':'last'};calls=[]
        r.query=lambda p,a,v,lo,hi,tab: (calls.append((a,v,lo,hi,tab)) or {'total_packages':2})
        r.write=lambda *args: calls.append(args[4])
        r.fallback('single',1,5)
        self.assertEqual(calls,[([],[],1,5,'One item only'),'release_single'])
        calls.clear();r.fallback('multis',None,None)
        self.assertEqual(len(calls),6)
        self.assertTrue(all(x[0]==[] and x[1]==[] for x in calls[::2]))
    def test_fallback_top_does_not_exceed_remaining_budget(self):
        r=self.runner();r.run={'mode':'first','top_released':1999}
        r.query=lambda *a:{'total_packages':2}
        r.write=lambda *a:self.fail('over budget')
        r.fallback('top',100,999)
        self.assertEqual(len(r.run['deferred_top']),1)
    def test_query_timeout_retries_only_reads_twice(self):
        from playwright.sync_api import TimeoutError
        r=self.runner();r.creator='tester';r.warehouse='WH1';recover=[]
        self.b.recover_query_page=lambda reopen=False:recover.append(reopen)
        self.b.query=lambda *a,**kw:(_ for _ in ()).throw(TimeoutError('timeout'))
        with self.assertRaises(TimeoutError):r.query(scoped_phases('single')[0],[],[])
        self.assertEqual(recover,[False,True]);self.assertFalse(self.b.writes)
        recover.clear();r.data['pending']={'kind':'create'}
        with self.assertRaises(TimeoutError):r.query(scoped_phases('single')[0],[],[])
        self.assertEqual(recover,[])
    def test_periodic_refresh_and_business_errors(self):
        r=self.runner();r.creator='tester';r.warehouse='WH1';r.query_count=40;recover=[]
        self.b.recover_query_page=lambda reopen=False:recover.append(reopen)
        r.query(scoped_phases('single')[0],[],[])
        self.assertEqual(recover,[False]);recover.clear()
        self.b.query=lambda *a,**kw:(_ for _ in ()).throw(RuntimeError('ambiguous'))
        with self.assertRaises(RuntimeError):r.query(scoped_phases('single')[0],[],[])
        self.assertEqual(recover,[])
