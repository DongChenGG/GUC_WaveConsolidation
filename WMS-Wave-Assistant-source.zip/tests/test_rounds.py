import copy
import threading
import unittest
from wms_assistant.rounds import RoundRunner,steps_for,candidate_threshold,scoped_phases
from wms_assistant.core import default_config,aisle_pairs

class Fake:
    def __init__(self):self.queries=[];self.writes=[];self.cancels=[];self.rows=[];self.number=0
    def recover_query_page(self,reopen=False):pass
    def identity(self):return 'tester','WH1'
    def query(self,p,pairs,v,c,quantity=None,tab_override=None):
        self.queries.append((p.name,list(pairs),list(v),quantity,tab_override))
        return {'total_packages':20 if self.cancels and p.id==103 else 0,'quantity_range':quantity}
    def wave_snapshot(self,c):return copy.deepcopy(self.rows)
    def consolidate(self,strategy,before,stop,receipt_via_table=False):before();self.writes.append(strategy)
    def wait_new_waves(self,intent,stop):
        self.number+=1
        row={'wave_number':f'WAVE{self.number}','creator':'tester','packages':intent['packages'],'status':'Created','created_at':'date'}
        self.rows.append(row);return [row]
    def cancel_owned_wave(self,w,before,stop):before();self.cancels.append(w['wave_number'])

class RoundTests(unittest.TestCase):
    def runner(self,b=None,data=None):
        self.saved=[];self.stop=threading.Event();self.b=b or Fake();self.data=data or {'waves':[],'runs':[]}
        return RoundRunner(self.b,self.data,lambda d:self.saved.append(copy.deepcopy(d)),lambda *a:None,self.stop,default_config())
    def test_round_order_and_tail_isolates_before_single_multis(self):
        self.assertEqual([k for k,_ in steps_for('first')],['hold_top','hold_single','multis','cancel_single','single','cancel_top','top','audit'])
        self.assertEqual([k for k,_ in steps_for('last')],['hold_top','single','multis','cancel_top','top','audit'])
        self.assertNotIn('cancel_top',[k for k,_ in steps_for('second')])
    def test_all_kinds_have_ground_and_shelf_height_batches(self):
        for kind in ('single','top'):
            phases=scoped_phases(kind)
            self.assertEqual(len(phases),7)
            for p in phases[1:]:
                self.assertEqual(p.grouped,p.zone_types==['Box']);self.assertEqual(len(p.zone_types),1);self.assertEqual(len(p.virtual_zones),1)
    def test_empty_round_finishes_without_any_write(self):
        r=self.runner();r.execute('first');self.assertEqual(self.b.writes,[])
        self.assertEqual(self.data['runs'][-1]['status'],'complete')
    def test_second_keeps_owned_top_holds(self):
        data={'runs':[],'waves':[{'wave_number':'held','purpose':'top','state':'held','creator':'tester','warehouse':'WH1','packages':20}]}
        r=self.runner(data=data);r.execute('second');self.assertEqual(self.b.cancels,[])
        self.assertEqual(data['waves'][0]['state'],'held')
    def test_last_cancels_only_owned_account_warehouse_holds(self):
        waves=[{'wave_number':'ours','purpose':'top','state':'held','creator':'tester','warehouse':'WH1','packages':20},
               {'wave_number':'other','purpose':'top','state':'held','creator':'other','warehouse':'WH1','packages':20},
               {'wave_number':'warehouse','purpose':'top','state':'held','creator':'tester','warehouse':'WH2','packages':20},
               {'wave_number':'released','purpose':'release_top','state':'released','creator':'tester','warehouse':'WH1','packages':20}]
        r=self.runner(data={'runs':[],'waves':waves});r.execute('last');self.assertEqual(self.b.cancels,['ours'])
    def test_threshold_maximizes_under_cap_without_overflow(self):
        threshold,counts=candidate_threshold(lambda n:3000-n*20,2000)
        self.assertEqual(threshold,50);self.assertEqual(counts[threshold],2000)
        threshold,_=candidate_threshold(lambda n:2500 if n<150 else 1800,2000)
        self.assertEqual(threshold,150)
        threshold,_=candidate_threshold(lambda n:3000,2000);self.assertIsNone(threshold)
    def test_whole_pallet_has_no_aisle_filter_and_defers_small_count(self):
        r=self.runner();p=scoped_phases('single')[1]
        result=list(r.batches(p,1,3,'One item only',True))
        self.assertEqual(result,[])
        self.assertEqual(self.b.queries[0][1],[])
        self.assertEqual(self.b.queries[0][2],['TT PALLET L'])
    def test_changed_count_uses_latest_search_and_submits_once(self):
        r=self.runner();r.creator='tester';r.warehouse='WH1';r.run={'id':'run','mode':'first','top_released':0}
        self.b.query=lambda *a,**kw:{'total_packages':2833}
        r.write(scoped_phases('single')[0],[],[],{'total_packages':2827},'release_single',1,3,'One item only')
        self.assertEqual(len(self.b.writes),1);self.assertIsNone(self.data.get('pending'))
        self.assertEqual(self.data['waves'][0]['packages'],2833)
    def test_ambiguous_create_is_durable_and_blocks_new_round(self):
        r=self.runner();r.creator='tester';r.warehouse='WH1';r.run={'id':'run','mode':'first','top_released':0}
        self.b.query=lambda *a,**kw:{'total_packages':40}
        self.b.wait_new_waves=lambda *a:(_ for _ in ()).throw(RuntimeError('timeout'))
        with self.assertRaises(RuntimeError):r.write(scoped_phases('single')[0],[],[],{'total_packages':40},'release_single',1,3,'One item only')
        self.assertEqual(self.data['pending']['packages'],40)
        with self.assertRaises(RuntimeError):r.execute('first')
        self.assertEqual(len(self.b.writes),1)
    def test_first_top_guard_checks_cumulative_budget(self):
        r=self.runner();r.creator='tester';r.warehouse='WH1';r.run={'id':'run','mode':'first','top_released':1990}
        self.b.query=lambda *a,**kw:{'total_packages':40}
        with self.assertRaises(RuntimeError):r.write(scoped_phases('top')[0],[],[],{'total_packages':40},'release_top',100,999,'One item only')
        self.assertFalse(self.b.writes)

    def test_fallback_clears_zones_retains_class_and_small_batches(self):
        r=self.runner();r.run={'mode':'last'};calls=[]
        r.query=lambda p,a,v,lo,hi,tab: (calls.append((a,v,lo,hi,tab)) or {'total_packages':2})
        r.write=lambda *args: calls.append(args[4])
        r.fallback('single',1,5)
        self.assertEqual(calls,[([],[],1,5,'One item only')])
        calls.clear();r.fallback('multis',None,None)
        self.assertEqual(len(calls),1)
        self.assertTrue(all(x[0]==[] and x[1]==[] for x in calls[::2]))
    def test_fallback_top_does_not_exceed_remaining_budget(self):
        r=self.runner();r.run={'mode':'first','top_released':1999}
        r.query=lambda *a:{'total_packages':2}
        r.write=lambda *a:self.fail('over budget')
        r.fallback('top',100,999)
        self.assertEqual(len(r.run['deferred_batches']),1)
    def test_query_timeout_retries_only_reads_twice(self):
        from playwright.sync_api import TimeoutError
        r=self.runner();r.creator='tester';r.warehouse='WH1';recover=[]
        self.b.recover_query_page=lambda reopen=False:recover.append(reopen)
        self.b.query=lambda *a,**kw:(_ for _ in ()).throw(TimeoutError('timeout'))
        with self.assertRaises(TimeoutError):r.query(scoped_phases('single')[0],[],[])
        self.assertEqual(recover,[False,True]);self.assertFalse(self.b.writes)
        recover.clear();r.data['pending']={'kind':'create'}
        with self.assertRaises(TimeoutError):r.query(scoped_phases('single')[0],[],[])
        self.assertEqual(recover,[])
    def test_periodic_refresh_and_business_errors(self):
        r=self.runner();r.creator='tester';r.warehouse='WH1';r.query_count=40;r.cfg['refresh_every_queries']=40;recover=[]
        self.b.recover_query_page=lambda reopen=False:recover.append(reopen)
        r.query(scoped_phases('single')[0],[],[])
        self.assertEqual(recover,[False]);recover.clear()
        self.b.query=lambda *a,**kw:(_ for _ in ()).throw(RuntimeError('ambiguous'))
        with self.assertRaises(RuntimeError):r.query(scoped_phases('single')[0],[],[])
        self.assertEqual(recover,[])

    def test_resume_verified_hold_skips_top_and_preserves_run(self):
        r=self.runner(data={'waves':[], 'runs':[{'id':'existing','mode':'first','status':'paused','creator':'tester','warehouse':'WH1','top_released':0,'next_step':1,'resume_ready':True}]})
        steps=[]
        r.hold=lambda kind,*a:steps.append('hold_'+kind)
        r.release_multis=lambda:steps.append('multis')
        r.release=lambda *a:None;r.release_top=lambda *a:None;r.cancel=lambda *a:None;r.audit=lambda:None
        r.resume()
        self.assertEqual(steps[:2],['hold_single','multis'])
        self.assertNotIn('hold_top',steps);self.assertEqual(len(r.data['runs']),1)
        self.assertEqual(r.run['status'],'complete')
    def test_resume_refuses_pending_or_wrong_account(self):
        r=self.runner(data={'pending':{'kind':'create'},'waves':[], 'runs':[]})
        with self.assertRaises(RuntimeError):r.resume()
        r.data['pending']=None
        r.data['runs']=[{'mode':'first','status':'paused','creator':'other','warehouse':'WH1','resume_ready':True}]
        with self.assertRaises(RuntimeError):r.resume()
    def test_quantity_difference_registered_as_actual_without_retry(self):
        r=self.runner();r.creator='tester';r.warehouse='WH1';r.run={'id':'run','mode':'first','top_released':0}
        self.b.query=lambda *a,**kw:{'total_packages':2567}
        self.b.wait_new_waves=lambda *a:[{'wave_number':'WAVE052','creator':'tester','packages':3131,'status':'Created'}]
        r.write(scoped_phases('top')[0],[],[],{'total_packages':2567},'top',6,999,'One item only')
        self.assertEqual(r.data['waves'][0]['packages'],3131)
        self.assertEqual(r.data['waves'][0]['state'],'held')
        self.assertEqual(r.run['quantity_differences'][0]['actual'],3131)
        self.assertIsNone(r.data['pending']);self.assertEqual(len(self.b.writes),1)

    def test_zero_latest_search_skips_consolidation(self):
        r=self.runner();r.creator='tester';r.warehouse='WH1';r.run={'id':'run','mode':'first','top_released':0}
        r.write(scoped_phases('single')[0],[],[],{'total_packages':20},'release_single',1,3,'One item only')
        self.assertEqual(self.b.writes,[])

    def test_old_count_pause_recovers_unsubmitted_hold(self):
        data={'waves':[],'runs':[{'id':'r','mode':'first','creator':'tester','warehouse':'WH1','status':'paused','top_released':0,'resume_ready':False,'error':'提交前包裹数发生变化，已暂停；本批尚未提交'}]}
        r=self.runner(data=data);calls=[]
        r.hold=lambda kind,*a:calls.append(kind)
        r.release_multis=lambda:None;r.release=lambda *a:None;r.release_top=lambda *a:None;r.cancel=lambda *a:None;r.audit=lambda:None
        r.resume()
        self.assertEqual(calls,['top','single']);self.assertEqual(data['runs'][0]['status'],'complete')

    def test_only_box_extends_small_batches(self):
        for kind in ('multis','single','top'):
            for p in scoped_phases(kind):
                if len(p.zone_types)!=1:continue
                r=self.runner();calls=[]
                def query(*args,**kw):
                    calls.append(list(args[1]));return {'total_packages':10 if len(calls)==1 else 40}
                self.b.query=query
                groups=list(r.batches(p,None,None,'All',True))
                if p.zone_types==['Box']:
                    self.assertEqual(calls[:2],[[130,132,134],[130,132,134,136]])
                    self.assertTrue(all(130<=a<=178 for c in calls for a in c))
                else:
                    self.assertEqual(len(calls),1)
                    self.assertEqual(groups,[])
                    self.assertEqual(calls,[[]])

    def test_multis_uses_all_once_per_scope(self):
        r=self.runner();r.run={'mode':'first'};calls=[];writes=[]
        r.query=lambda p,a,v,lo,hi,tab:(calls.append((p.name,tab)) or {'total_packages':1})
        r.write=lambda *a:writes.append(a[-1])
        r.release_multis()
        self.assertTrue(all(t=='All' for _,t in calls))
        self.assertEqual(sum(n=='地堆 Multis' for n,t in calls),1)
        self.assertTrue(all(t=='All' for t in writes))

    def test_preserved_query_avoids_requery_and_second_baseline_scan(self):
        r=self.runner();r.creator='tester';r.warehouse='WH1';r.run={'id':'r','mode':'first','top_released':0}
        self.b.preserves_query_for_receipts=True
        scans=[];self.b.wave_snapshot=lambda c:(scans.append(c) or [])
        self.b.query=lambda *a,**kw:self.fail('Unexpected repeat Search')
        for _ in range(2):r.write(scoped_phases('single')[0],[],[],{'total_packages':40},'release_single',1,3,'One item only')
        self.assertEqual(scans,['tester']);self.assertEqual(len(self.b.writes),2)
        self.assertEqual(len(r.receipt_baseline),2)

    def test_stopped_multis_resumes_without_reholding_single_top(self):
        data={'waves':[{'wave_number':'old','purpose':'release_multis','state':'released'}],'runs':[{'id':'r','mode':'first','creator':'tester','warehouse':'WH1','status':'paused','next_step':2,'top_released':0,'resume_ready':False,'error':'已停止，尚未点击最终 OK；请人工关闭弹窗'}]}
        r=self.runner(data=data);calls=[]
        self.b.dismiss_unsubmitted_dialog=lambda:calls.append('close')
        r.hold=lambda *a:self.fail('Already held')
        r.release_multis=lambda:calls.append('multis')
        r.release=lambda *a:None;r.release_top=lambda *a:None;r.cancel=lambda *a:None;r.audit=lambda:None
        r.resume()
        self.assertEqual(calls,['close','multis']);self.assertEqual(len(data['waves']),1)

    def test_release_write_gate_rejects_small_even_if_caller_bypasses_batches(self):
        r=self.runner();r.creator='tester';r.warehouse='WH1';r.run={'id':'r','mode':'last','top_released':0}
        self.b.preserves_query_for_receipts=True
        for purpose in ('release_multis','release_single','release_top'):
            r.write(scoped_phases('single')[0],[],[],{'total_packages':29},purpose)
        self.assertEqual(self.b.writes,[])
        self.assertEqual(len(r.run['deferred_batches']),3)
    def test_audit_records_arrivals_without_loop_or_failure(self):
        r=self.runner();r.run={'mode':'last'};self.b.query=lambda *a,**kw:{'total_packages':2}
        r.audit();self.assertEqual(len(r.run['remaining']),6)
    def test_waiting_action_precedes_blocking_receipt(self):
        r=self.runner();r.creator='tester';r.warehouse='WH1';r.run={'id':'r','mode':'last','top_released':0};r.step=(1,'single','Single')
        actions=[];r.progress=lambda *a:actions.append(a[-1].get('action'))
        self.b.preserves_query_for_receipts=True
        original=self.b.wait_new_waves
        def wait(*a):
            self.assertEqual(actions[-1],'等待 WMS 生成波次');return original(*a)
        self.b.wait_new_waves=wait
        r.write(scoped_phases('single')[0],[],[],{'total_packages':40},'release_single')
        self.assertEqual(actions[-1],'已生成波次')
