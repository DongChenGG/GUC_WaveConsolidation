import threading
import unittest
from wms_assistant.rounds import RoundRunner, validate_targets
from wms_assistant.core import default_config
from test_rounds import Fake

class SmallFake(Fake):
    preserves_query_for_receipts=True
    def __init__(self,count):super().__init__();self.count=count
    def query(self,p,pairs,v,c,quantity=None,tab_override=None):
        self.queries.append((p.kind,list(v)))
        return {'total_packages':self.count}

class NewRulesTests(unittest.TestCase):
    def runner(self,b):
        return RoundRunner(b,{'waves':[],'runs':[]},lambda d:None,lambda *a:None,threading.Event(),default_config())
    def test_flex_zero_releases_small_scope_once(self):
        for kind in ('single','top','multis'):
            for scope in ('ground','pallet_l','box_h','bin_h'):
                for count in (1,2,29):
                    with self.subTest(kind=kind,scope=scope,count=count):
                        b=SmallFake(count);r=self.runner(b);key=kind+'_'+scope
                        r.execute('flex',selection=[key],package_targets={key:0})
                        self.assertEqual(len(b.writes),1)
                        self.assertEqual(r.data['waves'][0]['packages'],count)
    def test_flex_small_target(self):
        b=SmallFake(2);r=self.runner(b)
        self.assertEqual(validate_targets('flex',{'single_ground':2}),{'single_ground':2})
        r.execute('flex',selection=['single_ground'],package_targets={'single_ground':2})
        self.assertEqual(len(b.writes),1)
    def test_fixed_modes_keep_minimum(self):
        for mode in ('first','last'):
            r=self.runner(SmallFake(2));r.run={'mode':mode}
            self.assertEqual(r.minimum_release,30)
    def test_single_top_fallback_writes_stay_separated(self):
        for kind in ('single','top'):
            b=SmallFake(40);r=self.runner(b)
            r.run={'id':'run','mode':'last','top_released':0};r.creator='tester';r.warehouse='WH1'
            r.fallback(kind,6 if kind=='top' else None,999 if kind=='top' else None)
            self.assertEqual(len(b.writes),3)
            self.assertEqual(b.queries[0][1],['TTGROUND'])
            for _,zones in b.queries:
                self.assertTrue(zones)
                self.assertFalse('TTGROUND' in zones and len(zones)>1)
