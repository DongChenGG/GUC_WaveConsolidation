import unittest, threading, copy
from wms_assistant.rounds import RoundRunner,validate_targets
from wms_assistant.core import default_config
from test_rounds import Fake

class TargetFake(Fake):
    preserves_query_for_receipts=True
    def query(self,p,pairs,v,c,quantity=None,tab_override=None):
        self.queries.append(list(pairs))
        return {'total_packages':4800 if not pairs else 200*len(pairs)}

class TargetTests(unittest.TestCase):
    def runner(self,b,data=None):
        return RoundRunner(b,data or {'waves':[],'runs':[]},lambda d:None,lambda *a:None,threading.Event(),default_config())
    def test_split_is_finite_and_actual_counts_reach_target(self):
        b=TargetFake();r=self.runner(b);r.execute('flex',selection=['top_box_h'],package_targets={'top_box_h':2000})
        self.assertEqual(r.run['node_packages']['top_box_h'],2000)
        self.assertLess(len(b.queries),30)
        self.assertTrue(all(w['packages']>=30 for w in r.data['waves']))
    def test_actual_over_target_stops_next_write(self):
        b=TargetFake()
        def receipt(intent,stop):return [{'wave_number':'ONE','packages':2100,'status':'Created'}]
        b.wait_new_waves=receipt;r=self.runner(b)
        r.execute('flex',selection=['top_box_h'],package_targets={'top_box_h':2000})
        self.assertEqual(len(b.writes),1);self.assertEqual(r.run['node_packages']['top_box_h'],2100)
    def test_indivisible_ground_is_left_without_write(self):
        b=TargetFake();r=self.runner(b);r.execute('flex',selection=['top_ground'],package_targets={'top_ground':2000})
        self.assertFalse(b.writes);self.assertEqual(len(b.queries),1)
    def test_resume_keeps_actual_budget_and_partition(self):
        b=TargetFake();r=self.runner(b);original=b.wait_new_waves
        def receipt(intent,stop):
            rows=original(intent,stop);stop.set();return rows
        b.wait_new_waves=receipt
        with self.assertRaises(RuntimeError):r.execute('flex',selection=['top_box_h'],package_targets={'top_box_h':2000})
        first_total=r.run['node_packages']['top_box_h'];self.assertGreater(first_total,0)
        b.wait_new_waves=original;r2=self.runner(b,r.data);r2.resume()
        self.assertEqual(r2.run['node_packages']['top_box_h'],2000)
        self.assertEqual(sum(w['packages'] for w in r.data['waves']),2000)
    def test_validation_excludes_holds_and_invalid_targets(self):
        for targets in ({'top_box_h':-1},{'hold_top':2000},{'top_box_h':True}):
            with self.assertRaises(ValueError):validate_targets('flex',targets)
        with self.assertRaises(ValueError):validate_targets('first',{'top_box_h':2000})
