"""Use the live observed readonly calendar/time-picker structure."""
import unittest
from playwright.sync_api import sync_playwright
from wms_assistant.browser import WMSBrowser
class DatePickerTests(unittest.TestCase):
    def test_readonly_calendar_time_and_committed_values(self):
        with sync_playwright() as pw:
            browser=pw.chromium.launch(headless=True,executable_path=pw.chromium.executable_path)
            try:
                page=browser.new_page()
                page.set_content('''<div class="auxo-form-item"><label for="consignment_order_create_time">Outbound order created at</label><input readonly id="consignment_order_create_time" onclick="document.querySelector('.sp-picker-range').hidden=false"><input readonly></div>
<div class="sp-picker-range" hidden><div class="sp-picker-range-body"><input readonly onclick="idx=0"><input readonly onclick="idx=1"></div>
<table><tr><td class="auxo-picker-cell-in-view" title="2026-11-24" onclick="days[idx]='11/24/2026'">24</td><td class="auxo-picker-cell-in-view" title="2026-11-25" onclick="days[idx]='11/25/2026'">25</td></tr></table>
<div class="sp-picker-range-time"><input readonly value="00:00:00" onclick="timeIdx=0;document.querySelector('.auxo-picker-time-panel').hidden=false"></div>
<div class="sp-picker-range-time"><input readonly value="23:59:59" onclick="timeIdx=1;document.querySelector('.auxo-picker-time-panel').hidden=false"></div>
<div class="auxo-picker-time-panel" hidden></div><button onclick="document.querySelectorAll('.auxo-form-item input').forEach((e,i)=>e.value=days[i]+' 12:00:00 PM');this.parentElement.hidden=true">OK</button></div>
<script>let idx=0,timeIdx=0,days=[],times=[['00','00','00'],['23','59','59']];let panel=document.querySelector('.auxo-picker-time-panel');for(let c=0;c<3;c++){let ul=document.createElement('ul');ul.className='auxo-picker-time-panel-column';for(let n=0;n<(c?60:24);n++){let li=document.createElement('li');li.textContent=String(n).padStart(2,'0');li.onclick=()=>{times[timeIdx][c]=li.textContent;document.querySelectorAll('.sp-picker-range-time input')[timeIdx].value=times[timeIdx].join(':')};ul.append(li)}panel.append(ul)}document.addEventListener('keydown',e=>{if(e.key==='Escape')panel.hidden=true})</script>''')
                b=WMSBrowser.__new__(WMSBrowser);b.page=page
                b.set_outbound_created_range({'start':'2026-11-24T12:00:00-05:00','end':'2026-11-25T12:00:00-05:00'})
                self.assertEqual(page.locator('#consignment_order_create_time').input_value(),'11/24/2026 12:00:00 PM')
            finally:browser.close()
