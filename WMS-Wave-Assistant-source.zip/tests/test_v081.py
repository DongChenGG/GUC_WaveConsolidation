import copy,datetime as dt,threading,unittest
from wms_assistant.rounds import RoundRunner,tail_window,run_steps,flex_phases
from wms_assistant.core import default_config
from test_rounds import Fake
class CapturingFake(Fake):
    preserves_query_for_receipts=True
    def __init__(self):super().__init__();self.configs=[]
    def query(self,p,pairs,v,c,quantity=None,tab_override=None):
        self.configs.append(copy.deepcopy(c));self.queries.append((p.kind,pairs,v,quantity,tab_override))
        return {'total_packages':80,'quantity_range':quantity}
class NewRulesTests(unittest.TestCase):
    def runner(self,b):return RoundRunner(b,{'waves':[],'runs':[]},lambda d:None,lambda *a:None,threading.Event(),default_config())
    def test_noon_window_uses_eastern_not_computer_local(self):
        w=tail_window(dt.datetime(2026,11,25,3,tzinfo=dt.timezone.utc))
        self.assertEqual(w['start'],'2026-11-23T12:00:00-05:00');self.assertEqual(w['end'],'2026-11-24T12:00:00-05:00')
        w=tail_window(dt.datetime(2026,3,8,20,tzinfo=dt.timezone.utc))
        self.assertTrue(w['start'].endswith('-05:00'));self.assertTrue(w['end'].endswith('-04:00'))
    def test_old_tail_resume_keeps_old_indexes(self):
        self.assertEqual(run_steps({'mode':'last','plan_version':2})[0][0],'cancel_top')
        self.assertEqual(run_steps({'mode':'last','plan_version':3})[0][0],'top')
    def test_tail_applies_same_frozen_window_to_all_queries(self):
        b=CapturingFake();r=self.runner(b);r.execute('last')
        self.assertFalse(b.cancels)
        self.assertTrue(b.configs)
        self.assertTrue(all(c['outbound_created_range']==r.run['outbound_created_range'] for c in b.configs))
    def test_flex_hold_top_executes_query_and_actual_consolidation(self):
        b=CapturingFake();r=self.runner(b);r.execute('flex',selection=['hold_top'])
        self.assertEqual(b.queries[0][3:],((6,999),'One item only'))
        self.assertEqual(b.writes,['Top Selling - Single'])
        self.assertEqual(r.data['waves'][0]['purpose'],'top');self.assertEqual(r.data['waves'][0]['state'],'held')
    def test_every_flex_release_scope_uses_selected_filter_and_strategy(self):
        for key,phase in flex_phases().items():
            with self.subTest(key=key):
                b=CapturingFake();r=self.runner(b);r.execute('flex',selection=[key],release_limit=1)
                self.assertEqual(b.queries[0][2],phase.virtual_zones)
                self.assertEqual(b.writes,[phase.strategy]);self.assertFalse(b.cancels)
                self.assertTrue(all('outbound_created_range' not in c for c in b.configs))
