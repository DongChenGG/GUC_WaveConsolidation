import copy
import unittest
import test_rounds
from test_rounds import Fake
from wms_assistant.rounds import scoped_phases, finish_checkpoint

class BatchResumeTests(unittest.TestCase):
    runner=test_rounds.RoundTests.runner
    # Reuse setup helper only, not inherited tests.
    def test_box_resume_preserves_pending_range_and_skips_completed_range(self):
        r=self.runner();r.run={'id':'r','batch_progress':{}};r.step=(0,'single','Single')
        p=scoped_phases('single')[3];queries=[]
        r.query=lambda p,a,v,*rest:(queries.append(list(a)) or {'total_packages':600 if not a else 40})
        g=r.batches(p,1,4,'One item only',True)
        first=next(g)[0];finish_checkpoint(r.run,r.active_batch)
        second=next(g)[0]
        saved=copy.deepcopy(r.run);g.close()
        r2=self.runner();r2.run=saved;r2.step=r.step;r2.query=r.query
        queries.clear();g2=r2.batches(p,1,4,'One item only',True)
        resumed=next(g2)[0]
        self.assertEqual(second,resumed);self.assertNotEqual(first,resumed)
        self.assertEqual(queries,[second]);g2.close()

    def test_finished_scope_is_not_queried_after_restart(self):
        r=self.runner();r.run={'batch_progress':{}};r.step=(0,'single','Single')
        p=scoped_phases('single')[1]
        r.query=lambda *a:{'total_packages':40}
        g=r.batches(p,1,4,'One item only',True);next(g)
        finish_checkpoint(r.run,r.active_batch);g.close()
        r.query=lambda *a: self.fail('Completed scope queried again')
        self.assertEqual(list(r.batches(p,1,4,'One item only',True)),[])

    def test_query_failure_resume_stays_on_unfinished_scope(self):
        class Interrupted(Fake):
            def query(self,p,pairs,v,c,quantity=None,tab_override=None):
                self.queries.append(list(v))
                if v==['TT PALLET L'] and not getattr(self,'recovered',False):raise RuntimeError('temporary loading')
                return {'total_packages':40 if v else 0}
        b=Interrupted();r=self.runner(b)
        # No recovery retry needed for generic simulated page error.
        with self.assertRaisesRegex(RuntimeError,'temporary loading'):r.execute('last',selection=['single'])
        self.assertTrue(r.run['resume_ready']);self.assertEqual(len(b.writes),1)
        b.recovered=True;b.queries.clear();r2=self.runner(b,self.data);r2.resume()
        self.assertNotIn(['TTGround'],b.queries)
        self.assertEqual(r2.run['status'],'complete')
