import unittest,threading
from unittest.mock import Mock
from wms_assistant.desktop import DesktopControls,WindowAPI

class DesktopTests(unittest.TestCase):
    def test_closing_workspace_keeps_job_running_in_monitor(self):
        stop=threading.Event();c=DesktopControls(stop);c.main=Mock();c.mini=Mock()
        self.assertFalse(c.close_main());c.main.hide.assert_called_once();c.mini.show.assert_called_once()
        self.assertFalse(stop.is_set())
        c.expand();c.main.restore.assert_called_once();c.mini.hide.assert_called_once()
    def test_monitor_close_without_tray_restores_workspace(self):
        c=DesktopControls(threading.Event());c.main=Mock();c.mini=Mock()
        self.assertFalse(c.close_mini());c.main.show.assert_called_once()
    def test_tray_quit_stops_task_and_destroys_both_windows(self):
        stop=threading.Event();c=DesktopControls(stop);c.main=Mock();c.mini=Mock();c.tray=Mock()
        c.hide_monitor();c.mini.hide.assert_called_once();c.main.show.assert_not_called()
        c.quit();self.assertTrue(stop.is_set());self.assertTrue(c.close_main());c.tray.stop.assert_called_once()
        c.main.destroy.assert_called_once();c.mini.destroy.assert_called_once()
    def test_bridge_exposes_only_window_controls(self):
        api=WindowAPI(Mock())
        self.assertFalse(hasattr(api,'background'));api.pin(True);api._controls.pin.assert_called_once_with(True)
