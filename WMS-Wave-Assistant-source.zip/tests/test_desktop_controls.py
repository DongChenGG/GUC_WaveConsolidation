import unittest,threading
from unittest.mock import Mock
from wms_assistant.desktop import DesktopControls,WindowAPI
class DesktopTests(unittest.TestCase):
    def test_close_exits_instead_of_hiding(self):
        c=DesktopControls(threading.Event());c.main=Mock()
        self.assertTrue(c.close_main());self.assertTrue(c.stop.is_set());self.assertTrue(c.closed.is_set())
        c.main.hide.assert_not_called()
    def test_quit_destroys_once(self):
        c=DesktopControls(threading.Event());c.main=Mock();api=WindowAPI(c)
        api.quit();api.quit();c.main.destroy.assert_called_once()
        self.assertFalse(hasattr(api,'compact'))
