import unittest
from playwright.sync_api import sync_playwright
from wms_assistant.browser import WMSBrowser, URL

class NavigationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw=sync_playwright().start()
        cls.browser=cls.pw.chromium.launch(headless=True,executable_path=cls.pw.chromium.executable_path)
    @classmethod
    def tearDownClass(cls): cls.browser.close();cls.pw.stop()
    def setUp(self):
        self.context=self.browser.new_context()
        self.context.route('**/*',lambda r:r.fulfill(content_type='text/html',body='<button>Reset</button>' if 'wave-summary' in r.request.url else '<h1>Home</h1>'))
        self.adapter=WMSBrowser.__new__(WMSBrowser)
        self.adapter.context=self.context;self.adapter.page=self.context.new_page()
    def tearDown(self): self.context.close()
    def test_home_moves_to_wave_page(self):
        self.adapter.page.goto('https://wms-ttp.tiktokw.us/home')
        self.adapter.ensure_wave_page()
        self.assertEqual(self.adapter.page.url,URL)
    def test_closed_wms_window_is_recreated(self):
        self.adapter.page.close();self.adapter.ensure_wave_page()
        self.assertEqual(self.adapter.page.url,URL)
    def test_ready_wave_page_is_not_reloaded(self):
        self.adapter.page.goto(URL)
        self.adapter.page.evaluate('document.body.dataset.marker="keep"')
        self.adapter.ensure_wave_page()
        self.assertEqual(self.adapter.page.locator('body').get_attribute('data-marker'),'keep')

    def test_deep_link_redirect_uses_outbound_wave_menu(self):
        self.context.unroute('**/*')
        html = """<div role="menuitem" onclick="document.querySelector('#wave').hidden=false">Outbound</div>
        <div id="wave" role="menuitem" hidden onclick="document.querySelector('#destination').hidden=false">Wave</div>
        <div id="destination" role="menuitem" hidden onclick="history.pushState({},'', '/outbound/waveManagementInfo/wave-summary');document.querySelector('#reset').hidden=false">Wave Consolidation</div>
        <button id="reset" hidden>Reset</button>
        <script>history.replaceState({},'', '/home')</script>"""
        self.context.route('**/*',lambda route:route.fulfill(content_type='text/html',body=html))
        self.adapter.page.goto('https://wms-ttp.tiktokw.us/home')
        self.adapter.ensure_wave_page()
        self.assertEqual(self.adapter.page.url, URL)
        self.assertTrue(self.adapter.page.get_by_role('button',name='Reset').is_visible())

    def test_loading_current_route_waits_without_clicking_outbound(self):
        self.adapter.page.goto(URL)
        self.adapter.page.set_content('''<div role="menuitem" onclick="document.body.dataset.clicked='yes'">Outbound</div><button hidden id="r">Reset</button><script>setTimeout(()=>document.querySelector('#r').hidden=false,400)</script>''')
        self.adapter.ensure_wave_page()
        self.assertIsNone(self.adapter.page.locator('body').get_attribute('data-clicked'))

    def test_identity_uses_english_form_without_language_header(self):
        self.adapter.page.goto(URL)
        self.adapter.page.set_content('<button>Reset</button><button><img alt="Profile Photo">tester WH1</button>')
        self.assertEqual(self.adapter.identity(),('tester','WH1'))

    def test_expired_session_is_explicit(self):
        self.adapter.page.goto('https://wms-ttp.tiktokw.us/login')
        with self.assertRaisesRegex(RuntimeError,'登录已过期'):self.adapter.check_session()
