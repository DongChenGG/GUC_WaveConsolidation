import unittest
from playwright.sync_api import sync_playwright
from wms_assistant.browser import WMSBrowser, URL

class NavigationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw=sync_playwright().start()
        cls.browser=cls.pw.chromium.launch(headless=True,executable_path=cls.pw.chromium.executable_path)
    @classmethod
    def tearDownClass(cls): cls.browser.close();cls.pw.stop()
    def setUp(self):
        self.context=self.browser.new_context()
        self.context.route('**/*',lambda r:r.fulfill(content_type='text/html',body='<button>Reset</button>' if 'wave-summary' in r.request.url else '<h1>Home</h1>'))
        self.adapter=WMSBrowser.__new__(WMSBrowser)
        self.adapter.context=self.context;self.adapter.page=self.context.new_page()
    def tearDown(self): self.context.close()
    def test_home_moves_to_wave_page(self):
        self.adapter.page.goto('https://wms-ttp.tiktokw.us/home')
        self.adapter.ensure_wave_page()
        self.assertEqual(self.adapter.page.url,URL)
    def test_closed_wms_window_is_recreated(self):
        self.adapter.page.close();self.adapter.ensure_wave_page()
        self.assertEqual(self.adapter.page.url,URL)
    def test_ready_wave_page_is_not_reloaded(self):
        self.adapter.page.goto(URL)
        self.adapter.page.evaluate('document.body.dataset.marker="keep"')
        self.adapter.ensure_wave_page()
        self.assertEqual(self.adapter.page.locator('body').get_attribute('data-marker'),'keep')
