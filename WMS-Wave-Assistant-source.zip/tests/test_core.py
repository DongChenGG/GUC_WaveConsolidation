import unittest
from wms_assistant.core import *

class RulesTests(unittest.TestCase):
    def test_boundary_aisles(self):
        self.assertEqual(aisle_pairs(['Pallet']),[124,126,128,130])
        self.assertEqual(aisle_pairs(['Box'])[0],130)
        self.assertEqual(aisle_pairs(['Box'])[-1],178)
        self.assertEqual(aisle_pairs(['Bin']),[178,180,182,184,186,188,190])
    def test_full_aisle_halves(self):
        self.assertEqual(zone_values([124,126,128]),['124-125-1','124-125-2','126-127-1','126-127-2','128-129-1','128-129-2'])
    def test_mixed_ranges_deduplicate_boundaries(self):
        combined=aisle_pairs(['Pallet','Box','Bin'])
        self.assertEqual(combined,list(range(124,191,2)))
        self.assertEqual(len(combined),34)
    def test_order_and_manual_gates(self):
        p=default_phases()
        self.assertEqual(len(p),30)
        self.assertEqual([x.id for x in p if x.manual],[14,15,23])
        self.assertEqual(p[6].virtual_zones,['TT BIN H'])
        self.assertTrue(all(x.kind=='single' for x in p[15:22]))
        self.assertTrue(all(x.kind=='top' for x in p[23:30]))
        self.assertTrue(all(not x.grouped for x in p[7:13]))
    def test_ground_never_in_regular_shelf_variants(self):
        p=default_phases()
        self.assertNotIn('TTGROUND',list(variants(p[11]))[0][1])
        self.assertIn('TTGROUND',list(variants(p[12]))[0][1])
        self.assertEqual([x[0] for x in variants(p[11])],['L','H'])
    def test_invalid_settings_rejected(self):
        for key,value in [('min_packages',0),('initial_aisles',0),('virtual_operator','Equal')]:
            cfg=default_config();cfg[key]=value
            with self.assertRaises(ValueError):validate_config(cfg)
    def test_manual_gate_cannot_be_edited_away(self):
        p=default_phases()[14]; d=p.to_dict();d['manual']=False
        with self.assertRaises(ValueError):validate_phase(d,p)

if __name__=='__main__':unittest.main()
