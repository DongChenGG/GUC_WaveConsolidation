import os,sys,time,tempfile,subprocess,unittest
from pathlib import Path
@unittest.skipUnless(sys.platform=='win32','Windows Job Object lifecycle')
class ProcessCleanupTests(unittest.TestCase):
    def test_forced_parent_exit_kills_owned_child(self):
        import ctypes as c
        from ctypes import wintypes as w
        k=c.WinDLL('kernel32',use_last_error=True)
        k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.OpenProcess.restype=w.HANDLE
        k.GetExitCodeProcess.argtypes=[w.HANDLE,c.POINTER(w.DWORD)];k.CloseHandle.argtypes=[w.HANDLE]
        script="from wms_assistant.lifecycle import own_process_tree; own_process_tree(); import subprocess,sys,time; from pathlib import Path; child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(120)']); Path(sys.argv[1]).write_text(str(child.pid)); time.sleep(120)"
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'child.pid';parent=subprocess.Popen([sys.executable,'-c',script,str(path)])
            handle=None
            try:
                deadline=time.monotonic()+15
                while not path.exists() and time.monotonic()<deadline:time.sleep(.1)
                self.assertTrue(path.exists(),'Job child did not start')
                handle=k.OpenProcess(0x1000,False,int(path.read_text()));self.assertTrue(handle)
                parent.kill();parent.wait(timeout=5)
                code=w.DWORD(259);deadline=time.monotonic()+5
                while code.value==259 and time.monotonic()<deadline:
                    k.GetExitCodeProcess(handle,c.byref(code));time.sleep(.1)
                self.assertNotEqual(code.value,259,'Owned browser-style child survived parent termination')
            finally:
                if parent.poll() is None:parent.kill();parent.wait(timeout=5)
                if handle:k.CloseHandle(handle)
