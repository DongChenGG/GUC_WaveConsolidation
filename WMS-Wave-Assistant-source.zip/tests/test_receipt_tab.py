import unittest
from wms_assistant.browser import receipt_page
class Page:
    def __init__(self):self.visits=[]
    def is_closed(self):return False
    def set_default_timeout(self,x):pass
    def goto(self,url,**kwargs):self.visits.append(url)
class Context:
    def __init__(self):self.pages=[]
    def new_page(self):
        p=Page();self.pages.append(p);return p
class Browser:
    def __init__(self):self.page=Page();self.context=Context()
    @receipt_page
    def snapshot(self,fail=False):
        if fail:raise RuntimeError('timeout')
        return self.page
    @receipt_page
    def nested(self):return self.snapshot()
class ReceiptTabTests(unittest.TestCase):
    def test_reuse_nested_tab_restore_main_on_success_and_error(self):
        b=Browser();original=b.page
        receipt=b.snapshot();self.assertIsNot(receipt,original);self.assertIs(b.page,original)
        self.assertIs(b.nested(),receipt)
        with self.assertRaises(RuntimeError):b.snapshot(True)
        self.assertIs(b.page,original);self.assertEqual(len(b.context.pages),1)
        self.assertEqual(original.visits,[])
