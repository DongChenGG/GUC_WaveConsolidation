"""Regression for the Auxo selected-label overlay reported by the user."""
import unittest
from playwright.sync_api import sync_playwright, TimeoutError
from wms_assistant.browser import WMSBrowser

class SelectTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw=sync_playwright().start()
        cls.browser=cls.pw.chromium.launch(headless=True,executable_path=cls.pw.chromium.executable_path)
    @classmethod
    def tearDownClass(cls): cls.browser.close();cls.pw.stop()
    def setUp(self):
        self.page=self.browser.new_page();self.page.set_default_timeout(1500)
        self.adapter=WMSBrowser.__new__(WMSBrowser);self.adapter.page=self.page
    def tearDown(self): self.page.close()
    def fixture(self, field='logical_zone_op_type', multi=False):
        self.page.set_content('''<style>.auxo-select-selector{position:relative;width:220px;height:40px;border:1px solid}input{position:absolute;inset:0;width:210px}.auxo-select-selection-item{position:absolute;inset:0;background:white;z-index:2}</style>
        <div class="auxo-select-selector" onclick="document.querySelector('#menu').hidden=false">
        <input readonly role="combobox" id="'''+field+'''" aria-controls="choices" onkeydown="if(event.key==='Escape')document.querySelector('#menu').hidden=true">
        <span class="auxo-select-selection-item" title="Include">Include</span></div>
        <div class="auxo-select-dropdown" id="menu" hidden><div id="choices" role="listbox"></div>
        <div title="Include" onclick="document.querySelector('#result').textContent='Include';this.parentElement.hidden=true">Include</div>
        <div title="Totally included" onclick="document.querySelector('#result').textContent='Totally included';this.parentElement.hidden=true">Totally included</div>
        <div title="TT Pallet L" onclick="document.querySelector('#result').textContent+='L'">TT Pallet L</div>
        <div title="TT Pallet H" onclick="document.querySelector('#result').textContent+='H'">TT Pallet H</div></div>
        <div class="auxo-select-dropdown"><div title="Include" onclick="document.querySelector('#result').textContent='WRONG'">Include</div></div>
        <p id="result"></p>''')
    def test_reproduces_covered_input_and_operator_fix(self):
        self.fixture()
        with self.assertRaises(TimeoutError): self.page.locator('#logical_zone_op_type').click(timeout=250)
        self.adapter.set_operator('logical_zone_op_type','Include')
        self.assertEqual(self.page.locator('#result').inner_text(),'Include')
    def test_physical_zone_operator_changes_exact_value(self):
        self.fixture('zone_op_type')
        self.adapter.set_operator('zone_op_type','Totally included')
        self.assertEqual(self.page.locator('#result').inner_text(),'Totally included')
    def test_multiselect_uses_same_surface_and_closes(self):
        self.fixture('logical_inv_zone_list',True)
        self.adapter.select('logical_inv_zone_list',['TT Pallet L','TT Pallet H'])
        self.assertEqual(self.page.locator('#result').inner_text(),'LH')
        self.assertFalse(self.page.locator('#menu').is_visible())
    def test_missing_exact_option_stops_without_selecting(self):
        self.fixture()
        with self.assertRaises(TimeoutError): self.adapter.set_operator('logical_zone_op_type','Unknown')
        self.assertEqual(self.page.locator('#result').inner_text(),'')
