"""Slow old queries must finish before the final Search total is read."""
import threading,time,unittest
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from wms_assistant.browser import WMSBrowser
from wms_assistant.core import default_phases,default_config

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        if self.path=='/':
            body=b'''<button onclick="load('reset')">Reset</button>
            <div onclick="load('tab')">One item only</div>
            <input type="number"><input type="number">
            <button onclick="fetch('/wms-ttp.tiktokw.us/meta');load('search')">Search</button>
            <p id="total">Total package: 5891</p>
            <script>function load(kind){fetch('/wms-ttp.tiktokw.us/'+kind).then(r=>r.text()).then(n=>document.querySelector('#total').textContent='Total package: '+n)}</script>'''
            mime='text/html'
        else:
            time.sleep(2 if self.path.endswith(('reset','search')) else 0.1)
            body=b'2469' if self.path.endswith('search') else b'5891';mime='text/plain'
        self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
class QueryRaceTests(unittest.TestCase):
    def test_waits_for_reset_tab_and_search_data_not_fast_metadata(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            with sync_playwright() as pw:
                browser=pw.chromium.launch(headless=True,executable_path=pw.chromium.executable_path)
                try:
                    page=browser.new_page();page.goto('http://127.0.0.1:'+str(server.server_port))
                    b=WMSBrowser.__new__(WMSBrowser);b.page=page;b.ensure_wave_page=lambda:None
                    result=b.query(default_phases()[23],[],[],default_config(),quantity=(6,999))
                    self.assertEqual(result['total_packages'],2469)
                    self.assertEqual(result['quantity_range'],[6,999])
                finally:browser.close()
        finally:server.shutdown();server.server_close();thread.join()
