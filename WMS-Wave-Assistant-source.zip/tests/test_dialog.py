"""Local browser fixture: verifies UI write sequence without contacting WMS."""
import threading
import unittest
from playwright.sync_api import sync_playwright
from wms_assistant.browser import WMSBrowser

class DialogTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw=sync_playwright().start()
        cls.browser=cls.pw.chromium.launch(headless=True,executable_path=cls.pw.chromium.executable_path)
    @classmethod
    def tearDownClass(cls):
        cls.browser.close();cls.pw.stop()
    def setUp(self):
        self.page=self.browser.new_page();self.page.set_default_timeout(10000)
        self.adapter=WMSBrowser.__new__(WMSBrowser);self.adapter.page=self.page
    def tearDown(self): self.page.close()
    def fixture(self, status=True):
        self.page.set_content('''<p>Goods selected 0</p><button onclick="document.querySelector('#pre').hidden=false">Consolidate Wave</button>
        <div id="pre" role="dialog" hidden><p>Confirm?</p><button onclick="this.parentElement.hidden=true;document.querySelector('#pick').hidden=false">OK</button></div>
        <div id="pick" role="dialog" hidden><h2>Select pick strategy</h2><table><tr><td><input type="radio" name="strategy" value="wrong"></td><td>Clean-up Single</td></tr>
        <tr><td><input type="radio" name="strategy" value="right"></td><td>Clean-up Multis</td></tr></table>'''+
        ('<label><input type="radio" name="status">Not Operated</label>' if status else '')+'''
        <button onclick="if(document.querySelector('input[value=right]').checked){this.parentElement.hidden=true;document.querySelector('#receipt').textContent='Consolidate Wave successfully';document.querySelector('#counter').textContent='1'}">OK</button></div><div role="alert" id="receipt"></div><span id="counter">0</span>''')
    def test_exact_strategy_then_not_operated_then_single_final_ok(self):
        self.fixture();calls=[]
        result=self.adapter.consolidate('Clean-up Multis',lambda:calls.append('intent'),threading.Event())
        self.assertEqual(calls,['intent']);self.assertEqual(result['status'],'confirmed')
        self.assertEqual(self.page.locator('#counter').inner_text(),'1')
    def test_missing_not_operated_does_not_write(self):
        self.fixture(False);calls=[]
        with self.assertRaises(RuntimeError):
            self.adapter.consolidate('Clean-up Multis',lambda:calls.append('intent'),threading.Event())
        self.assertEqual(calls,[]);self.assertEqual(self.page.locator('#counter').inner_text(),'0')
