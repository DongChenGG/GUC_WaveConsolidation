"""Local browser fixture: verifies UI write sequence without contacting WMS."""
import threading
import unittest
from playwright.sync_api import sync_playwright
from wms_assistant.browser import WMSBrowser

class DialogTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw=sync_playwright().start()
        cls.browser=cls.pw.chromium.launch(headless=True,executable_path=cls.pw.chromium.executable_path)
    @classmethod
    def tearDownClass(cls):
        cls.browser.close();cls.pw.stop()
    def setUp(self):
        self.page=self.browser.new_page();self.page.set_default_timeout(10000)
        self.adapter=WMSBrowser.__new__(WMSBrowser);self.adapter.page=self.page
    def tearDown(self): self.page.close()
    def fixture(self, status=True):
        self.page.set_content('''<p>Goods selected 0</p><button onclick="document.querySelector('#pre').hidden=false">Consolidate Wave</button>
        <div id="pre" role="dialog" hidden><p>Confirm?</p><button onclick="this.parentElement.hidden=true;document.querySelector('#pick').hidden=false">OK</button></div>
        <div id="pick" role="dialog" hidden><h2>Select pick strategy</h2><table><tr><td><input type="radio" name="strategy" value="wrong"></td><td>Clean-up Single</td></tr>
        <tr><td><input type="radio" name="strategy" value="right"></td><td>Clean-up Multis</td></tr></table>'''+
        ('<label><input type="radio" name="status">Not Operated</label>' if status else '')+'''
        <button onclick="if(document.querySelector('input[value=right]').checked){this.parentElement.hidden=true;document.querySelector('#receipt').textContent='Consolidate Wave successfully';document.querySelector('#counter').textContent='1'}">OK</button></div><div role="alert" id="receipt"></div><span id="counter">0</span>''')
    def test_exact_strategy_then_not_operated_then_single_final_ok(self):
        self.fixture();calls=[]
        result=self.adapter.consolidate('Clean-up Multis',lambda:calls.append('intent'),threading.Event())
        self.assertEqual(calls,['intent']);self.assertEqual(result['status'],'confirmed')
        self.assertEqual(self.page.locator('#counter').inner_text(),'1')
    def test_missing_not_operated_does_not_write(self):
        self.fixture(False);calls=[]
        with self.assertRaises(RuntimeError):
            self.adapter.consolidate('Clean-up Multis',lambda:calls.append('intent'),threading.Event())
        self.assertEqual(calls,[]);self.assertEqual(self.page.locator('#counter').inner_text(),'0')

    def dropdown_fixture(self, duplicate=False):
        self.page.set_content('''<style>.auxo-select-selector{position:relative;width:250px;height:35px;border:1px solid}.auxo-select-selector input{position:absolute;inset:0}.auxo-select-selection-placeholder,.auxo-select-selection-item{position:absolute;inset:0;background:white;z-index:2}</style>
        <p>Goods selected 0</p><button onclick="document.querySelector('#pre').hidden=false">Consolidate Wave</button>
        <div id="pre" role="dialog" hidden><p>Confirm?</p><button onclick="this.parentElement.hidden=true;document.querySelector('#pick').hidden=false">OK</button></div>
        <div id="pick" role="dialog" hidden><div class="auxo-modal-title">Select pick strategy</div>
        <div class="auxo-select-selector" onclick="document.querySelector('#menu').hidden=false"><input id="strategy" role="combobox" readonly aria-controls="strategy_list"><span id="selection" class="auxo-select-selection-placeholder">Select pick strategy</span></div>
        <label><input type="radio" name="status">Not Operated</label>
        <button onclick="document.querySelector('#counter').textContent=Number(document.querySelector('#counter').textContent)+1;this.parentElement.hidden=true;document.querySelector('#receipt').textContent='Consolidate Wave successfully'">OK</button></div>
        <div class="auxo-select-dropdown" id="menu" hidden><div role="listbox" id="strategy_list"></div>
        <div title="Clean-up Single">Clean-up Single</div>
        <div title="Clean-up Multis" onclick="let s=document.querySelector('#selection');s.textContent='Clean-up Multis';s.className='auxo-select-selection-item';this.parentElement.hidden=true">Clean-up Multis</div>'''+
        ('<div title="Clean-up Multis">Clean-up Multis</div>' if duplicate else '')+'''
        </div><div role="alert" id="receipt"></div><span id="counter">0</span>''')

    def test_duplicate_title_placeholder_uses_dropdown_and_final_ok_once(self):
        self.dropdown_fixture();calls=[]
        result=self.adapter.consolidate('Clean-up Multis',lambda:calls.append('intent'),threading.Event())
        self.assertEqual(result['status'],'confirmed')
        self.assertEqual(calls,['intent'])
        self.assertEqual(self.page.locator('#selection').inner_text(),'Clean-up Multis')
        self.assertTrue(self.page.locator('input[name=status]').is_checked())
        self.assertEqual(self.page.locator('#counter').inner_text(),'1')

    def test_duplicate_dropdown_options_stop_before_final_ok(self):
        self.dropdown_fixture(True);calls=[]
        with self.assertRaises(RuntimeError):
            self.adapter.consolidate('Clean-up Multis',lambda:calls.append('intent'),threading.Event())
        self.assertEqual(calls,[])
        self.assertEqual(self.page.locator('#counter').inner_text(),'0')
