import tempfile
from pathlib import Path
import threading
import types
import sys
import unittest
from wms_assistant import app
from wms_assistant.core import default_config, default_phases

class FakeBrowser:
    calls=[]
    counts=[]
    def __init__(self,profile):pass
    def close(self):pass
    def query(self,phase,pairs,virtuals,cfg):
        self.calls.append(list(pairs))
        return {'total_packages':self.counts.pop(0) if self.counts else 100}

class WorkerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        app.DATA=Path(self.temp.name)
        FakeBrowser.calls=[];FakeBrowser.counts=[]
        self.old=sys.modules.get('wms_assistant.browser')
        sys.modules['wms_assistant.browser']=types.SimpleNamespace(WMSBrowser=FakeBrowser)
        self.thread=threading.Thread(target=app.worker,daemon=True);self.thread.start()
        app.JOBS.put(('open',{}));app.JOBS.join()
    def tearDown(self):
        app.JOBS.put(('shutdown',{}));self.thread.join(3)
        # shutdown is deliberately not a task; clear queue accounting for subsequent tests.
        app.JOBS.task_done()
        if self.old:sys.modules['wms_assistant.browser']=self.old
        else:sys.modules.pop('wms_assistant.browser',None)
        self.temp.cleanup()
    def run_phase(self,number,verified=True):
        cfg=default_config();cfg['operators_verified']=verified
        app.JOBS.put(('scan',{'phase_config':default_phases()[number-1],'config':cfg}));app.JOBS.join()
    def test_adds_whole_aisle_until_threshold(self):
        FakeBrowser.counts=[10,40]
        self.run_phase(17)
        self.assertEqual(FakeBrowser.calls,[[124,126,128],[124,126,128,130]])
    def test_multis_expands_using_total_package(self):
        FakeBrowser.counts=[1,2]
        self.run_phase(2)
        self.assertEqual(FakeBrowser.calls,[[124,126,128],[124,126,128,130]])
    def test_hold_and_cancel_never_touch_browser(self):
        self.run_phase(15);self.run_phase(23)
        self.assertEqual(FakeBrowser.calls,[])
    def test_low_high_mixed_ranges_query_separately(self):
        self.run_phase(12)
        self.assertEqual(len(FakeBrowser.calls),2)
        self.assertEqual(FakeBrowser.calls[0],list(range(124,191,2)))

if __name__=='__main__':unittest.main()
