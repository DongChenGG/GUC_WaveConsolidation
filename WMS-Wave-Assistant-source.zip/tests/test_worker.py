import tempfile
from pathlib import Path
import threading
import types
import sys
import unittest
from unittest.mock import patch
from wms_assistant import app
from wms_assistant.core import default_config, default_phases

class FakeBrowser:
    calls=[]
    counts=[]
    def __init__(self,profile):pass
    def close(self):pass
    def identity(self):return 'tester','WH1'
    def wait_new_waves(self,intent,stop,**kwargs):return [{'wave_number':'WAVE052','creator':'tester','packages':3131,'status':'Created'}]
    def query(self,phase,pairs,virtuals,cfg):
        self.calls.append(list(pairs))
        return {'total_packages':self.counts.pop(0) if self.counts else 100}

class WorkerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        app.DATA=Path(self.temp.name)
        FakeBrowser.calls=[];FakeBrowser.counts=[]
        self.old=sys.modules.get('wms_assistant.browser')
        sys.modules['wms_assistant.browser']=types.SimpleNamespace(WMSBrowser=FakeBrowser)
        self.thread=threading.Thread(target=app.worker,daemon=True);self.thread.start()
        app.JOBS.put(('open',{}));app.JOBS.join()
    def tearDown(self):
        app.JOBS.put(('shutdown',{}));self.thread.join(3)
        # shutdown is deliberately not a task; clear queue accounting for subsequent tests.
        app.JOBS.task_done()
        if self.old:sys.modules['wms_assistant.browser']=self.old
        else:sys.modules.pop('wms_assistant.browser',None)
        self.temp.cleanup()
    def run_phase(self,number,verified=True):
        cfg=default_config();cfg['operators_verified']=verified
        app.JOBS.put(('scan',{'phase_config':batch_phases()[number-1],'config':cfg}));app.JOBS.join()
    def test_adds_whole_aisle_until_threshold(self):
        FakeBrowser.counts=[10,40]
        self.run_phase(17)
        self.assertEqual(FakeBrowser.calls,[[124,126,128],[124,126,128,130]])
    def test_multis_expands_using_total_package(self):
        FakeBrowser.counts=[1,2]
        self.run_phase(2)
        self.assertEqual(FakeBrowser.calls,[[124,126,128],[124,126,128,130]])
    def test_hold_and_cancel_never_touch_browser(self):
        self.run_phase(15);self.run_phase(23)
        self.assertEqual(FakeBrowser.calls,[])
    def test_low_high_mixed_ranges_query_separately(self):
        self.run_phase(12)
        self.assertEqual(len(FakeBrowser.calls),2)
        self.assertEqual(FakeBrowser.calls[0],list(range(124,191,2)))

    def test_old_pending_top_recheck_registers_hold_and_next_step(self):
        app.save_round_ledger({'waves':[],'runs':[{'id':'run','mode':'first','status':'paused','top_released':0}],
          'pending':{'kind':'create','run_id':'run','creator':'tester','warehouse':'WH1','purpose':'top','packages':2567,'baseline':[]}})
        app.JOBS.put(('recheck',{}));app.JOBS.join()
        data=app.round_ledger()
        self.assertIsNone(data['pending'])
        self.assertEqual(data['waves'][0]['state'],'held')
        self.assertEqual(data['waves'][0]['packages'],3131)
        self.assertEqual(data['runs'][0]['next_step'],1)
        self.assertTrue(data['runs'][0]['resume_ready'])
        self.assertEqual(data['runs'][0]['quantity_differences'][0]['expected'],2567)

    def test_start_automatically_reconciles_then_resumes(self):
        app.STOP.clear()
        app.save_round_ledger({'waves':[],'runs':[{'id':'run','mode':'first','creator':'tester','warehouse':'WH1','status':'paused','top_released':0}],
          'pending':{'kind':'create','run_id':'run','creator':'tester','warehouse':'WH1','purpose':'top','packages':2567,'baseline':[]}})
        with patch('wms_assistant.rounds.RoundRunner.resume') as resume, patch('wms_assistant.rounds.RoundRunner.execute') as execute:
            app.JOBS.put(('round',{'mode':'first'}));app.JOBS.join()
            resume.assert_called_once();execute.assert_not_called()
        self.assertIsNone(app.round_ledger()['pending'])

    def test_canceled_hold_retries_same_step_not_skips_it(self):
        app.save_round_ledger({'waves':[],'runs':[{'id':'run','mode':'first','status':'paused','top_released':0}],
          'pending':{'kind':'create','run_id':'run','creator':'tester','warehouse':'WH1','purpose':'top','packages':2567,'baseline':[]}})
        with patch.object(FakeBrowser,'wait_new_waves',return_value=[{'wave_number':'WAVE052','creator':'tester','packages':3131,'status':'Canceled'}]):
            app.reconcile_round(FakeBrowser(None))
        data=app.round_ledger()
        self.assertEqual(data['runs'][0]['next_step'],0)
        self.assertEqual(data['waves'][0]['state'],'canceled')
        self.assertTrue(data['runs'][0]['resume_ready'])

    def test_restart_ends_old_run_preserves_waves_and_backs_up(self):
        app.STOP.clear()
        old={'id':'run','mode':'first','creator':'tester','warehouse':'WH1','status':'paused','top_released':0,'next_step':2}
        waves=[{'wave_number':'WAVEold','state':'held','purpose':'single'}]
        app.save_round_ledger({'waves':waves,'runs':[old],'pending':None})
        with patch('wms_assistant.rounds.RoundRunner.resume') as resume, patch('wms_assistant.rounds.RoundRunner.execute') as execute:
            app.JOBS.put(('round',{'mode':'last','restart':True}));app.JOBS.join()
            execute.assert_called_once_with('last');resume.assert_not_called()
        data=app.round_ledger()
        self.assertEqual(data['runs'][0]['status'],'ended')
        self.assertEqual(data['waves'],waves)
        self.assertEqual(len(list((app.DATA/'backups').glob('*.json'))),1)

    def test_restart_reconciles_pending_before_ending_old_run(self):
        app.STOP.clear()
        app.save_round_ledger({'waves':[],'runs':[{'id':'run','mode':'first','creator':'tester','warehouse':'WH1','status':'paused','top_released':0}],
          'pending':{'kind':'create','run_id':'run','creator':'tester','warehouse':'WH1','purpose':'top','packages':2567,'baseline':[]}})
        with patch('wms_assistant.rounds.RoundRunner.execute') as execute:
            app.JOBS.put(('round',{'mode':'first','restart':True}));app.JOBS.join()
            execute.assert_called_once_with('first')
        data=app.round_ledger()
        self.assertEqual(data['runs'][0]['status'],'ended')
        self.assertEqual(data['waves'][0]['state'],'held')
        self.assertIsNone(data['pending'])

    def test_unknown_pending_does_not_end_old_run_or_start_new(self):
        app.STOP.clear()
        data={'waves':[],'runs':[{'id':'run','mode':'first','creator':'tester','warehouse':'WH1','status':'paused','top_released':0}],
          'pending':{'kind':'create','run_id':'run','creator':'tester','warehouse':'WH1','purpose':'top','packages':2567,'baseline':[]}}
        app.save_round_ledger(data)
        with patch.object(FakeBrowser,'wait_new_waves',side_effect=RuntimeError('Unknown receipt')), patch('wms_assistant.rounds.RoundRunner.execute') as execute:
            app.JOBS.put(('round',{'mode':'first','restart':True}));app.JOBS.join()
            execute.assert_not_called()
        self.assertEqual(app.round_ledger(),data)

    def test_new_selection_bypasses_paused_multis_after_archiving_old_run(self):
        app.STOP.clear()
        app.save_round_ledger({'waves':[],'runs':[{'id':'old','mode':'first','creator':'tester','warehouse':'WH1','status':'paused','next_step':2}], 'pending':None})
        with patch('wms_assistant.rounds.RoundRunner.execute') as execute,patch('wms_assistant.rounds.RoundRunner.resume') as resume:
            app.JOBS.put(('round',{'mode':'first','restart':True,'selected_steps':['single'],'release_limit':3}));app.JOBS.join()
            execute.assert_called_once_with('first',selection=['single'],release_limit=3);resume.assert_not_called()
        self.assertEqual(app.round_ledger()['runs'][0]['status'],'ended')

    def test_resume_reconciles_pending_batch_before_continuing(self):
        app.STOP.clear()
        app.save_round_ledger({'waves':[], 'runs':[{'id':'run','mode':'last','creator':'tester','warehouse':'WH1','status':'paused','top_released':0,'next_step':3,'batch_progress':{}}],
          'pending':{'kind':'create','run_id':'run','creator':'tester','warehouse':'WH1','purpose':'release_single','packages':40,'baseline':[], 'step_key':'single','checkpoint':{'key':'box-low','after':{'cursor':6,'end':9}}}})
        with patch('wms_assistant.rounds.RoundRunner.resume') as resume:
            app.JOBS.put(('resume',{}));app.JOBS.join();resume.assert_called_once()
        data=app.round_ledger();run=data['runs'][0]
        self.assertIsNone(data['pending']);self.assertEqual(run['next_step'],3)
        self.assertEqual(run['batch_progress']['box-low']['cursor'],6)
        self.assertEqual(run['node_submissions']['single'],1)


    def test_new_flex_reads_created_cancel_receipt_without_resuming_first(self):
        app.STOP.clear()
        wave={'wave_number':'WAVElock','creator':'tester','warehouse':'WH1','purpose':'single','packages':1735,'state':'held','status':'Created'}
        app.save_round_ledger({'waves':[wave],'runs':[{'id':'first','mode':'first','creator':'tester','warehouse':'WH1','status':'paused','next_step':4}],
          'pending':{'kind':'cancel','run_id':'first','creator':'tester','warehouse':'WH1','wave':wave}})
        with patch.object(FakeBrowser,'wave_snapshot',return_value=[wave],create=True),patch('wms_assistant.rounds.RoundRunner.execute') as execute,patch('wms_assistant.rounds.RoundRunner.resume') as resume:
            app.JOBS.put(('round',{'mode':'flex','restart':True,'selected_steps':['top_box_h'],'release_limit':0}));app.JOBS.join()
            execute.assert_called_once_with('flex',selection=['top_box_h'],release_limit=0);resume.assert_not_called()
        data=app.round_ledger()
        self.assertIsNone(data['pending']);self.assertEqual(data['waves'][0]['state'],'held')
        self.assertEqual(data['runs'][0]['status'],'ended')

    def test_resume_cancel_after_reboot_retains_same_node(self):
        app.STOP.clear()
        wave={'wave_number':'WAVElock','creator':'tester','packages':1735,'state':'held','status':'Created','purpose':'single'}
        app.save_round_ledger({'waves':[wave],'runs':[{'id':'first','mode':'first','creator':'tester','warehouse':'WH1','status':'running','next_step':4,'batch_progress':{}}],
          'pending':{'kind':'cancel','run_id':'first','creator':'tester','warehouse':'WH1','wave':wave}})
        with patch.object(FakeBrowser,'wave_snapshot',return_value=[wave],create=True),patch('wms_assistant.rounds.RoundRunner.resume') as resume:
            app.JOBS.put(('resume',{}));app.JOBS.join();resume.assert_called_once()
        data=app.round_ledger();self.assertIsNone(data['pending']);self.assertEqual(data['runs'][0]['next_step'],4)


def batch_phases():
    # Explicit opt-in batching remains supported; the new default is full range.
    phases=default_phases()
    for p in phases:
        if len(p.zone_types)==1 and not p.manual: p.grouped=True
    return phases


if __name__=='__main__':unittest.main()
