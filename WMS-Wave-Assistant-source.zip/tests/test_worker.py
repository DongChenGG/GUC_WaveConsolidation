import tempfile
from pathlib import Path
import threading
import types
import sys
import unittest
from wms_assistant import app
from wms_assistant.core import default_config, default_phases

class FakeBrowser:
    calls=[]
    counts=[]
    def __init__(self,profile):pass
    def close(self):pass
    def identity(self):return 'tester','WH1'
    def wait_new_waves(self,intent,stop):return [{'wave_number':'WAVE052','creator':'tester','packages':3131,'status':'Created'}]
    def query(self,phase,pairs,virtuals,cfg):
        self.calls.append(list(pairs))
        return {'total_packages':self.counts.pop(0) if self.counts else 100}

class WorkerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        app.DATA=Path(self.temp.name)
        FakeBrowser.calls=[];FakeBrowser.counts=[]
        self.old=sys.modules.get('wms_assistant.browser')
        sys.modules['wms_assistant.browser']=types.SimpleNamespace(WMSBrowser=FakeBrowser)
        self.thread=threading.Thread(target=app.worker,daemon=True);self.thread.start()
        app.JOBS.put(('open',{}));app.JOBS.join()
    def tearDown(self):
        app.JOBS.put(('shutdown',{}));self.thread.join(3)
        # shutdown is deliberately not a task; clear queue accounting for subsequent tests.
        app.JOBS.task_done()
        if self.old:sys.modules['wms_assistant.browser']=self.old
        else:sys.modules.pop('wms_assistant.browser',None)
        self.temp.cleanup()
    def run_phase(self,number,verified=True):
        cfg=default_config();cfg['operators_verified']=verified
        app.JOBS.put(('scan',{'phase_config':batch_phases()[number-1],'config':cfg}));app.JOBS.join()
    def test_adds_whole_aisle_until_threshold(self):
        FakeBrowser.counts=[10,40]
        self.run_phase(17)
        self.assertEqual(FakeBrowser.calls,[[124,126,128],[124,126,128,130]])
    def test_multis_expands_using_total_package(self):
        FakeBrowser.counts=[1,2]
        self.run_phase(2)
        self.assertEqual(FakeBrowser.calls,[[124,126,128],[124,126,128,130]])
    def test_hold_and_cancel_never_touch_browser(self):
        self.run_phase(15);self.run_phase(23)
        self.assertEqual(FakeBrowser.calls,[])
    def test_low_high_mixed_ranges_query_separately(self):
        self.run_phase(12)
        self.assertEqual(len(FakeBrowser.calls),2)
        self.assertEqual(FakeBrowser.calls[0],list(range(124,191,2)))

    def test_old_pending_top_recheck_registers_hold_and_next_step(self):
        app.save_round_ledger({'waves':[],'runs':[{'id':'run','mode':'first','status':'paused','top_released':0}],
          'pending':{'kind':'create','run_id':'run','creator':'tester','warehouse':'WH1','purpose':'top','packages':2567,'baseline':[]}})
        app.JOBS.put(('recheck',{}));app.JOBS.join()
        data=app.round_ledger()
        self.assertIsNone(data['pending'])
        self.assertEqual(data['waves'][0]['state'],'held')
        self.assertEqual(data['waves'][0]['packages'],3131)
        self.assertEqual(data['runs'][0]['next_step'],1)
        self.assertTrue(data['runs'][0]['resume_ready'])
        self.assertEqual(data['runs'][0]['quantity_differences'][0]['expected'],2567)

if __name__=='__main__':unittest.main()


def batch_phases():
    # Explicit opt-in batching remains supported; the new default is full range.
    phases=default_phases()
    for p in phases:
        if len(p.zone_types)==1 and not p.manual: p.grouped=True
    return phases
