import tempfile
import unittest
from pathlib import Path
from wms_assistant import app
from wms_assistant.core import default_config, default_phases

class Browser:
    def __init__(self, counts, fail=False):
        self.counts=iter(counts); self.calls=[]; self.submits=0; self.fail=fail
    def query(self, phase, pairs, virtuals, cfg):
        self.calls.append(list(pairs))
        return {'total_packages':next(self.counts)}
    def consolidate(self,strategy,before_submit,stop):
        before_submit(); self.submits+=1
        if self.fail: raise RuntimeError('ambiguous timeout')
        return {'status':'confirmed','strategy':strategy}

class LiveTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.old=app.DATA;app.DATA=Path(self.temp.name)
        app.STOP.clear(); self.cfg=default_config();self.cfg['operators_verified']=True
    def tearDown(self):
        app.DATA=self.old;app.STOP.clear();self.temp.cleanup()
    def test_single_expands_before_one_write(self):
        b=Browser([10,50]);app.execute_phase(b,default_phases()[16],self.cfg)
        self.assertEqual(b.calls,[[124,126,128],[124,126,128,130]])
        self.assertEqual(b.submits,1);self.assertIsNone(app.pending_submission())
    def test_unknown_write_blocks_all_future_writes_across_restart(self):
        b=Browser([100],fail=True)
        with self.assertRaises(RuntimeError):app.execute_phase(b,default_phases()[15],self.cfg)
        self.assertIsNotNone(app.pending_submission())
        with self.assertRaises(RuntimeError):app.execute_phase(b,default_phases()[15],self.cfg)
        self.assertEqual(b.submits,1);self.assertEqual(len(b.calls),1)
    def test_below_threshold_deferred_unless_tail_selected(self):
        b=Browser([5]);app.execute_phase(b,default_phases()[15],self.cfg)
        self.assertEqual(b.submits,0)
        b=Browser([5]);app.execute_phase(b,default_phases()[15],self.cfg,True)
        self.assertEqual(b.submits,1)
    def test_zero_never_submits_even_tail(self):
        b=Browser([0]);app.execute_phase(b,default_phases()[15],self.cfg,True)
        self.assertEqual(b.submits,0)
    def test_stop_and_unverified_cannot_write(self):
        b=Browser([]);app.STOP.set();app.execute_phase(b,default_phases()[15],self.cfg)
        self.assertEqual(b.submits,0)
        app.STOP.clear();self.cfg['operators_verified']=False
        with self.assertRaises(RuntimeError):app.execute_phase(b,default_phases()[15],self.cfg)
    def test_multis_fixed_groups_and_no_single_threshold_inference(self):
        b=Browser([5,5]);app.execute_phase(b,default_phases()[1],self.cfg)
        self.assertEqual(b.calls,[[124,126,128],[130]]);self.assertEqual(b.submits,2)
