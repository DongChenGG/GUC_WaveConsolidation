import tempfile
import unittest
from pathlib import Path
from wms_assistant import app
from wms_assistant.core import default_config, default_phases

class Browser:
    def __init__(self, counts, fail=False):
        self.counts=iter(counts); self.calls=[]; self.submits=0; self.fail=fail
    def query(self, phase, pairs, virtuals, cfg):
        self.calls.append(list(pairs))
        return {'total_packages':next(self.counts)}
    def consolidate(self,strategy,before_submit,stop):
        before_submit(); self.submits+=1
        if self.fail: raise RuntimeError('ambiguous timeout')
        return {'status':'confirmed','strategy':strategy}

class LiveTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.old=app.DATA;app.DATA=Path(self.temp.name)
        app.STOP.clear(); self.cfg=default_config();self.cfg['operators_verified']=True
    def tearDown(self):
        app.DATA=self.old;app.STOP.clear();self.temp.cleanup()
    def test_single_expands_before_one_write(self):
        b=Browser([10,50]);app.execute_phase(b,batch_phases()[16],self.cfg)
        self.assertEqual(b.calls,[[124,126,128],[124,126,128,130]])
        self.assertEqual(b.submits,1);self.assertIsNone(app.pending_submission())
    def test_unknown_write_blocks_all_future_writes_across_restart(self):
        b=Browser([100],fail=True)
        with self.assertRaises(RuntimeError):app.execute_phase(b,batch_phases()[15],self.cfg)
        self.assertIsNotNone(app.pending_submission())
        with self.assertRaises(RuntimeError):app.execute_phase(b,batch_phases()[15],self.cfg)
        self.assertEqual(b.submits,1);self.assertEqual(len(b.calls),1)
    def test_ground_defers_small_even_with_tail_option(self):
        b=Browser([5]);app.execute_phase(b,batch_phases()[15],self.cfg)
        self.assertEqual(b.submits,0)
        b=Browser([5]);app.execute_phase(b,batch_phases()[15],self.cfg,True)
        self.assertEqual(b.submits,0)
    def test_zero_never_submits_even_tail(self):
        b=Browser([0]);app.execute_phase(b,batch_phases()[15],self.cfg,True)
        self.assertEqual(b.submits,0)
    def test_stop_blocks_write_but_legacy_verification_flag_does_not(self):
        b=Browser([]);app.STOP.set();app.execute_phase(b,batch_phases()[15],self.cfg)
        self.assertEqual(b.submits,0)
        app.STOP.clear();self.cfg['operators_verified']=False
        b=Browser([30]);app.execute_phase(b,batch_phases()[15],self.cfg)
        self.assertEqual(b.submits,1)
    def test_multis_extends_until_total_package_threshold(self):
        b=Browser([5,30]);app.execute_phase(b,batch_phases()[1],self.cfg)
        self.assertEqual(b.calls,[[124,126,128],[124,126,128,130]]);self.assertEqual(b.submits,1)

    def test_multis_tail_stays_inside_pallet_range_and_defers(self):
        b=Browser([5,29]);app.execute_phase(b,batch_phases()[1],self.cfg)
        self.assertEqual(b.calls,[[124,126,128],[124,126,128,130]])
        self.assertEqual(b.submits,0)
    def test_multis_tail_cannot_bypass_minimum(self):
        b=Browser([5,29]);app.execute_phase(b,batch_phases()[1],self.cfg,True)
        self.assertEqual(b.submits,0)
    def test_multis_exact_threshold_starts_next_disjoint_batch(self):
        b=Browser([30,31]);app.execute_phase(b,batch_phases()[1],self.cfg)
        self.assertEqual(b.calls,[[124,126,128],[130]])
        self.assertEqual(b.submits,2)


    def test_default_each_type_queries_full_intersection_once(self):
        for phase in default_phases():
            if len(phase.zone_types)!=1: continue
            from wms_assistant.core import aisle_pairs
            base=aisle_pairs(phase.zone_types)
            expected=[base[i:i+3] for i in range(0,len(base),3)] if phase.zone_types==['Box'] else [base]
            b=Browser([50]*len(expected));app.execute_phase(b,phase,self.cfg)
            self.assertEqual(b.calls,expected)
            self.assertEqual(b.submits,len(expected))
            self.assertEqual(app.STATE['completed_phase'],phase.id)


def batch_phases():
    # Explicit opt-in batching remains supported; the new default is full range.
    phases=default_phases()
    for p in phases:
        if len(p.zone_types)==1 and not p.manual: p.grouped=True
    return phases
