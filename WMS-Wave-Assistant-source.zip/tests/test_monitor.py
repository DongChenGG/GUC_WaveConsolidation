import unittest,json
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
class MonitorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw=sync_playwright().start();cls.browser=cls.pw.chromium.launch(headless=True,executable_path=cls.pw.chromium.executable_path)
    @classmethod
    def tearDownClass(cls):cls.browser.close();cls.pw.stop()
    def setUp(self):
        self.context=self.browser.new_context();self.page=self.context.new_page();self.posts=[]
        self.data={'state':{'busy':True,'round_progress':{'key':'top_box_h','scope':'Box H · 140–145','action':'等待 WMS 生成波次','updated':1}},'round_ledger':{'runs':[{'id':'r','status':'running','package_targets':{'top_box_h':2000},'node_packages':{'top_box_h':1260}}]}}
        def route(r):
            if r.request.url.endswith('/icon.png'):
                r.fulfill(content_type='image/png',body=(Path(__file__).parents[1]/'wms_assistant/assets/wave.png').read_bytes());return
            if '/api/' in r.request.url:
                if r.request.method=='POST':self.posts.append(r.request.url)
                r.fulfill(content_type='application/json',body=json.dumps(self.data))
            else:r.fulfill(content_type='text/html',body=(Path(__file__).parents[1]/'wms_assistant/monitor.html').read_text(encoding='utf8'))
        self.page.route('**/*',route);self.page.goto('http://monitor.test/')
    def tearDown(self):self.context.close()
    def test_counts_scope_pause_and_resume(self):
        expect(self.page.locator('#scope')).to_contain_text('Box H')
        expect(self.page.locator('#counts')).to_contain_text('2000 · 已放 1260 · 剩余 740')
        with self.page.expect_response(lambda r:r.url.endswith('/api/stop') and r.request.method=='POST'):
            self.page.locator('#stop').click()
        self.assertTrue(self.posts[-1].endswith('/api/stop'))
        self.data['state']['busy']=False;self.data['round_ledger']['runs'][0].update(status='paused',error='Network timeout')
        self.page.evaluate('refresh()');expect(self.page.locator('#resume')).to_be_enabled()
        expect(self.page.locator('#action')).to_contain_text('Network timeout')
        with self.page.expect_response(lambda r:r.url.endswith('/api/resume-round') and r.request.method=='POST'):
            self.page.locator('#resume').click()
        self.assertTrue(self.posts[-1].endswith('/api/resume-round'))
        self.page.locator('#lang').select_option('es');expect(self.page.locator('#state')).to_have_text('Pausado')
    def test_disconnect_never_shows_running(self):
        self.page.unroute('**/*');self.page.route('**/api/*',lambda r:r.fulfill(status=503,body=''))
        self.page.evaluate('refresh()');expect(self.page.locator('#state')).to_have_text('监控连接中断')
        expect(self.page.locator('#resume')).to_be_disabled()
