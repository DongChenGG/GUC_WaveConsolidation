#!/bin/sh
set -eu
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo '请先从 python.org 安装 Python 3.10 或更新版本。'; read answer; exit 1
fi
if [ ! -f .venv/bin/python ]; then
  python3 -m venv .venv
fi
if [ ! -f .venv/wms-ready ]; then
  .venv/bin/python -m pip install -r requirements.txt
  .venv/bin/python -m playwright install chromium --no-shell
  touch .venv/wms-ready
fi
exec .venv/bin/python run.py
