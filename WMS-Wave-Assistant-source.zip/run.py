"""Source and frozen entry point; frozen distributions carry Chromium."""
import os
import sys
from pathlib import Path


def validate_bundled_plan():
    from wms_assistant.rounds import steps_for
    assert [k for k,_ in steps_for('first')] == ['top','hold_top','hold_single','multis','cancel_single','single','cancel_top']
    assert [k for k,_ in steps_for('last')] == ['cancel_top','top','cancel_single','single','multis','audit']
    assert len(steps_for('flex')) == 25

def self_test():
    from wms_assistant.core import default_phases, aisle_pairs
    from wms_assistant.rounds import steps_for
    validate_bundled_plan()
    from zoneinfo import ZoneInfo
    from playwright.sync_api import sync_playwright
    import wms_assistant.app as app
    assert len(default_phases()) == 30
    assert aisle_pairs(['Bin'])[-1] == 190
    assert ZoneInfo('America/New_York') is not None
    assert Path(app.__file__).with_name('ui.html').is_file()
    assert Path(app.__file__).with_name('monitor.html').is_file()
    assert Path(app.__file__).with_name('assets').joinpath('wave.ico').is_file()
    with sync_playwright() as pw:
        # Use bundled full Chromium, so a separate headless-shell download is unnecessary.
        with pw.chromium.launch(headless=True, executable_path=pw.chromium.executable_path) as browser:
            page = browser.new_page()
            page.set_content('<title>WMS bundle self-test</title><p>OK</p>')
            assert page.title() == 'WMS bundle self-test'
    print('PASS: Python, app assets, timezone database, 30 phases and bundled Chromium.')


def entry():
    if getattr(sys, 'frozen', False):
        # Hermetic browser installation included in the executable, never the builder's cache.
        os.environ['PLAYWRIGHT_BROWSERS_PATH'] = '0'
    if '--self-test' in sys.argv:
        self_test()
        return
    if '--desktop-self-test' in sys.argv:
        from wms_assistant.desktop import desktop_self_test
        desktop_self_test()
        return
    from wms_assistant.app import main
    main()


if __name__ == '__main__':
    if sys.stdout is None:
        sys.stdout = open(os.devnull, 'w')
    if sys.stderr is None:
        sys.stderr = open(os.devnull, 'w')
    try:
        entry()
    except Exception as exc:
        print('WMS startup failed:', exc, file=sys.stderr)
        if getattr(sys, 'frozen', False) and '--self-test' not in sys.argv:
            if '--desktop-self-test' not in sys.argv:
                import ctypes
                ctypes.windll.user32.MessageBoxW(0, str(exc), 'WMS startup error / 启动失败', 0x10)
        if '--self-test' in sys.argv or '--desktop-self-test' in sys.argv:
            sys.exit(1)
        raise
