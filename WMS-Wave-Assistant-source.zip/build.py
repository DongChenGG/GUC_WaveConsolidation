"""Build a Windows x64 single EXE, bundle Chromium and smoke-test the result."""
from pathlib import Path
import hashlib
import json
import os
import platform
import subprocess
import sys


def main():
    if sys.platform != 'win32' or platform.machine().lower() not in ('amd64', 'x86_64'):
        raise SystemExit('This build must run on Windows x64 with 64-bit Python. macOS cannot build this EXE.')
    root = Path(__file__).resolve().parent
    env = os.environ.copy()
    env['PLAYWRIGHT_BROWSERS_PATH'] = '0'
    env['PYTHONUTF8'] = '1'
    subprocess.run([sys.executable,'-m','playwright','install','chromium','--no-shell'], cwd=root,env=env,check=True)
    subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=root,env=env,check=True)
    subprocess.run([sys.executable,'-m','PyInstaller','--noconfirm','--clean','--onefile','--console',
                    '--name','WMS-Wave-Assistant','--collect-all','playwright','--collect-all','tzdata',
                    '--add-data',str(root/'wms_assistant'/'ui.html')+';wms_assistant',
                    str(root/'run.py')],cwd=root,env=env,check=True)
    exe = root/'dist'/'WMS-Wave-Assistant.exe'
    # Remove builder-specific paths to ensure the EXE can find its own embedded browser.
    verify_env = env.copy()
    for key in ('PLAYWRIGHT_BROWSERS_PATH','PYTHONPATH','PYTHONHOME','WMS_ASSISTANT_DATA'):
        verify_env.pop(key,None)
    subprocess.run([str(exe),'--self-test'],cwd=root,env=verify_env,check=True,timeout=240)
    sha = hashlib.sha256(exe.read_bytes()).hexdigest()
    exe.with_suffix('.exe.sha256').write_text(sha+'  '+exe.name+'\n',encoding='ascii')
    exe.with_suffix('.build.json').write_text(json.dumps({'artifact':exe.name,'sha256':sha,
        'platform':platform.platform(),'python':platform.python_version(),
        'self_test':'passed','wms_live_query_test':'not performed','mode':'read-only preview'},indent=2),encoding='utf-8')
    print('\nSUCCESS: '+str(exe)+'\nCopy this EXE to a Windows x64 computer; no Python installation required.')


if __name__ == '__main__':
    main()
