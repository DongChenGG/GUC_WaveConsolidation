@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist .venv\wms-ready goto run
if exist .venv\Scripts\python.exe goto install
py -3 -m venv .venv
if errorlevel 1 goto failed
:install
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m playwright install chromium --no-shell
if errorlevel 1 goto failed
type nul > .venv\wms-ready
:run
.venv\Scripts\python.exe run.py
if errorlevel 1 goto failed
exit /b 0
:failed
echo 启动失败。请安装 Python 3.10+ 并检查网络。保留本窗口中的错误信息。
pause
exit /b 1
