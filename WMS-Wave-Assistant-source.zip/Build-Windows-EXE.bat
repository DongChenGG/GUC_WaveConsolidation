@echo off
setlocal
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto nopython
if not exist .build-venv\Scripts\python.exe py -3 -m venv .build-venv
if errorlevel 1 goto failed
.build-venv\Scripts\python.exe -m pip install -r requirements.txt -r requirements-build.txt
if errorlevel 1 goto failed
.build-venv\Scripts\python.exe build.py
if errorlevel 1 goto failed
explorer "%CD%\dist"
echo 构建完成。将 dist\WMS-Wave-Assistant.exe 复制到另一台 Windows x64 电脑即可使用。
pause
exit /b 0
:nopython
echo 仅构建电脑需要 Python。请安装 Python 3.11 或 3.12 x64，再运行本文件。
pause
exit /b 1
:failed
echo 构建未完成，请保留上方错误信息。尚未生成通过验证的 EXE。
pause
exit /b 1
