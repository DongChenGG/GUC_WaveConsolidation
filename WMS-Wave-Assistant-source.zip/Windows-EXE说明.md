# v0.7.0-test Windows EXE

这是具有真实汇波、锁单及取消功能的测试版，不是只读预览。首波 / 尾波 / Flex 规则见 README.md。运行前确认标题为 v0.7.0-test，WMS 网页切换为 English。

Windows x64 EXE 内嵌 Python 和 Chromium，桌面窗口需要 Edge WebView2 Runtime。启动时会解压到临时目录，可能有等待。每台电脑自行登录，分发包不含账号或台账。

EXE 尚未签名，Smart App Control 或企业策略可能阻止启动；构建自检通过不等于 Windows 信任认证。本次更新未解决签名。

## 构建

在 Windows x64 安装 Python 3.12，运行 Build-Windows-EXE.bat，或在 GitHub Actions 执行 Build Windows EXE。构建包含回归测试、Chromium 与桌面自检。成功后产物为 EXE、SHA256 和 build.json。

本次仅提供 Actions 测试构建，不发布 GitHub 正式 Release。Actions 下载可能要求登录，产物保留 7 天。不要分享临时签名下载地址，应分享对应 Actions 页面。

生产 WMS 的创建和取消未用于自动化测试；请先用少量 Flex 批次验收。台账保留在本机数据目录，升级不删除历史波次或未决记录。
