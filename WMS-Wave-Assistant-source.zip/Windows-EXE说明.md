# Windows EXE 构建

当前提供的是 **EXE 构建包**。本次工作环境为 macOS ARM64，没有 Windows 运行环境，因此尚未生成或验证实际 `.exe`。

## 一次构建，其他电脑直接用

1. 在 Windows 10/11 x64 电脑上解压本文件夹。
2. 构建电脑安装 Python 3.11/3.12 x64（仅构建电脑需要）。
3. 双击 `Build-Windows-EXE.bat`，保持联网。
4. 脚本会安装打包依赖、下载 Chromium、运行测试并生成单文件 EXE。
5. 自动验证 EXE 内的 Chromium、页面资源和时区库。只有验证通过才报告成功并写出 SHA256。
6. 将 `dist/WMS-Wave-Assistant.exe` 复制到其他 Windows x64 电脑，双击即可使用，无需安装 Python 或另行下载 Chromium。

浏览器被内嵌，所以 EXE 较大；每次启动需解压至系统临时目录，会有启动等待和额外磁盘占用。运行仍需联网访问 WMS，并在每台电脑重新登录。不要复制或分享登录配置目录。

窗口会打开本地网页管理界面，控制台保留用于查看错误，关闭控制台会结束服务。EXE 没有代码签名；若公司设备阻止运行，请交由 IT 审核，不要绕过组织限制。

功能仍是 v0.1 只读预览：不会创建、确认或取消波次。EXE 打包不会启用生产放单。

## 可选：Windows 云构建

此目录已附 `.github/workflows/windows-exe.yml`，仅支持手动触发。在得到授权的 GitHub 仓库根目录放置本包内容后，可运行 Actions 中的 Build Windows EXE，成功后下载 artifact。

本次没有上传源代码或创建远程仓库。不能将 `browser-profile/`、本机数据目录或账号凭据上传。

## 构建依据

- [PyInstaller 要求在目标操作系统构建](https://pyinstaller.org/en/stable/operating-mode.html)
- [Playwright 官方打包浏览器说明](https://playwright.dev/python/docs/library#pyinstaller)
